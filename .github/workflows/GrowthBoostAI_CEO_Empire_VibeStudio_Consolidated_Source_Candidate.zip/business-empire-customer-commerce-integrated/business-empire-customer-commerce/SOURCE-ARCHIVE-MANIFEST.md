# GrowthBoost AI CEO Business Empire + Vibe Studio — Source Consolidation Manifest

Status: consolidated source candidate; NOT a production deployment or release certification.

## Canonical source selected

`business-empire-customer-commerce-integrated.zip` is the canonical base because it is a strict superset of the earlier `business-empire-vibe-integrated-source.zip` file set: it retains all 385 relative files from that package, updates 75 shared files, and adds 36 Phase 15 customer-commerce files. It includes all seven business apps, CEO HQ, and the shared Vibe Coding Platform.

## Historical/reference archives reviewed

- `files.zip` — archive collection containing prior empire source bundles.
- `business-empire-vibe-integrated-source.zip` — Phase 14 Vibe integration baseline.
- `business-empire-customer-commerce-integrated.zip` — selected canonical Phase 15 + Vibe source.
- `CEO_Business_Empire_All_7_Businesses_Source_Code.zip` — earlier seven-business + HQ baseline, predating the shared Vibe workspace.
- `empire-hq-hardened.zip` — earlier HQ security hardening baseline.
- `business-empire-full-source-release(2).zip` — earlier consolidated source release.
- `empire-hq-phase7-tenant-isolation.zip` — historical tenant isolation phase.
- `empire-hq-phase8-api-isolation.zip` — historical API tenant isolation phase.
- `empire-hq-phase9-business-workspaces.zip` — historical business workspace phase.
- `empire-hq-phase13-account-security-centre.zip` — historical account security centre phase.

The selected canonical package already contains the superseding source for the relevant earlier phases. Older bundles are retained in the Library and are not blindly overlaid, to avoid regressing newer code.

## Included workspaces

- CEO Headquarters
- GrowthBoost AI
- AI Magazine & Comic Book Studio
- Trust Vault customer-vault scaffold
- Stock Market Express
- Real Estate Master Developments
- SUPERGPU UNIVERSAL
- DailyAccess
- Shared Vibe Coding Platform (technology service, not an eighth portfolio business)

## Static checks executed in this consolidation session

- `node scripts/preflight.mjs` — PASS
- `node scripts/check-customer-identity.mjs` — PASS
- `node scripts/check-phase12.mjs` — PASS
- `node scripts/check-phase13.mjs` — PASS
- `node scripts/check-phase15.mjs` — PASS
- `node scripts/source-release-check.mjs` — PASS
- `node scripts/check-rls.mjs` — PASS

These are structural/static checks only. Full dependency installation, TypeScript type checking, Vitest, Prisma validation/migrations, PostgreSQL RLS integration tests, Next.js production builds, browser E2E and security review remain outstanding.

## Vibe Studio activation gates

- Set server-side `AI_GATEWAY_API_KEY` and `VIBE_AI_MODEL` in Vercel only after provisioning and verifying a real gateway key/model.
- The Vibe source uses `/api/projects/[id]/generate`; the inspected Vercel deployment logs instead show failing requests to `/api/chat`. This indicates the deployed project source/route layout does not match this archived source package and must be reconciled before deploying.
- AI generation has not been runtime-tested against a configured provider.
- Remote sandbox execution, dependency installation, hosted preview URLs, public app deployment, custom domains, billing, marketplace checkout and payouts are not implemented/verified as live by this archive alone.
- The Vibe integration is a shared platform linked to seven business workspaces, not an eighth business.

## Vercel safety

No production deployment, project settings, environment variables, database migration or live payment configuration was changed during this consolidation. Do not deploy this source to production until the source repository/project mapping is corrected and all required build, database, security and integration checks pass.
