import { confirmCustomerMfa } from "../../../../../lib/identity";
export async function POST(req: Request) { return confirmCustomerMfa(req); }
