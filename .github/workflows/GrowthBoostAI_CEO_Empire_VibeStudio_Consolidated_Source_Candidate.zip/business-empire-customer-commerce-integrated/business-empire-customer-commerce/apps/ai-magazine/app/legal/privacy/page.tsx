const CONTENT = "# Privacy policy — AI Magazine & Comic Book Studio\n\n> TEMPLATE — must be reviewed by qualified counsel before production use.\n\nWe process personal data under UK GDPR. Data controller: AI Magazine & Comic Book Studio (a separate legal entity within the group). Lawful bases, retention periods, data-subject rights (access, rectification, erasure, portability), international transfers and our Data Protection Officer contact are documented here before go-live. Customer data is never shared with other group companies without a lawful basis.";

export default function LegalPage() {
  return <main style={{ padding: 24, whiteSpace: "pre-wrap", fontFamily: "system-ui" }}><pre style={{ whiteSpace: "pre-wrap", fontFamily: "inherit" }}>{CONTENT}</pre></main>;
}
