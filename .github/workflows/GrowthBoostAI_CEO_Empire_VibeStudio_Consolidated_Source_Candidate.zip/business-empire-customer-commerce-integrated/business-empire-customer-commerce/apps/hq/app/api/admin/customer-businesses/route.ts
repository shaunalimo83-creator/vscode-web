import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { currentHqUser } from "../../auth/session";

export async function GET() {
  const headers = { "Cache-Control": "no-store" };
  const hq = await currentHqUser();
  if (!hq) return NextResponse.json({ error: "ceo_authentication_required" }, { status: 401, headers });
  try {
    const businesses = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${hq.id}, true)`;
      await tx.$queryRaw`SELECT set_config('app.company_id', ${hq.companyId}, true)`;
      return tx.company.findMany({
        where: { kind: "customer" },
        orderBy: { createdAt: "desc" },
        take: 500,
        select: { id: true, slug: true, name: true, status: true, createdAt: true, businessProfile: { select: { visibility: true, handle: true } } },
      });
    });
    return NextResponse.json({ businesses }, { headers });
  } catch { return NextResponse.json({ error: "customer_business_directory_unavailable" }, { status: 503, headers }); }
}
