import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { currentHqUser } from "../../../auth/session";
import { isSameOriginRequest } from "@empire/core";

export async function GET() {
  const headers = { "Cache-Control": "no-store" };
  const hq = await currentHqUser();
  if (!hq) return NextResponse.json({ error: "ceo_authentication_required" }, { status: 401, headers });
  try {
    const products = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${hq.id}, true)`;
      await tx.$queryRaw`SELECT set_config('app.company_id', ${hq.companyId}, true)`;
      return tx.marketplaceProduct.findMany({
        where: { status: "pending_review" },
        orderBy: { createdAt: "asc" },
        take: 100,
        select: { id: true, title: true, description: true, productType: true, priceMinor: true, currency: true, createdAt: true, company: { select: { name: true, slug: true } } },
      });
    });
    return NextResponse.json({ products }, { headers });
  } catch { return NextResponse.json({ error: "marketplace_review_unavailable" }, { status: 503, headers }); }
}

export async function PATCH(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const hq = await currentHqUser();
  if (!hq) return NextResponse.json({ error: "ceo_authentication_required" }, { status: 401, headers });
  const body = await request.json().catch(() => null);
  const id = typeof body?.productId === "string" ? body.productId : "";
  const status = body?.status === "published" || body?.status === "archived" ? body.status : "";
  if (!id || id.length > 80 || !status) return NextResponse.json({ error: "valid_product_and_review_action_required" }, { status: 400, headers });
  try {
    const result = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${hq.id}, true)`;
      await tx.$queryRaw`SELECT set_config('app.company_id', ${hq.companyId}, true)`;
      const updated = await tx.marketplaceProduct.updateMany({ where: { id, status: "pending_review" }, data: { status } });
      if (updated.count !== 1) return false;
      await tx.auditLog.create({ data: { actorId: hq.id, companyId: hq.companyId, action: `marketplace.product.${status}`, subject: id } });
      return true;
    });
    if (!result) return NextResponse.json({ error: "review_item_not_found" }, { status: 404, headers });
    return NextResponse.json({ ok: true, status }, { headers });
  } catch { return NextResponse.json({ error: "marketplace_review_unavailable" }, { status: 503, headers }); }
}
