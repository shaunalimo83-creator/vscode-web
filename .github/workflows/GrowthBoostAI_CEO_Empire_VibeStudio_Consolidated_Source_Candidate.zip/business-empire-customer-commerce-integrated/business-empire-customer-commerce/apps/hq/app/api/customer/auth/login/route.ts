import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { decryptMfaSecret, newSessionToken, sha256, verifyPassword, verifyTotp, isSameOriginRequest } from "@empire/core";
import { loginIsThrottled, clearLoginThrottle } from "../../../auth/throttle";
import { CUSTOMER_SESSION_COOKIE } from "../../../../../lib/customer-session";

export async function POST(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const body = await request.json().catch(() => null);
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  const mfaCode = typeof body?.mfaCode === "string" ? body.mfaCode.trim() : "";
  const recoveryCode = typeof body?.recoveryCode === "string" ? body.recoveryCode.trim() : "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !password || password.length > 256) return NextResponse.json({ error: "invalid_credentials" }, { status: 401, headers });
  const ip = request.headers.get("x-real-ip") || "unknown";
  if (await loginIsThrottled(email, ip)) return NextResponse.json({ error: "too_many_attempts_try_again_later" }, { status: 429, headers });
  try {
    const user = await prisma.user.findUnique({ where: { email }, select: { id: true, passwordHash: true, isActive: true, emailVerifiedAt: true, mfaEnrolled: true, mfaSecretEnc: true } });
    if (!user?.isActive || !user.emailVerifiedAt || !user.passwordHash || !verifyPassword(password, user.passwordHash)) return NextResponse.json({ error: "invalid_credentials" }, { status: 401, headers });
    if (user.mfaEnrolled) {
      let valid = false;
      if (mfaCode && user.mfaSecretEnc) {
        try { valid = verifyTotp(decryptMfaSecret(user.mfaSecretEnc), mfaCode, Math.floor(Date.now() / 1000)); } catch { valid = false; }
      }
      if (!valid && recoveryCode) {
        const normalized = recoveryCode.replace(/-/g, "").toUpperCase();
        const hashes = [...new Set([sha256(recoveryCode), sha256(recoveryCode.toLowerCase()), sha256(recoveryCode.toUpperCase()), sha256(normalized)])];
        const saved = await prisma.$transaction(async tx => {
          await tx.$queryRaw`SELECT set_config('app.user_id', ${user.id}, true)`;
          const code = await tx.recoveryCode.findFirst({ where: { userId: user.id, codeHash: { in: hashes }, usedAt: null }, select: { id: true } });
          if (!code) return false;
          const consumed = await tx.recoveryCode.updateMany({ where: { id: code.id, usedAt: null }, data: { usedAt: new Date() } });
          return consumed.count === 1;
        });
        valid = saved;
      }
      if (!valid) return NextResponse.json({ error: "mfa_verification_required" }, { status: 401, headers });
    }
    const token = newSessionToken();
    const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000);
    await prisma.session.create({ data: { userId: user.id, tokenHash: sha256(token), expiresAt } });
    await clearLoginThrottle(email, ip);
    const response = NextResponse.json({ ok: true, expiresAt }, { headers });
    response.cookies.set(CUSTOMER_SESSION_COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", expires: expiresAt });
    return response;
  } catch {
    return NextResponse.json({ error: "customer_login_unavailable" }, { status: 503, headers });
  }
}
