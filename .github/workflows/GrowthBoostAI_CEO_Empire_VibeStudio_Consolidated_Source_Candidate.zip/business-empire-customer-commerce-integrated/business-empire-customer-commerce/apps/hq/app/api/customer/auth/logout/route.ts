import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@empire/db";
import { sha256, isSameOriginRequest } from "@empire/core";
import { CUSTOMER_SESSION_COOKIE } from "../../../../../lib/customer-session";

export async function POST(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const token = cookies().get(CUSTOMER_SESSION_COOKIE)?.value;
  if (token) await prisma.session.updateMany({ where: { tokenHash: sha256(token), revokedAt: null }, data: { revokedAt: new Date() } }).catch(() => null);
  const response = NextResponse.json({ ok: true }, { headers });
  response.cookies.set(CUSTOMER_SESSION_COOKIE, "", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: 0 });
  return response;
}
