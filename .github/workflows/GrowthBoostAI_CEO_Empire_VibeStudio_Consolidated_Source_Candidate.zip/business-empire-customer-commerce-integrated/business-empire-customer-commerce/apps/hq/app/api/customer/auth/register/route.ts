import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { prisma } from "@empire/db";
import { hashPassword, verifyPassword, sha256, isSameOriginRequest } from "@empire/core";
import { loginIsThrottled } from "../../../auth/throttle";

export const runtime = "nodejs";
const NO_STORE = { "Cache-Control": "no-store" };
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function sendVerification(to: string, token: string) {
  const endpoint = process.env.AUTH_EMAIL_WEBHOOK_URL;
  const secret = process.env.AUTH_EMAIL_WEBHOOK_SECRET;
  const appUrl = process.env.CUSTOMER_HQ_URL || process.env.PUBLIC_APP_URL;
  if (!endpoint || !secret || !appUrl) throw new Error("email_delivery_not_configured");
  const url = new URL("/customer/verify", appUrl);
  url.searchParams.set("token", token);
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${secret}` },
    body: JSON.stringify({
      to,
      subject: "Verify your Business Empire account",
      text: `Verify your email address to activate your Business Empire customer account: ${url.toString()}\n\nThis link expires in 30 minutes. If you did not create this account, ignore this message.`,
      application: "business-empire-customer-hq",
    }),
    cache: "no-store",
  });
  if (!response.ok) throw new Error("email_delivery_failed");
}

export async function POST(request: Request) {
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers: NO_STORE });
  if (process.env.CUSTOMER_REGISTRATION_ENABLED !== "true") return NextResponse.json({ error: "customer_registration_not_enabled" }, { status: 503, headers: NO_STORE });
  const body = await request.json().catch(() => null);
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  const displayName = typeof body?.displayName === "string" ? body.displayName.trim() : "";
  const termsAccepted = body?.termsAccepted === true;
  const privacyAccepted = body?.privacyAccepted === true;
  if (!EMAIL.test(email) || email.length > 254 || password.length < 12 || password.length > 256 || displayName.length < 2 || displayName.length > 60 || !termsAccepted || !privacyAccepted) {
    return NextResponse.json({ error: "valid_name_email_and_password_minimum_12_characters_required" }, { status: 400, headers: NO_STORE });
  }
  const ip = request.headers.get("x-real-ip") || "unknown";
  if (await loginIsThrottled(email, ip)) return NextResponse.json({ error: "too_many_attempts_try_again_later" }, { status: 429, headers: NO_STORE });

  try {
    const existing = await prisma.user.findUnique({ where: { email }, select: { id: true, passwordHash: true, emailVerifiedAt: true, isActive: true } });
    if (existing?.emailVerifiedAt) return NextResponse.json({ error: "account_already_exists_sign_in" }, { status: 409, headers: NO_STORE });
    if (existing && (!existing.isActive || !existing.passwordHash)) return NextResponse.json({ error: "registration_unavailable" }, { status: 503, headers: NO_STORE });
    if (existing?.passwordHash && !verifyPassword(password, existing.passwordHash)) {
      return NextResponse.json({ error: "account_already_exists_sign_in" }, { status: 409, headers: NO_STORE });
    }
    const rawToken = randomBytes(32).toString("hex");
    const userId = await prisma.$transaction(async (tx) => {
      const user = existing
        ? await tx.user.findUniqueOrThrow({ where: { id: existing.id }, select: { id: true, passwordHash: true } })
        : await tx.user.create({ data: { email, passwordHash: hashPassword(password) }, select: { id: true, passwordHash: true } });
      if (existing && (!user.passwordHash || !verifyPassword(password, user.passwordHash))) throw new Error("account_exists_password_mismatch");
      await tx.$queryRaw`SELECT set_config('app.user_id', ${user.id}, true)`;
      await tx.customerConsent.createMany({
        data: [
          { userId: user.id, documentType: "terms", version: process.env.CUSTOMER_TERMS_VERSION || "2026-11-17-v1", source: "customer-hq" },
          { userId: user.id, documentType: "privacy", version: process.env.CUSTOMER_PRIVACY_VERSION || "2026-11-17-v1", source: "customer-hq" },
        ],
        skipDuplicates: true,
      });
      const profile = await tx.customerProfile.findUnique({ where: { userId: user.id }, select: { id: true } });
      if (!profile) {
        const base = displayName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 24) || "member";
        await tx.customerProfile.create({ data: { userId: user.id, handle: `${base}-${randomBytes(3).toString("hex")}`, displayName, visibility: "private" } });
      }
      await tx.emailVerificationToken.updateMany({ where: { userId: user.id, usedAt: null }, data: { usedAt: new Date() } });
      await tx.emailVerificationToken.create({ data: { userId: user.id, tokenHash: sha256(rawToken), expiresAt: new Date(Date.now() + 30 * 60 * 1000) } });
      return user.id;
    });
    await sendVerification(email, rawToken);
    return NextResponse.json({ ok: true, message: "Check your email and verify your account before signing in." }, { status: 201, headers: NO_STORE });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message === "account_exists_password_mismatch") return NextResponse.json({ error: "account_already_exists_sign_in" }, { status: 409, headers: NO_STORE });
    return NextResponse.json({ error: "registration_or_email_delivery_unavailable" }, { status: 503, headers: NO_STORE });
  }
}
