import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { sha256, isSameOriginRequest } from "@empire/core";

export async function POST(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const body = await request.json().catch(() => null);
  const token = typeof body?.token === "string" ? body.token : "";
  if (!/^[a-f0-9]{64}$/i.test(token)) return NextResponse.json({ error: "invalid_or_expired_verification_link" }, { status: 400, headers });
  try {
    const saved = await prisma.emailVerificationToken.findUnique({ where: { tokenHash: sha256(token) }, select: { id: true, userId: true, expiresAt: true, usedAt: true } });
    if (!saved || saved.usedAt || saved.expiresAt <= new Date()) return NextResponse.json({ error: "invalid_or_expired_verification_link" }, { status: 400, headers });
    await prisma.$transaction(async tx => {
      const consumed = await tx.emailVerificationToken.updateMany({ where: { id: saved.id, usedAt: null, expiresAt: { gt: new Date() } }, data: { usedAt: new Date() } });
      if (consumed.count !== 1) throw new Error("verification_already_used");
      await tx.user.update({ where: { id: saved.userId }, data: { emailVerifiedAt: new Date() } });
    });
    return NextResponse.json({ ok: true, message: "Your email is verified. You can now sign in." }, { headers });
  } catch {
    return NextResponse.json({ error: "verification_unavailable" }, { status: 503, headers });
  }
}
