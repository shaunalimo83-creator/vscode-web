import { NextResponse } from "next/server";
import { isSameOriginRequest } from "@empire/core";
import { getCustomerSession, withCustomerBusiness } from "../../../../../../../lib/customer-session";

export async function PATCH(request: Request, context: { params: { id: string; productId: string } }) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const result = await withCustomerBusiness(session, context.params.id, async ({ tx, companyId }) => {
    const updated = await tx.marketplaceProduct.updateMany({
      where: { id: context.params.productId, companyId, sellerUserId: session.userId, status: "draft" },
      data: { status: "pending_review" },
    });
    return updated.count === 1;
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers });
  if (!result.value) return NextResponse.json({ error: "draft_product_not_found" }, { status: 404, headers });
  return NextResponse.json({ ok: true, message: "Product submitted for CEO Headquarters marketplace review." }, { headers });
}
