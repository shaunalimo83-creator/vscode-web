import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { isSameOriginRequest } from "@empire/core";
import { getCustomerSession, withCustomerBusiness } from "../../../../../../lib/customer-session";

export async function GET(_request: Request, context: { params: { id: string } }) {
  const headers = { "Cache-Control": "no-store" };
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const result = await withCustomerBusiness(session, context.params.id, async ({ tx, companyId }) =>
    tx.marketplaceProduct.findMany({ where: { companyId }, orderBy: { createdAt: "desc" }, take: 100, select: { id: true, title: true, description: true, productType: true, priceMinor: true, currency: true, stockQuantity: true, status: true } })
  );
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers });
  return NextResponse.json({ products: result.value }, { headers });
}

export async function POST(request: Request, context: { params: { id: string } }) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const body = await request.json().catch(() => null);
  const title = typeof body?.title === "string" ? body.title.trim() : "";
  const description = typeof body?.description === "string" ? body.description.trim() : "";
  const productType = ["physical","digital","service"].includes(body?.productType) ? body.productType : "";
  const priceMinor = Number(body?.priceMinor);
  const stockQuantity = body?.stockQuantity === null || body?.stockQuantity === undefined || body?.stockQuantity === "" ? null : Number(body.stockQuantity);
  if (title.length < 2 || title.length > 120 || description.length < 10 || description.length > 4000 || !productType || !Number.isSafeInteger(priceMinor) || priceMinor < 1 || priceMinor > 100_000_000 || (stockQuantity !== null && (!Number.isSafeInteger(stockQuantity) || stockQuantity < 0))) {
    return NextResponse.json({ error: "valid_product_details_and_price_in_pence_required" }, { status: 400, headers });
  }
  const result = await withCustomerBusiness(session, context.params.id, async ({ tx, companyId }) => {
    const base = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48) || "product";
    const slug = `${base}-${randomBytes(3).toString("hex")}`;
    return tx.marketplaceProduct.create({
      data: { companyId, sellerUserId: session.userId, slug, title, description, productType, priceMinor, currency: "GBP", stockQuantity, status: "draft" },
      select: { id: true, title: true, priceMinor: true, currency: true, status: true },
    });
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers });
  return NextResponse.json({ product: result.value, message: "Product saved as a draft. Marketplace review and payment-provider activation are required before customers can buy it." }, { status: 201, headers });
}
