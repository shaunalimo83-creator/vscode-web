import { NextResponse } from "next/server";
import { isSameOriginRequest } from "@empire/core";
import { getCustomerSession, withCustomerBusiness } from "../../../../../../lib/customer-session";

export async function PUT(request: Request, context: { params: { id: string } }) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const body = await request.json().catch(() => null);
  const description = typeof body?.description === "string" ? body.description.trim() : "";
  const visibility = body?.visibility === "public" ? "public" : body?.visibility === "private" ? "private" : "";
  const websiteUrl = typeof body?.websiteUrl === "string" && body.websiteUrl.trim() ? body.websiteUrl.trim() : null;
  if (description.length > 2000 || !visibility || (websiteUrl && (!/^https:\/\//i.test(websiteUrl) || websiteUrl.length > 300))) {
    return NextResponse.json({ error: "invalid_business_profile_details" }, { status: 400, headers });
  }
  const result = await withCustomerBusiness(session, context.params.id, async ({ tx, companyId }) => {
    return tx.businessProfile.update({ where: { companyId }, data: { description, visibility, websiteUrl }, select: { handle: true, displayName: true, description: true, visibility: true, websiteUrl: true } });
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers });
  return NextResponse.json({ profile: result.value }, { headers });
}
