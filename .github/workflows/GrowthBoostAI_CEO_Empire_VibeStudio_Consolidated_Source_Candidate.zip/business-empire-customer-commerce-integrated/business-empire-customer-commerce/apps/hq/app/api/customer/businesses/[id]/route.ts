import { NextResponse } from "next/server";
import { getCustomerSession, withCustomerBusiness } from "../../../../../lib/customer-session";

export async function GET(_request: Request, context: { params: { id: string } }) {
  const headers = { "Cache-Control": "no-store" };
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const result = await withCustomerBusiness(session, context.params.id, async ({ tx, companyId }) => {
    const [company, products, orders, settlements, pendingSettlements, sellerAccount] = await Promise.all([
      tx.company.findUnique({ where: { id: companyId }, select: { id: true, slug: true, name: true, currency: true, businessProfile: { select: { handle: true, visibility: true, description: true } } } }),
      tx.marketplaceProduct.findMany({ where: { companyId }, orderBy: { createdAt: "desc" }, take: 50, select: { id: true, title: true, productType: true, priceMinor: true, currency: true, status: true, createdAt: true } }),
      tx.marketplaceOrder.findMany({ where: { sellerCompanyId: companyId }, orderBy: { createdAt: "desc" }, take: 50, select: { id: true, status: true, subtotalMinor: true, platformFeeMinor: true, sellerNetMinor: true, currency: true, createdAt: true, paidAt: true, items: { select: { titleSnapshot: true, quantity: true, lineTotalMinor: true } } } }),
      tx.marketplaceSettlement.aggregate({ where: { sellerCompanyId: companyId, status: { in: ["transferred","paid"] } }, _sum: { sellerNetMinor: true } }),
      tx.marketplaceSettlement.aggregate({ where: { sellerCompanyId: companyId, status: "pending" }, _sum: { sellerNetMinor: true } }),
      tx.sellerPaymentAccount.findUnique({ where: { companyId }, select: { provider: true, onboardingStatus: true, detailsSubmitted: true, chargesEnabled: true, payoutsEnabled: true } }),
    ]);
    return { company, products, orders, confirmedSellerProceedsMinor: settlements._sum.sellerNetMinor ?? 0, pendingSellerProceedsMinor: pendingSettlements._sum.sellerNetMinor ?? 0, sellerAccount };
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers });
  if (!result.value.company) return NextResponse.json({ error: "business_not_found" }, { status: 404, headers });
  return NextResponse.json({ dashboard: result.value }, { headers });
}
