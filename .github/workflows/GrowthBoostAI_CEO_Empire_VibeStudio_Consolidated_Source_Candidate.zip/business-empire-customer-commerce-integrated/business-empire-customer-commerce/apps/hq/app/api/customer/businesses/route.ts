import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { getCustomerSession } from "../../../../lib/customer-session";
import { isSameOriginRequest } from "@empire/core";

export async function GET() {
  const headers = { "Cache-Control": "no-store" };
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  try {
    const businesses = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      return tx.userCompany.findMany({
        where: { userId: session.userId, role: "business_owner", company: { kind: "customer", status: "active" } },
        select: { company: { select: { id: true, slug: true, name: true, currency: true, status: true, businessProfile: { select: { handle: true, visibility: true } } } } },
        orderBy: { company: { createdAt: "desc" } },
      });
    });
    return NextResponse.json({ businesses: businesses.map(row => row.company) }, { headers });
  } catch { return NextResponse.json({ error: "business_list_unavailable" }, { status: 503, headers }); }
}

export async function POST(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const body = await request.json().catch(() => null);
  const name = typeof body?.name === "string" ? body.name.trim() : "";
  const description = typeof body?.description === "string" ? body.description.trim() : "";
  if (name.length < 2 || name.length > 100 || description.length > 2000) return NextResponse.json({ error: "invalid_business_details" }, { status: 400, headers });
  try {
    const created = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      const rows = await tx.$queryRaw<Array<{ company_id: string; company_slug: string }>>`SELECT * FROM create_customer_business(${name}, ${description})`;
      return rows[0];
    });
    if (!created) return NextResponse.json({ error: "business_creation_failed" }, { status: 503, headers });
    return NextResponse.json({ business: { id: created.company_id, slug: created.company_slug, name }, message: "Your business workspace has been created in Customer Business HQ." }, { status: 201, headers });
  } catch (error) {
    const code = error instanceof Error ? error.message : "";
    if (code.includes("verified_account_required")) return NextResponse.json({ error: "verified_email_required" }, { status: 403, headers });
    if (code.includes("invalid_business_name")) return NextResponse.json({ error: "invalid_business_name" }, { status: 400, headers });
    return NextResponse.json({ error: "business_creation_unavailable" }, { status: 503, headers });
  }
}
