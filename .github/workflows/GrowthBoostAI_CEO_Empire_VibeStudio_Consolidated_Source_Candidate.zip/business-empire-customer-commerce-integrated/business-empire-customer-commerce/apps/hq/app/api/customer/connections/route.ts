import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { isSameOriginRequest } from "@empire/core";
import { getCustomerSession } from "../../../../lib/customer-session";

export async function GET() {
  const headers = { "Cache-Control": "no-store" };
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  try {
    const connections = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      return tx.profileConnection.findMany({
        where: { OR: [{ requesterUserId: session.userId }, { recipientUserId: session.userId }] },
        orderBy: { createdAt: "desc" },
        take: 100,
        select: { id: true, status: true, requesterUserId: true, recipientUserId: true, requester: { select: { customerProfile: { select: { handle: true, displayName: true } } } }, recipient: { select: { customerProfile: { select: { handle: true, displayName: true } } } } },
      });
    });
    return NextResponse.json({ connections }, { headers });
  } catch { return NextResponse.json({ error: "connections_unavailable" }, { status: 503, headers }); }
}

export async function PATCH(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const body = await request.json().catch(() => null);
  const id = typeof body?.id === "string" ? body.id : "";
  const status = body?.status === "accepted" || body?.status === "declined" ? body.status : "";
  if (!id || !status) return NextResponse.json({ error: "invalid_connection_action" }, { status: 400, headers });
  try {
    await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      const updated = await tx.profileConnection.updateMany({ where: { id, recipientUserId: session.userId, status: "pending" }, data: { status } });
      if (updated.count !== 1) throw new Error("connection_not_found");
    });
    return NextResponse.json({ ok: true, status }, { headers });
  } catch { return NextResponse.json({ error: "connection_action_unavailable" }, { status: 404, headers }); }
}
