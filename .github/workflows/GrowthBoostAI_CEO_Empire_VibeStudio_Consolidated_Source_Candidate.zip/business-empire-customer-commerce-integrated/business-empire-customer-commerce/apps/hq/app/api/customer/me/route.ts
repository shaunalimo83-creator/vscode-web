import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { getCustomerSession } from "../../../../lib/customer-session";

export async function GET() {
  const headers = { "Cache-Control": "no-store" };
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  try {
    const data = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      const profile = await tx.customerProfile.findUnique({ where: { userId: session.userId }, select: { handle: true, displayName: true, bio: true, avatarUrl: true, visibility: true, allowConnections: true } });
      const memberships = await tx.userCompany.findMany({
        where: { userId: session.userId, role: "business_owner", company: { kind: "customer", status: "active" } },
        select: { company: { select: { id: true, slug: true, name: true, status: true, businessProfile: { select: { visibility: true, handle: true } } } } },
        orderBy: { company: { createdAt: "desc" } },
      });
      return { profile, businesses: memberships.map(m => m.company) };
    });
    return NextResponse.json({ user: { id: session.userId, email: session.email, displayName: session.displayName }, ...data }, { headers });
  } catch { return NextResponse.json({ error: "customer_account_unavailable" }, { status: 503, headers }); }
}
