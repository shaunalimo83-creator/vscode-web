import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { getCustomerSession } from "../../../../lib/customer-session";

export async function GET() {
  const headers = { "Cache-Control": "no-store" };
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  try {
    const orders = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      return tx.marketplaceOrder.findMany({
        where: { buyerUserId: session.userId },
        orderBy: { createdAt: "desc" },
        take: 100,
        select: { id: true, status: true, subtotalMinor: true, currency: true, createdAt: true, paidAt: true, sellerCompany: { select: { name: true } }, items: { select: { titleSnapshot: true, quantity: true, lineTotalMinor: true } } },
      });
    });
    return NextResponse.json({ orders }, { headers });
  } catch { return NextResponse.json({ error: "order_history_unavailable" }, { status: 503, headers }); }
}
