import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { randomBytes } from "node:crypto";
import { getCustomerSession } from "../../../../lib/customer-session";
import { isSameOriginRequest } from "@empire/core";

export async function GET() {
  const headers = { "Cache-Control": "no-store" };
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const profile = await prisma.$transaction(async tx => {
    await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
    return tx.customerProfile.findUnique({ where: { userId: session.userId }, select: { handle: true, displayName: true, bio: true, avatarUrl: true, visibility: true, allowConnections: true } });
  });
  return NextResponse.json({ profile }, { headers });
}

export async function PUT(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const body = await request.json().catch(() => null);
  const displayName = typeof body?.displayName === "string" ? body.displayName.trim() : "";
  const bio = typeof body?.bio === "string" ? body.bio.trim() : "";
  const visibility = body?.visibility === "private" ? "private" : body?.visibility === "public" ? "public" : "";
  const allowConnections = body?.allowConnections === true;
  if (displayName.length < 2 || displayName.length > 60 || bio.length > 500 || !visibility) return NextResponse.json({ error: "invalid_profile_details" }, { status: 400, headers });
  try {
    const profile = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      const current = await tx.customerProfile.findUnique({ where: { userId: session.userId }, select: { id: true } });
      if (current) return tx.customerProfile.update({ where: { userId: session.userId }, data: { displayName, bio, visibility, allowConnections }, select: { handle: true, displayName: true, bio: true, visibility: true, allowConnections: true } });
      const handle = `${displayName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 24) || "member"}-${randomBytes(3).toString("hex")}`;
      return tx.customerProfile.create({ data: { userId: session.userId, handle, displayName, bio, visibility, allowConnections }, select: { handle: true, displayName: true, bio: true, visibility: true, allowConnections: true } });
    });
    return NextResponse.json({ profile }, { headers });
  } catch { return NextResponse.json({ error: "profile_update_unavailable" }, { status: 503, headers }); }
}
