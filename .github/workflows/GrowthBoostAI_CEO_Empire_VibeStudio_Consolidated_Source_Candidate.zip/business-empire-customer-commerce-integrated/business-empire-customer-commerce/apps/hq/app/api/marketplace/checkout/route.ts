import { NextResponse } from "next/server";
import { isSameOriginRequest } from "@empire/core";
import { getCustomerSession } from "../../../../lib/customer-session";

/**
 * Checkout is intentionally fail-closed until a regulated marketplace PSP
 * adapter, seller verification, signed webhooks and transfer reconciliation
 * have been configured and independently tested.
 */
export async function POST(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  const body = await request.json().catch(() => null);
  if (typeof body?.productId !== "string" || body.productId.length > 80) return NextResponse.json({ error: "valid_product_required" }, { status: 400, headers });
  return NextResponse.json({
    error: "marketplace_payments_not_connected",
    message: "Checkout is not available yet. The seller payment account, buyer checkout, platform fee allocation and verified payout webhook must be activated before any money is collected.",
  }, { status: 503, headers });
}
