import { NextResponse } from "next/server";
import { prisma } from "@empire/db";

export async function GET(request: Request) {
  const headers = { "Cache-Control": "no-store" };
  const url = new URL(request.url);
  const search = (url.searchParams.get("q") || "").trim().slice(0, 80);
  try {
    const products = await prisma.marketplaceProduct.findMany({
      where: { status: "published", ...(search ? { OR: [{ title: { contains: search, mode: "insensitive" } }, { description: { contains: search, mode: "insensitive" } }] } : {}) },
      orderBy: { createdAt: "desc" },
      take: 60,
      select: { id: true, title: true, description: true, productType: true, priceMinor: true, currency: true, company: { select: { name: true, businessProfile: { select: { handle: true, displayName: true } } } } },
    });
    return NextResponse.json({ products }, { headers });
  } catch { return NextResponse.json({ error: "marketplace_unavailable" }, { status: 503, headers }); }
}
