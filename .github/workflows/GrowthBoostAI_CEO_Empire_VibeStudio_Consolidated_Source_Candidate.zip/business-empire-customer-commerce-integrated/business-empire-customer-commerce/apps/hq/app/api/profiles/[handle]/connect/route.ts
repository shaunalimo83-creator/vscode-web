import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { isSameOriginRequest } from "@empire/core";
import { getCustomerSession } from "../../../../../lib/customer-session";

export async function POST(request: Request, context: { params: { handle: string } }) {
  const headers = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers });
  const session = await getCustomerSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers });
  try {
    const result = await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      const target = await tx.customerProfile.findFirst({ where: { handle: context.params.handle, visibility: "public", allowConnections: true }, select: { userId: true } });
      if (!target || target.userId === session.userId) return null;
      const existing = await tx.profileConnection.findUnique({
        where: { requesterUserId_recipientUserId: { requesterUserId: session.userId, recipientUserId: target.userId } },
        select: { id: true, status: true },
      });
      if (existing) return existing;
      return tx.profileConnection.create({
        data: { requesterUserId: session.userId, recipientUserId: target.userId, status: "pending" },
        select: { id: true, status: true },
      });
    });
    if (!result) return NextResponse.json({ error: "profile_not_available_for_connection" }, { status: 404, headers });
    return NextResponse.json({ connection: result }, { status: 201, headers });
  } catch { return NextResponse.json({ error: "connection_request_unavailable" }, { status: 503, headers }); }
}
