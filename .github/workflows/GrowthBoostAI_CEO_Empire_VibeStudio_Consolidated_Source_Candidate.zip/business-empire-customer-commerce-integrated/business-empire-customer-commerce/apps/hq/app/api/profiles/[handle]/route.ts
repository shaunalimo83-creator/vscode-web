import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { getCustomerSession } from "../../../../lib/customer-session";

export async function GET(_request: Request, context: { params: { handle: string } }) {
  const headers = { "Cache-Control": "no-store" };
  const handle = context.params.handle.toLowerCase();
  if (!/^[a-z0-9-]{2,40}$/.test(handle)) return NextResponse.json({ error: "profile_not_found" }, { status: 404, headers });
  try {
    const session = await getCustomerSession();
    const profile = session
      ? await prisma.$transaction(async tx => {
          await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
          const accepted = await tx.profileConnection.findMany({
            where: { status: "accepted", OR: [{ requesterUserId: session.userId }, { recipientUserId: session.userId }] },
            select: { requesterUserId: true, recipientUserId: true },
          });
          const connectedIds = [...new Set(accepted.flatMap(connection => [connection.requesterUserId, connection.recipientUserId]).filter(id => id !== session.userId))];
          return tx.customerProfile.findFirst({
            where: { handle, OR: [{ visibility: "public" }, { userId: session.userId }, { userId: { in: connectedIds } }] },
            select: { handle: true, displayName: true, bio: true, avatarUrl: true, visibility: true, allowConnections: true, user: { select: { ownedCompanies: { where: { kind: "customer", status: "active" }, select: { businessProfile: { select: { handle: true, displayName: true, description: true } } } } } } },
          });
        })
      : await prisma.customerProfile.findFirst({
          where: { handle, visibility: "public" },
          select: { handle: true, displayName: true, bio: true, avatarUrl: true, visibility: true, allowConnections: true, user: { select: { ownedCompanies: { where: { kind: "customer", status: "active" }, select: { businessProfile: { select: { handle: true, displayName: true, description: true } } } } } } },
        });
    if (!profile) return NextResponse.json({ error: "profile_not_found" }, { status: 404, headers });
    const businesses = profile.user.ownedCompanies.map(company => company.businessProfile).filter(Boolean);
    return NextResponse.json({ profile: { handle: profile.handle, displayName: profile.displayName, bio: profile.bio, avatarUrl: profile.avatarUrl, visibility: profile.visibility, allowConnections: profile.allowConnections }, businesses }, { headers });
  } catch { return NextResponse.json({ error: "profile_service_unavailable" }, { status: 503, headers }); }
}
