import { NextResponse } from "next/server";
import { prisma } from "@empire/db";

export async function GET(_request: Request, context: { params: { handle: string } }) {
  const headers = { "Cache-Control": "no-store" };
  const handle = context.params.handle.toLowerCase();
  if (!/^[a-z0-9-]{2,80}$/.test(handle)) return NextResponse.json({ error: "store_not_found" }, { status: 404, headers });
  try {
    const profile = await prisma.businessProfile.findFirst({
      where: { handle, visibility: "public", company: { kind: "customer", status: "active" } },
      select: { handle: true, displayName: true, description: true, websiteUrl: true, company: { select: { id: true, name: true, marketplaceProducts: { where: { status: "published" }, orderBy: { createdAt: "desc" }, take: 60, select: { id: true, title: true, description: true, productType: true, priceMinor: true, currency: true } } } } },
    });
    if (!profile) return NextResponse.json({ error: "store_not_found" }, { status: 404, headers });
    return NextResponse.json({ store: { handle: profile.handle, displayName: profile.displayName, description: profile.description, websiteUrl: profile.websiteUrl, products: profile.company.marketplaceProducts } }, { headers });
  } catch { return NextResponse.json({ error: "store_unavailable" }, { status: 503, headers }); }
}
