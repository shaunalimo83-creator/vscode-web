"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
type Business={id:string;slug:string;name:string;status:string;createdAt:string;businessProfile:{visibility:string;handle:string}|null};
export default function CustomerBusinessesAdmin(){
 const [businesses,setBusinesses]=useState<Business[]>([]);const [error,setError]=useState("");
 useEffect(()=>{fetch("/api/admin/customer-businesses",{cache:"no-store"}).then(async r=>{const d=await r.json();if(!r.ok)throw new Error(d.error||"CEO access required.");setBusinesses(d.businesses||[]);}).catch(e=>setError(e.message));},[]);
 return <main style={wrap}><Link href="/" style={link}>← CEO Headquarters</Link><h1>Customer-owned businesses</h1><p style={muted}>Directory of businesses created by customers through Customer Business HQ. This view is limited to business identity and storefront status; it does not expose private customer financial records.</p>{error&&<p role="alert">{error}</p>}{businesses.length===0?<p style={muted}>No customer-owned businesses have been created yet.</p>:<div style={tableWrap}><table style={table}><thead><tr><th>Business</th><th>Status</th><th>Storefront</th><th>Created</th></tr></thead><tbody>{businesses.map(b=><tr key={b.id}><td><strong>{b.name}</strong><br/><small>{b.slug}</small></td><td>{b.status}</td><td>{b.businessProfile?.visibility||"private"}</td><td>{new Date(b.createdAt).toLocaleDateString("en-GB")}</td></tr>)}</tbody></table></div>}</main>;
}
const wrap:React.CSSProperties={maxWidth:1100,margin:"0 auto",padding:"36px 22px 80px",color:"#eef2ff"};const link:React.CSSProperties={color:"#c4b5fd",fontWeight:700};const muted:React.CSSProperties={color:"#aeb9d3",lineHeight:1.6};const tableWrap:React.CSSProperties={overflowX:"auto",marginTop:22};const table:React.CSSProperties={width:"100%",borderCollapse:"collapse",textAlign:"left"}; 
