"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
type Product = { id: string; title: string; productType: string; priceMinor: number; currency: string; status: string };
type Order = { id: string; status: string; subtotalMinor: number; sellerNetMinor: number; platformFeeMinor: number; currency: string; createdAt: string; items: { titleSnapshot: string; quantity: number; lineTotalMinor: number }[] };
type Dashboard = { company: { id: string; name: string; slug: string; businessProfile: { handle: string; visibility: string; description: string } | null }; products: Product[]; orders: Order[]; confirmedSellerProceedsMinor: number; pendingSellerProceedsMinor: number; sellerAccount: { provider: string; onboardingStatus: string; detailsSubmitted: boolean; chargesEnabled: boolean; payoutsEnabled: boolean } | null };
const money = (n: number, currency = "GBP") => new Intl.NumberFormat("en-GB", { style: "currency", currency }).format(n / 100);

export default function BusinessCEOPage({ params }: { params: { id: string } }) {
  const [data, setData] = useState<Dashboard | null>(null); const [error, setError] = useState(""); const [notice, setNotice] = useState("");
  const [title, setTitle] = useState(""); const [description, setDescription] = useState(""); const [productType, setProductType] = useState("physical"); const [price, setPrice] = useState("1000"); const [stock, setStock] = useState("");
  const [storeVisibility, setStoreVisibility] = useState("private"); const [businessDescription, setBusinessDescription] = useState(""); const [busy, setBusy] = useState(false);
  async function load() {
    const response = await fetch(`/api/customer/businesses/${params.id}`, { cache: "no-store" });
    const result = await response.json(); if (!response.ok) throw new Error(result.error || "Business dashboard unavailable.");
    setData(result.dashboard); setStoreVisibility(result.dashboard.company.businessProfile?.visibility || "private"); setBusinessDescription(result.dashboard.company.businessProfile?.description || "");
  }
  useEffect(() => { load().catch(e => setError(e.message)); }, [params.id]);
  async function addProduct(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const response = await fetch(`/api/customer/businesses/${params.id}/products`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ title, description, productType, priceMinor: Number(price), stockQuantity: stock === "" ? null : Number(stock) }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error || "Product could not be saved.");
      setTitle(""); setDescription(""); setNotice(result.message); await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Product could not be saved."); }
    finally { setBusy(false); }
  }
  async function submitReview(productId: string) {
    setBusy(true); setError(""); setNotice("");
    try {
      const response = await fetch(`/api/customer/businesses/${params.id}/products/${productId}`, { method: "PATCH" });
      const result = await response.json(); if (!response.ok) throw new Error(result.error || "Could not submit product.");
      setNotice(result.message); await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Could not submit product."); }
    finally { setBusy(false); }
  }
  async function saveStore(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const response = await fetch(`/api/customer/businesses/${params.id}/profile`, { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ description: businessDescription, visibility: storeVisibility }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error || "Store settings could not be saved.");
      setNotice(storeVisibility === "public" ? "Your public storefront is now visible to customers." : "Your storefront is private."); await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Store settings could not be saved."); }
    finally { setBusy(false); }
  }
  if (!data) return <main style={wrap}><Link href="/customer" style={link}>← Customer HQ</Link><p>{error || "Loading your CEO dashboard…"}</p></main>;
  return <main style={wrap}>
    <header style={header}><div><Link href="/customer" style={link}>← Your Business HQ</Link><p style={eyebrow}>CUSTOMER CEO DASHBOARD</p><h1>{data.company.name}</h1><p style={muted}>Private business workspace · {data.company.slug}</p></div><Link href={`/store/${data.company.businessProfile?.handle || data.company.slug}`} style={link}>View storefront →</Link></header>
    {notice && <p role="status" style={noticeBox}>{notice}</p>}{error && <p role="alert" style={errorBox}>{error}</p>}
    <section style={stats}>
      <article style={stat}><strong>{data.products.length}</strong><span>Products</span></article>
      <article style={stat}><strong>{data.orders.length}</strong><span>Orders recorded</span></article>
      <article style={stat}><strong>{money(data.confirmedSellerProceedsMinor)}</strong><span>Confirmed transfers / payouts</span></article>
      <article style={stat}><strong>{money(data.pendingSellerProceedsMinor)}</strong><span>Awaiting provider settlement</span></article>
      <article style={stat}><strong>{data.sellerAccount?.payoutsEnabled ? "Enabled" : "Not connected"}</strong><span>Seller payouts</span></article>
    </section>
    <section style={panel}>
      <h2 style={{ marginTop: 0 }}>Your storefront</h2>
      <form onSubmit={saveStore} style={form}>
        <label>Store description<textarea style={field} rows={3} maxLength={2000} value={businessDescription} onChange={e => setBusinessDescription(e.target.value)} /></label>
        <label>Store visibility<select style={field} value={storeVisibility} onChange={e => setStoreVisibility(e.target.value)}><option value="private">Private — only your business team</option><option value="public">Public — show approved products to customers</option></select></label>
        <button style={primary} disabled={busy}>Save storefront settings</button>
      </form>
      <p style={muted}>Your store URL: /store/{data.company.businessProfile?.handle || data.company.slug}. Products only appear publicly after CEO Headquarters review.</p>
    </section>
    <section style={panel}>
      <h2 style={{ marginTop: 0 }}>Add a product or service</h2>
      <form onSubmit={addProduct} style={form}>
        <label>Product / service name<input style={field} required minLength={2} maxLength={120} value={title} onChange={e => setTitle(e.target.value)} /></label>
        <label>Description<textarea style={field} required minLength={10} maxLength={4000} rows={3} value={description} onChange={e => setDescription(e.target.value)} /></label>
        <label>Type<select style={field} value={productType} onChange={e => setProductType(e.target.value)}><option value="physical">Physical product</option><option value="digital">Digital product</option><option value="service">Service</option></select></label>
        <label>Price in pence (e.g. £19.99 = 1999)<input style={field} type="number" min="1" step="1" required value={price} onChange={e => setPrice(e.target.value)} /></label>
        {productType === "physical" && <label>Stock quantity (optional)<input style={field} type="number" min="0" step="1" value={stock} onChange={e => setStock(e.target.value)} /></label>}
        <button style={primary} disabled={busy}>Save product draft</button>
      </form>
    </section>
    <section style={panel}>
      <h2 style={{ marginTop: 0 }}>Your products</h2>
      {data.products.length === 0 ? <p style={muted}>No products yet.</p> : <div style={list}>{data.products.map(product => <article key={product.id} style={row}><div><strong>{product.title}</strong><p style={muted}>{product.productType} · {money(product.priceMinor, product.currency)} · {product.status}</p></div>{product.status === "draft" && <button style={secondary} disabled={busy} onClick={() => submitReview(product.id)}>Submit for review</button>}</article>)}</div>}
    </section>
    <section style={panel}>
      <h2 style={{ marginTop: 0 }}>Orders and seller proceeds</h2>
      <p style={muted}>Customer purchases and payouts are not active until a regulated marketplace payment provider is connected, seller verification is completed and signed payment webhooks are tested.</p>
      {data.orders.length === 0 ? <p style={muted}>No customer orders have been recorded.</p> : <div style={list}>{data.orders.map(order => <article key={order.id} style={row}><div><strong>Order {order.id.slice(0,8)} · {order.status}</strong><p style={muted}>{order.items.map(i => `${i.titleSnapshot} × ${i.quantity}`).join(", ")}</p></div><div><strong>{money(order.subtotalMinor, order.currency)}</strong><p style={muted}>Seller net: {money(order.sellerNetMinor, order.currency)}</p></div></article>)}</div>}
      <div style={{ marginTop: 18, padding: 16, borderRadius: 12, background: "#0b1020" }}><strong>Seller account: {data.sellerAccount?.onboardingStatus || "Not started"}</strong><p style={muted}>Payments owed will be calculated from verified successful transactions, less clearly disclosed platform fees, refunds and disputes. This dashboard does not fabricate available balances or mark unconfirmed payouts as paid.</p></div>
    </section>
  </main>;
}
const wrap: React.CSSProperties = { maxWidth: 1100, margin: "0 auto", padding: "30px 22px 80px", color: "#eef2ff" };
const header: React.CSSProperties = { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 20, flexWrap: "wrap", marginBottom: 20 };
const panel: React.CSSProperties = { background: "#121a30", border: "1px solid #26314d", borderRadius: 18, padding: 24, marginTop: 18 };
const muted: React.CSSProperties = { color: "#aeb9d3", lineHeight: 1.6 };
const eyebrow: React.CSSProperties = { color: "#a78bfa", fontSize: 11, letterSpacing: ".15em", fontWeight: 800 };
const link: React.CSSProperties = { color: "#c4b5fd", fontWeight: 700, textDecoration: "none" };
const form: React.CSSProperties = { display: "grid", gap: 13, maxWidth: 680 };
const field: React.CSSProperties = { display: "block", boxSizing: "border-box", width: "100%", marginTop: 7, padding: 12, borderRadius: 9, border: "1px solid #35405d", background: "#0b1020", color: "#fff" };
const primary: React.CSSProperties = { border: 0, borderRadius: 10, background: "#8b5cf6", color: "white", padding: 14, fontWeight: 800, cursor: "pointer" };
const secondary: React.CSSProperties = { border: "1px solid #6d5aa6", borderRadius: 9, background: "#201a38", color: "#ddd6fe", padding: "9px 12px" };
const stats: React.CSSProperties = { display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(170px,1fr))", gap: 12, marginTop: 20 };
const stat: React.CSSProperties = { display: "grid", gap: 6, background: "#121a30", border: "1px solid #26314d", borderRadius: 14, padding: 18 };
const list: React.CSSProperties = { display: "grid", gap: 10 };
const row: React.CSSProperties = { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, flexWrap: "wrap", borderBottom: "1px solid #26314d", padding: "12px 0" };
const noticeBox: React.CSSProperties = { padding: 12, background: "#123c35", borderRadius: 10 };
const errorBox: React.CSSProperties = { padding: 12, background: "#451a25", borderRadius: 10, color: "#fecaca" };
