"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
type Order={id:string;status:string;subtotalMinor:number;currency:string;createdAt:string;paidAt:string|null;sellerCompany:{name:string};items:{titleSnapshot:string;quantity:number;lineTotalMinor:number}[]};
const money=(n:number,c:string)=>new Intl.NumberFormat("en-GB",{style:"currency",currency:c}).format(n/100);
export default function CustomerOrders(){
 const [orders,setOrders]=useState<Order[]>([]);const [error,setError]=useState("");
 useEffect(()=>{fetch("/api/customer/orders",{cache:"no-store"}).then(async r=>{const d=await r.json();if(!r.ok)throw new Error(d.error||"Order history unavailable.");setOrders(d.orders||[]);}).catch(e=>setError(e.message));},[]);
 return <main style={wrap}><Link href="/customer" style={link}>← Your Business HQ</Link><h1>My purchases</h1><p style={muted}>Your orders across Business Empire websites and customer-owned storefronts.</p>{error&&<p role="alert">{error}</p>}{orders.length===0?<p style={muted}>No purchases have been recorded yet. Marketplace checkout is waiting for payment-provider activation.</p>:orders.map(o=><article key={o.id} style={card}><strong>Order {o.id.slice(0,8)} · {o.status}</strong><p style={muted}>Seller: {o.sellerCompany.name} · {new Date(o.createdAt).toLocaleDateString("en-GB")}</p><p>{o.items.map(i=>`${i.titleSnapshot} × ${i.quantity}`).join(", ")}</p><strong>{money(o.subtotalMinor,o.currency)}</strong></article>)}</main>;
}
const wrap:React.CSSProperties={maxWidth:900,margin:"0 auto",padding:"36px 22px 80px",color:"#eef2ff"};const link:React.CSSProperties={color:"#c4b5fd",fontWeight:700};const muted:React.CSSProperties={color:"#aeb9d3",lineHeight:1.6};const card:React.CSSProperties={background:"#121a30",border:"1px solid #26314d",borderRadius:16,padding:20,marginTop:14};
