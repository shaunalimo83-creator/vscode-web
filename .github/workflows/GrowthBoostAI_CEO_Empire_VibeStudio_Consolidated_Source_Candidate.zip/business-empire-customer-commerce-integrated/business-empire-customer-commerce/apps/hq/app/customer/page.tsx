"use client";
import Link from "next/link";
import { useEffect, useState } from "react";

type Business = { id: string; slug: string; name: string; businessProfile?: { handle: string; visibility: string } | null };
type Account = { user: { id: string; email: string; displayName: string }; profile: { handle: string; displayName: string; bio: string; visibility: string; allowConnections: boolean } | null; businesses: Business[] };
type Connection = { id: string; status: string; requesterUserId: string; recipientUserId: string; requester: { customerProfile: { handle: string; displayName: string } | null }; recipient: { customerProfile: { handle: string; displayName: string } | null } };

export default function CustomerBusinessHQ() {
  const [account, setAccount] = useState<Account | null>(null);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [mode, setMode] = useState<"login" | "register">("register");
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState(""); const [mfaCode, setMfaCode] = useState("");
  const [recoveryCode, setRecoveryCode] = useState(""); const [termsAccepted, setTermsAccepted] = useState(false); const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const [businessName, setBusinessName] = useState(""); const [businessDescription, setBusinessDescription] = useState("");
  const [profileName, setProfileName] = useState(""); const [bio, setBio] = useState("");
  const [visibility, setVisibility] = useState("public"); const [allowConnections, setAllowConnections] = useState(true);
  const [notice, setNotice] = useState(""); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);

  async function load() {
    const response = await fetch("/api/customer/me", { cache: "no-store" });
    if (!response.ok) { setAccount(null); return; }
    const data = await response.json(); setAccount(data);
    const connectionResponse = await fetch("/api/customer/connections", { cache: "no-store" });
    if (connectionResponse.ok) { const connectionData = await connectionResponse.json(); setConnections(connectionData.connections || []); }
    setEmail(data.user.email); setProfileName(data.profile?.displayName || data.user.displayName);
    setBio(data.profile?.bio || ""); setVisibility(data.profile?.visibility || "public");
    setAllowConnections(data.profile?.allowConnections ?? true);
  }
  useEffect(() => { load().catch(() => setError("Customer HQ is temporarily unavailable.")); }, []);

  async function authenticate(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const endpoint = mode === "register" ? "/api/customer/auth/register" : "/api/customer/auth/login";
      const payload = mode === "register" ? { email, password, displayName, termsAccepted, privacyAccepted } : { email, password, mfaCode, recoveryCode };
      const response = await fetch(endpoint, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Account request failed.");
      if (mode === "register") setNotice("Account request received. Check your email and verify your address before signing in.");
      else { await load(); setNotice("Welcome to your Customer Business HQ."); }
    } catch (e) { setError(e instanceof Error ? e.message : "Account request failed."); }
    finally { setBusy(false); }
  }
  async function createBusiness(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const response = await fetch("/api/customer/businesses", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: businessName, description: businessDescription }) });
      const data = await response.json(); if (!response.ok) throw new Error(data.error || "Business could not be created.");
      setBusinessName(""); setBusinessDescription(""); setNotice(data.message); await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Business could not be created."); }
    finally { setBusy(false); }
  }
  async function saveProfile(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const response = await fetch("/api/customer/profile", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ displayName: profileName, bio, visibility, allowConnections }) });
      const data = await response.json(); if (!response.ok) throw new Error(data.error || "Profile could not be saved.");
      setNotice("Personal profile saved."); await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Profile could not be saved."); }
    finally { setBusy(false); }
  }
  async function respondConnection(id: string, status: "accepted" | "declined") {
    const response = await fetch("/api/customer/connections", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ id, status }) });
    if (!response.ok) { setError("Could not update connection request."); return; }
    await load();
  }
  async function signOut() { await fetch("/api/customer/auth/logout", { method: "POST" }); setAccount(null); setConnections([]); setNotice("You have signed out."); }

  return <main style={wrap}>
    <header style={header}><div><p style={eyebrow}>BUSINESS EMPIRE · CUSTOMER HEADQUARTERS</p><h1 style={{ margin: "8px 0" }}>Your Business HQ</h1><p style={muted}>Your personal account, your businesses, your products and your own CEO dashboards.</p></div><nav style={nav}><Link href="/marketplace" style={link}>Marketplace</Link><Link href="/customer/orders" style={link}>My purchases</Link><a href={process.env.NEXT_PUBLIC_VIBE_PLATFORM_URL ?? "http://localhost:3008"} style={link}>Vibe Studio</a>{account && <button onClick={signOut} style={quiet}>Sign out</button>}</nav></header>
    {notice && <p role="status" style={noticeStyle}>{notice}</p>}{error && <p role="alert" style={errorStyle}>{error}</p>}
    {!account ? <section style={panel}>
      <div style={tabs}><button style={mode === "register" ? tabActive : tab} onClick={() => setMode("register")}>Create customer account</button><button style={mode === "login" ? tabActive : tab} onClick={() => setMode("login")}>Sign in</button></div>
      <form onSubmit={authenticate} style={form}>
        {mode === "register" && <label>Your name<input style={field} required minLength={2} maxLength={60} value={displayName} onChange={e => setDisplayName(e.target.value)} /></label>}
        <label>Email address<input style={field} type="email" required value={email} onChange={e => setEmail(e.target.value)} /></label>
        <label>Password<input style={field} type="password" required minLength={12} value={password} onChange={e => setPassword(e.target.value)} /></label>
        {mode === "login" && <><label>Authenticator code (if enabled)<input style={field} inputMode="numeric" value={mfaCode} onChange={e => setMfaCode(e.target.value)} /></label><label>Or one-time recovery code<input style={field} value={recoveryCode} onChange={e => setRecoveryCode(e.target.value)} /></label></>}
        {mode === "register" && <><label style={check}><input type="checkbox" required checked={termsAccepted} onChange={e => setTermsAccepted(e.target.checked)} /> I agree to the <a href="/legal/terms" style={link}>Terms of Service</a>.</label><label style={check}><input type="checkbox" required checked={privacyAccepted} onChange={e => setPrivacyAccepted(e.target.checked)} /> I acknowledge the <a href="/legal/privacy" style={link}>Privacy Policy</a>.</label></>}
        <button style={primary} disabled={busy || (mode === "register" && (!termsAccepted || !privacyAccepted))}>{busy ? "Please wait…" : mode === "register" ? "Create my account" : "Sign in to Customer HQ"}</button>
      </form>
      <p style={muted}>Email verification is required. Use a strong, unique password. Registration remains disabled until the platform email and security settings are configured.</p>
    </section> : <>
      <section style={panel}>
        <h2 style={{ marginTop: 0 }}>Welcome, {account.user.displayName}</h2><p style={muted}>{account.user.email} · Personal customer account</p>
        <div style={grid}>
          <article style={stat}><strong>{account.businesses.length}</strong><span>Businesses you own</span></article>
          <article style={stat}><strong>{account.profile?.handle ? "@" + account.profile.handle : "Not set"}</strong><span>Personal profile</span></article>
          <article style={stat}><strong>GBP</strong><span>Default business currency</span></article>
        </div>
      </section>
      <section style={panel}>
        <h2 style={{ marginTop: 0 }}>Your personal profile</h2>
        <form onSubmit={saveProfile} style={form}>
          <label>Display name<input style={field} value={profileName} onChange={e => setProfileName(e.target.value)} required minLength={2} maxLength={60} /></label>
          <label>About you<textarea style={field} rows={3} value={bio} onChange={e => setBio(e.target.value)} maxLength={500} /></label>
          <label>Profile visibility<select style={field} value={visibility} onChange={e => setVisibility(e.target.value)}><option value="public">Public — other customers can find and view it</option><option value="private">Private — only you can view it</option></select></label>
          <label style={check}><input type="checkbox" checked={allowConnections} onChange={e => setAllowConnections(e.target.checked)} /> Allow connection requests from other customers</label>
          <button style={primary} disabled={busy}>Save personal profile</button>
        </form>
        {account.profile?.handle && <p style={muted}>Share your profile: <a style={link} href={`/profiles/${account.profile.handle}`}>/profiles/{account.profile.handle}</a></p>}
      </section>
      <section style={panel}>
        <h2 style={{ marginTop: 0 }}>Customer connections</h2>
        {connections.length === 0 ? <p style={muted}>No connection requests or connections yet. Share your public profile so other customers can find you.</p> : <div style={form}>{connections.map(c => {
          const incoming = c.recipientUserId === account.user.id;
          const person = (incoming ? c.requester.customerProfile?.displayName : c.recipient.customerProfile?.displayName) || "Customer";
          return <article key={c.id} style={businessCard}><strong>{person}</strong><p style={muted}>Connection status: {c.status}</p>{c.status === "pending" && incoming && <div style={{display:"flex",gap:8}}><button style={primary} onClick={() => respondConnection(c.id,"accepted")}>Accept</button><button style={quiet} onClick={() => respondConnection(c.id,"declined")}>Decline</button></div>}</article>;
        })}</div>}
      </section>
      <section style={panel}>
        <h2 style={{ marginTop: 0 }}>Your businesses and CEO dashboards</h2>
        {account.businesses.length === 0 ? <p style={muted}>You have not created a business yet. Create your first business below to open its own dashboard.</p> : <div style={grid}>{account.businesses.map(b => <article key={b.id} style={businessCard}><p style={eyebrow}>CUSTOMER-OWNED BUSINESS</p><h3>{b.name}</h3><p style={muted}>Private business workspace · {b.businessProfile?.visibility || "private"} storefront</p><Link href={`/customer/businesses/${b.id}`} style={link}>Open my CEO dashboard →</Link></article>)}</div>}
        <form onSubmit={createBusiness} style={{ ...form, marginTop: 22 }}>
          <h3>Create another business</h3>
          <label>Business name<input style={field} required minLength={2} maxLength={100} value={businessName} onChange={e => setBusinessName(e.target.value)} placeholder="Your business name" /></label>
          <label>What does your business do?<textarea style={field} rows={3} maxLength={2000} value={businessDescription} onChange={e => setBusinessDescription(e.target.value)} placeholder="Describe your products or services…" /></label>
          <button style={primary} disabled={busy}>Create my business dashboard</button>
        </form>
      </section>
    </>}
  </main>;
}
const wrap: React.CSSProperties = { maxWidth: 1100, margin: "0 auto", padding: "30px 22px 80px", color: "#eef2ff" };
const header: React.CSSProperties = { display: "flex", justifyContent: "space-between", gap: 20, flexWrap: "wrap", marginBottom: 28 };
const nav: React.CSSProperties = { display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" };
const panel: React.CSSProperties = { background: "#121a30", border: "1px solid #26314d", borderRadius: 18, padding: 24, marginTop: 18 };
const muted: React.CSSProperties = { color: "#aeb9d3", lineHeight: 1.6 };
const eyebrow: React.CSSProperties = { color: "#a78bfa", fontSize: 11, letterSpacing: ".15em", fontWeight: 800 };
const link: React.CSSProperties = { color: "#c4b5fd", fontWeight: 700, textDecoration: "none" };
const form: React.CSSProperties = { display: "grid", gap: 14, maxWidth: 680 };
const field: React.CSSProperties = { display: "block", boxSizing: "border-box", width: "100%", marginTop: 7, padding: 12, borderRadius: 9, border: "1px solid #35405d", background: "#0b1020", color: "#fff" };
const primary: React.CSSProperties = { border: 0, borderRadius: 10, background: "#8b5cf6", color: "white", padding: 14, fontWeight: 800, cursor: "pointer" };
const quiet: React.CSSProperties = { border: "1px solid #35405d", borderRadius: 9, background: "transparent", color: "#e5e7eb", padding: "8px 12px" };
const tabs: React.CSSProperties = { display: "flex", gap: 8, marginBottom: 18 };
const tab: React.CSSProperties = { border: "1px solid #35405d", borderRadius: 9, padding: "10px 14px", background: "transparent", color: "#cbd5e1" };
const tabActive: React.CSSProperties = { ...tab, background: "#312e81", color: "white" };
const grid: React.CSSProperties = { display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 14 };
const stat: React.CSSProperties = { display: "grid", gap: 5, padding: 16, borderRadius: 12, background: "#0b1020" };
const businessCard: React.CSSProperties = { padding: 18, borderRadius: 14, border: "1px solid #35405d", background: "#0d1428" };
const check: React.CSSProperties = { display: "flex", gap: 10, alignItems: "center", color: "#cbd5e1" };
const noticeStyle: React.CSSProperties = { padding: 12, background: "#123c35", borderRadius: 10 };
const errorStyle: React.CSSProperties = { padding: 12, background: "#451a25", borderRadius: 10, color: "#fecaca" };
