"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
export default function VerifyCustomerEmail(){
 const [message,setMessage]=useState("Verifying your email…");const [error,setError]=useState("");
 useEffect(()=>{const token=new URLSearchParams(window.location.search).get("token")||"";fetch("/api/customer/auth/verify",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({token})}).then(async r=>{const d=await r.json();if(!r.ok)throw new Error(d.error||"Verification failed.");setMessage(d.message);}).catch(e=>setError(e.message));},[]);
 return <main style={{maxWidth:560,margin:"12vh auto",padding:24,color:"#eef2ff"}}><h1>Email verification</h1><p role={error?"alert":"status"}>{error||message}</p><Link href="/customer" style={{color:"#c4b5fd"}}>Continue to Customer Business HQ</Link></main>;
}
