const CONTENT = `# Business Empire Customer Privacy Notice

DRAFT TEMPLATE — this notice must be reviewed by qualified UK data-protection counsel and completed with the correct legal controller details before customer registration is enabled.

Business Empire uses a shared customer account across its seven business websites and Customer Business HQ. Account information may include email address, password hash, email-verification status, security/session records, personal profile details, business membership, products, orders, customer support records and consent history.

Customers control whether their personal profile and business storefront are public or private. Public profile and storefront APIs disclose only the fields selected for public display. Private business records, orders, financial records and team data are restricted by business membership and access controls.

Marketplace payments and seller payouts are not active in this release. If activated later, payment processing and seller verification will be provided through an appropriately regulated payment service provider. Payment provider terms and privacy notices will also apply.

Before launch, the controller identity and contact details, lawful bases, retention periods, data-subject rights, complaint route, international transfers, processors, cookies, security contact and deletion/export process must be completed here. Customers remain responsible for their own tax obligations.
`;

export default function PrivacyPage() {
  return <main style={{ maxWidth: 860, margin: "40px auto", padding: 24, fontFamily: "system-ui", whiteSpace: "pre-wrap" }}><pre style={{ whiteSpace: "pre-wrap", fontFamily: "inherit" }}>{CONTENT}</pre></main>;
}
