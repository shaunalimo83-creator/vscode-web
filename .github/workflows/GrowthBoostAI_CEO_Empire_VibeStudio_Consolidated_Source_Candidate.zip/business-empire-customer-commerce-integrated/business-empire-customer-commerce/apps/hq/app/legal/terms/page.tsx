const CONTENT = `# Business Empire Customer Terms

DRAFT TEMPLATE — this document must be reviewed by qualified legal counsel and completed with the correct legal entity, jurisdiction, pricing, cancellation and consumer-rights information before customer registration is enabled.

These terms are intended to govern customer access to Business Empire websites, Customer Business HQ, personal profiles, customer-created business workspaces, website-building tools and marketplace features.

Customers must provide accurate account information, protect their credentials, respect other users' privacy and intellectual-property rights, and comply with applicable laws and the policies of each business service. Customers are responsible for the products, services, descriptions, fulfilment, refunds, tax and legal obligations of their own businesses.

Public profiles and storefronts are controlled by customer visibility settings. Product listings may be reviewed by Business Empire before publication. A listing being published does not mean Business Empire guarantees the product, seller or transaction.

Marketplace checkout, seller onboarding and payouts are not active in this release. They must not be advertised as available until an approved payment provider, seller verification, refunds/disputes, settlement and payout processes are operational.

Before launch, complete the contracting legal entity, contact details, jurisdiction, subscription prices, renewal/cancellation terms, refund rules, platform fees, acceptable-use rules, content policies, dispute resolution, consumer rights, liability limits and termination procedures.
`;

export default function TermsPage() {
  return <main style={{ maxWidth: 860, margin: "40px auto", padding: 24, fontFamily: "system-ui", whiteSpace: "pre-wrap" }}><pre style={{ whiteSpace: "pre-wrap", fontFamily: "inherit" }}>{CONTENT}</pre></main>;
}
