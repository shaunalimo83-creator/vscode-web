"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
type Profile={handle:string;displayName:string;bio:string;avatarUrl:string|null;visibility:string;allowConnections:boolean};
export default function ProfilePage({params}:{params:{handle:string}}){
 const [profile,setProfile]=useState<Profile|null>(null);const [businesses,setBusinesses]=useState<{handle:string;displayName:string;description:string}[]>([]);const [notice,setNotice]=useState("");const [error,setError]=useState("");
 useEffect(()=>{fetch(`/api/profiles/${encodeURIComponent(params.handle)}`,{cache:"no-store"}).then(async r=>{const d=await r.json();if(!r.ok)throw new Error("Profile not found or private.");setProfile(d.profile);setBusinesses(d.businesses||[]);}).catch(e=>setError(e.message));},[params.handle]);
 async function connect(){const r=await fetch(`/api/profiles/${encodeURIComponent(params.handle)}/connect`,{method:"POST"});const d=await r.json();setNotice(r.ok?"Connection request sent.":d.error||"Sign in to connect.");}
 if(!profile)return <main style={wrap}><Link href="/customer" style={link}>Customer HQ</Link><p>{error||"Loading profile…"}</p></main>;
 return <main style={wrap}><Link href="/customer" style={link}>← Customer HQ</Link><section style={card}><p style={eyebrow}>CUSTOMER PROFILE</p><h1>{profile.displayName}</h1><p style={muted}>@{profile.handle}</p><p>{profile.bio}</p>{profile.visibility === "public" && profile.allowConnections && <button style={button} onClick={connect}>Connect</button>}{notice&&<p role="status">{notice}</p>}</section><h2>Public businesses</h2>{businesses.map(b=><article key={b.handle} style={card}><h3>{b.displayName}</h3><p style={muted}>{b.description}</p><Link href={`/store/${b.handle}`} style={link}>Visit storefront →</Link></article>)}</main>;
}
const wrap:React.CSSProperties={maxWidth:900,margin:"0 auto",padding:"36px 22px 80px",color:"#eef2ff"};const card:React.CSSProperties={background:"#121a30",border:"1px solid #26314d",borderRadius:16,padding:24,marginTop:16};const link:React.CSSProperties={color:"#c4b5fd",fontWeight:700};const muted:React.CSSProperties={color:"#aeb9d3"};const eyebrow:React.CSSProperties={color:"#a78bfa",fontSize:11,letterSpacing:".14em",fontWeight:800};const button:React.CSSProperties={border:0,borderRadius:9,background:"#8b5cf6",color:"#fff",padding:"10px 16px",fontWeight:700};
