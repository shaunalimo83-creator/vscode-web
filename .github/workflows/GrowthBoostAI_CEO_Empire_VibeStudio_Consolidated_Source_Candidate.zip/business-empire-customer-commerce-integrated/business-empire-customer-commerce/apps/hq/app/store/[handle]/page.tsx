"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
type Store={handle:string;displayName:string;description:string;websiteUrl:string|null;products:{id:string;title:string;description:string;productType:string;priceMinor:number;currency:string}[]};
const money=(n:number,c:string)=>new Intl.NumberFormat("en-GB",{style:"currency",currency:c}).format(n/100);
export default function StorePage({params}:{params:{handle:string}}){
 const [store,setStore]=useState<Store|null>(null);const [error,setError]=useState("");
 useEffect(()=>{fetch(`/api/store/${encodeURIComponent(params.handle)}`,{cache:"no-store"}).then(async r=>{const d=await r.json();if(!r.ok)throw new Error(d.error||"Store unavailable.");setStore(d.store);}).catch(e=>setError(e.message));},[params.handle]);
 if(!store)return <main style={wrap}><Link href="/marketplace" style={link}>← Marketplace</Link><p>{error||"Loading storefront…"}</p></main>;
 return <main style={wrap}><Link href="/marketplace" style={link}>← Marketplace</Link><p style={eyebrow}>BUSINESS EMPIRE STOREFRONT</p><h1>{store.displayName}</h1><p style={muted}>{store.description}</p>{store.websiteUrl&&<p><a href={store.websiteUrl} style={link} target="_blank" rel="noreferrer">Business website ↗</a></p>}<h2>Products and services</h2>{store.products.length===0?<p style={muted}>No approved products are available yet.</p>:<div style={grid}>{store.products.map(p=><article key={p.id} style={card}><h3>{p.title}</h3><p style={muted}>{p.description}</p><strong>{money(p.priceMinor,p.currency)}</strong><p style={muted}>Purchases will be enabled when marketplace checkout is activated.</p></article>)}</div>}</main>;
}
const wrap:React.CSSProperties={maxWidth:1000,margin:"0 auto",padding:"36px 22px 80px",color:"#eef2ff"};const link:React.CSSProperties={color:"#c4b5fd",fontWeight:700};const muted:React.CSSProperties={color:"#aeb9d3",lineHeight:1.6};const eyebrow:React.CSSProperties={color:"#a78bfa",fontSize:11,letterSpacing:".14em",fontWeight:800};const grid:React.CSSProperties={display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))",gap:14};const card:React.CSSProperties={background:"#121a30",border:"1px solid #26314d",borderRadius:16,padding:20};
