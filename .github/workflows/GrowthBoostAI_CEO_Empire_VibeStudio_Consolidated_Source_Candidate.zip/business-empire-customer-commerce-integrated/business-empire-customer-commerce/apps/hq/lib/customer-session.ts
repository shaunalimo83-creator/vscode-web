import { cookies } from "next/headers";
import { prisma } from "@empire/db";
import type { Prisma } from "@prisma/client";
import { sha256 } from "@empire/core";

export const CUSTOMER_SESSION_COOKIE = "empire_customer_session";
export type CustomerSession = {
  userId: string;
  email: string;
  displayName: string;
  handle: string;
};

export async function getCustomerSession(): Promise<CustomerSession | null> {
  const token = cookies().get(CUSTOMER_SESSION_COOKIE)?.value;
  if (!token || token.length < 32 || token.length > 256) return null;
  try {
    const session = await prisma.session.findUnique({
      where: { tokenHash: sha256(token) },
      select: { userId: true, expiresAt: true, revokedAt: true, user: { select: { email: true, isActive: true, emailVerifiedAt: true } } },
    });
    if (!session || session.revokedAt || session.expiresAt <= new Date() || !session.user.isActive || !session.user.emailVerifiedAt) return null;
    return await prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      const profile = await tx.customerProfile.findUnique({
        where: { userId: session.userId },
        select: { displayName: true, handle: true },
      });
      return {
        userId: session.userId,
        email: session.user.email,
        displayName: profile?.displayName || session.user.email.split("@")[0],
        handle: profile?.handle || "",
      };
    });
  } catch {
    return null;
  }
}

export async function withCustomerBusiness<T>(
  session: CustomerSession,
  companyId: string,
  run: (context: { tx: Prisma.TransactionClient; companyId: string }) => Promise<T>,
): Promise<{ ok: true; value: T } | { ok: false; status: 403 | 503; error: string }> {
  try {
    return await prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      const membership = await tx.userCompany.findFirst({
        where: { userId: session.userId, companyId, role: "business_owner", company: { kind: "customer", status: "active" } },
        select: { companyId: true },
      });
      if (!membership) return { ok: false, status: 403, error: "business_owner_access_required" } as const;
      await tx.$queryRaw`SELECT set_config('app.company_id', ${membership.companyId}, true)`;
      const value = await run({ tx, companyId: membership.companyId });
      return { ok: true, value } as const;
    });
  } catch {
    return { ok: false, status: 503, error: "customer_business_service_unavailable" };
  }
}
