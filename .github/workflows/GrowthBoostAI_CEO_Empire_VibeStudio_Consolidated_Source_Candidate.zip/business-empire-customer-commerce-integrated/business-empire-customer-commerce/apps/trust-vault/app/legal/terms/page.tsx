const CONTENT = "# Terms of service — Trust Vault Bank\n\n> TEMPLATE — must be reviewed by qualified counsel before production use.\n\nThese terms govern use of Trust Vault Bank services. Liability limits, cancellation and refund rights, service levels and dispute resolution are documented here before go-live.";

export default function LegalPage() {
  return <main style={{ padding: 24, whiteSpace: "pre-wrap", fontFamily: "system-ui" }}><pre style={{ whiteSpace: "pre-wrap", fontFamily: "inherit" }}>{CONTENT}</pre></main>;
}
