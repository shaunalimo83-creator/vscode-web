import { getVibeSession } from "../../../../lib/auth";
import { NO_STORE } from "../../../../lib/security";

export async function GET() {
  const session = await getVibeSession();
  if (!session) return Response.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const businesses = session.memberships
    .filter((membership) => membership.slug !== "hq")
    .map((membership) => ({ slug: membership.slug, name: membership.name, role: membership.role }));
  return Response.json({ user: { email: session.email, isCeo: session.isCeo }, businesses }, { headers: NO_STORE });
}
