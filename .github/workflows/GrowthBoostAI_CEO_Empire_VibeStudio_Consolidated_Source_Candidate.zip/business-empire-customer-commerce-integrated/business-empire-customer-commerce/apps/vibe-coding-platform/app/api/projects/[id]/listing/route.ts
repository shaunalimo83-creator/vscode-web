import { NextResponse } from "next/server";
import { canAccessVibeBusiness, getVibeSession, withVibeTenant } from "../../../../../lib/auth";
import { NO_STORE, rejectVibeOrigin } from "../../../../../lib/security";

export async function POST(request: Request, context: { params: { id: string } }) {
  const blocked = rejectVibeOrigin(request);
  if (blocked) return blocked;
  const session = await getVibeSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const body = await request.json().catch(() => null);
  const target = body?.businessSlug;
  const title = typeof body?.title === "string" ? body.title.trim() : "";
  const description = typeof body?.description === "string" ? body.description.trim() : "";
  const priceMinor = Number(body?.priceMinor);
  if (!canAccessVibeBusiness(session, target) || title.length < 3 || title.length > 100 || description.length < 20 || description.length > 2000 || !Number.isSafeInteger(priceMinor) || priceMinor < 1 || priceMinor > 100_000_000) {
    return NextResponse.json({ error: "valid_listing_details_and_price_in_pence_required" }, { status: 400, headers: NO_STORE });
  }
  const result = await withVibeTenant(session, target, async ({ tx, companyId }) => {
    const project = await tx.vibeProject.findFirst({ where: { id: context.params.id, companyId, ownerUserId: session.userId }, select: { id: true } });
    if (!project) return null;
    return tx.vibeMarketplaceListing.create({
      data: { projectId: project.id, companyId, ownerUserId: session.userId, title, description, priceMinor, currency: "GBP", status: "draft" },
      select: { id: true, title: true, priceMinor: true, currency: true, status: true, createdAt: true },
    });
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers: NO_STORE });
  if (!result.value) return NextResponse.json({ error: "project_not_found_or_not_owned" }, { status: 404, headers: NO_STORE });
  return NextResponse.json({ listing: result.value, notice: "Draft saved. Publication and buyer checkout are disabled until marketplace review, hosting transfer and payment-provider settlement are connected." }, { status: 201, headers: NO_STORE });
}
