import { cookies } from "next/headers";
import { prisma, type TenantContext } from "@empire/db";
import { sha256 } from "@empire/core";
import { VIBE_BUSINESS_TARGETS, isVibeBusinessSlug, type VibeBusinessSlug } from "@empire/core";

export const VIBE_SESSION_COOKIE = "empire_vibe_session";
export const VIBE_BUSINESS_NAMES: Record<VibeBusinessSlug, string> = {
  growthboost: "GrowthBoost AI",
  "ai-magazine": "AI Magazine & Comic Book Studio",
  "trust-vault": "Trust Vault",
  "stock-express": "Stock Market Express",
  "real-estate": "Real Estate Master Developments",
  supergpu: "SUPERGPU UNIVERSAL",
  dailyaccess: "DailyAccess",
};

export type VibeMembership = {
  companyId: string;
  role: string;
  slug: string;
  name: string;
};

export type VibeSession = {
  userId: string;
  email: string;
  isCeo: boolean;
  memberships: VibeMembership[];
};

export async function getVibeSession(): Promise<VibeSession | null> {
  const token = cookies().get(VIBE_SESSION_COOKIE)?.value;
  if (!token || token.length < 32 || token.length > 256) return null;

  try {
    const session = await prisma.session.findUnique({
      where: { tokenHash: sha256(token) },
      select: {
        userId: true,
        expiresAt: true,
        revokedAt: true,
        user: { select: { email: true, isActive: true, emailVerifiedAt: true } },
      },
    });
    if (!session || session.revokedAt || session.expiresAt <= new Date() || !session.user.isActive) return null;

    return await prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      const rows = await tx.userCompany.findMany({
        where: { userId: session.userId },
        select: { companyId: true, role: true, company: { select: { slug: true, name: true, kind: true, status: true } } },
      });
      const memberships = rows
        .filter((row) => (row.company.kind === "customer" && row.company.status === "active")
          || (VIBE_BUSINESS_TARGETS as readonly string[]).includes(row.company.slug)
          || (row.company.slug === "hq" && row.role === "ceo"))
        .map((row) => ({ companyId: row.companyId, role: row.role, slug: row.company.slug, name: row.company.name }));
      const isCeo = memberships.some((row) => row.slug === "hq" && row.role === "ceo");
      if (!session.user.emailVerifiedAt) return null;
      return { userId: session.userId, email: session.user.email, isCeo, memberships };
    });
  } catch {
    return null;
  }
}

/** Re-resolve membership inside the same transaction as the project query/write. */
export async function withVibeTenant<T>(
  session: VibeSession,
  targetBusinessSlug: string,
  run: (context: { tx: TenantContext["tx"]; companyId: string; tenantSlug: string; role: string }) => Promise<T>,
): Promise<{ ok: true; value: T } | { ok: false; status: 403 | 503; error: string }> {
  try {
    return await prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
      let companyId = "";
      let tenantSlug = targetBusinessSlug;
      let role = "";

      if (session.isCeo) {
        const hq = await tx.userCompany.findFirst({
          where: { userId: session.userId, role: "ceo", company: { slug: "hq" } },
          select: { companyId: true, role: true },
        });
        if (!hq) return { ok: false, status: 403, error: "hq_ceo_access_revoked" } as const;
        companyId = hq.companyId;
        tenantSlug = "hq";
        role = hq.role;
      } else {
        const membership = await tx.userCompany.findFirst({
          where: { userId: session.userId, company: { slug: targetBusinessSlug, status: "active" }, role: { in: ["customer", "staff", "admin", "business_owner"] } },
          select: { companyId: true, role: true },
        });
        if (!membership) return { ok: false, status: 403, error: "business_membership_required" } as const;
        companyId = membership.companyId;
        role = membership.role;
      }

      await tx.$queryRaw`SELECT set_config('app.company_id', ${companyId}, true)`;
      const value = await run({ tx, companyId, tenantSlug, role });
      return { ok: true, value } as const;
    });
  } catch {
    return { ok: false, status: 503, error: "vibe_tenant_service_unavailable" };
  }
}

/** Dynamic business access is granted only by an active membership on that exact company. */
export function canAccessVibeBusiness(session: VibeSession, target: unknown): target is string {
  if (typeof target !== "string" || target.length < 1 || target.length > 120) return false;
  if (session.isCeo) return isVibeBusinessSlug(target);
  return session.memberships.some((membership) =>
    membership.slug === target && ["customer", "staff", "admin", "business_owner"].includes(membership.role),
  );
}
