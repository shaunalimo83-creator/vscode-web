# Phase 15 — customer accounts, customer-owned businesses and marketplace foundation

## Customer experience

The seven public business applications now share one customer identity. Registration through any of the seven business sites creates the same `User` identity and provisions a `customer` membership for each active group business. A later login also repairs any missing customer memberships. These memberships do not grant staff, admin, CEO or finance permissions.

CEO Headquarters also contains a separate **Customer Business HQ** portal. It uses the same verified customer identity but a separate HttpOnly session cookie from the group CEO session. Customers can register, verify their email, sign in, edit their personal profile, create multiple businesses and open an individual dashboard for each business.

Customer registration remains disabled by default. Both the customer portal and seven business-site registration forms require explicit Terms and Privacy acknowledgements, which are versioned in `CustomerConsent`. The portal requires `CUSTOMER_REGISTRATION_ENABLED=true`, a configured HTTPS email webhook, current reviewed document versions and `CUSTOMER_HQ_URL`; do not enable public registration until rate limits, email delivery, account recovery and independent security review have been completed.

## Personal and business profiles

- `CustomerProfile` stores a customer's display name, unique public handle, short bio, optional avatar URL, public/private visibility and connection-request preference.
- Public profile APIs return only explicitly selected profile fields and public business links; email addresses and internal account identifiers are not exposed.
- `ProfileConnection` stores connection requests. Only the recipient may accept, decline or block a pending request. Private profile details become visible to accepted connections through RLS.
- `BusinessProfile` stores a customer's public-facing business name, description, public handle, optional website/logo and public/private storefront visibility.
- Customers choose whether to expose a personal profile or storefront. Private profiles and stores are not returned by public lookup APIs.

## Customer-owned businesses and CEO dashboards

`create_customer_business()` is a database function that requires an authenticated `app.user_id` and verified active account. It creates a `Company` with `kind=customer`, assigns the creator the `business_owner` role in `UserCompany`, and creates a private `BusinessProfile`. It uses the normal transaction-local RLS company/user context rather than a general privileged bypass.

CEO Headquarters also has a restricted customer-business directory at `/customer-businesses`, showing business identity and storefront status without exposing private customer financial records.

Every customer-owned business gets its own dashboard under `/customer/businesses/[id]`. The owner can manage its profile/storefront, create products and services, submit product drafts for CEO moderation, view recorded orders and see provider-confirmed/pending seller settlement totals. Membership is checked inside each database transaction. A customer cannot access another customer's business merely by changing a URL or supplying a company ID.

The shared Vibe Coding Platform accepts these customer-owned business memberships as project targets, so a customer can create and manage website projects for each of their own businesses. The account-wide free Vibe plan remains three website projects across the account.

## Marketplace foundation

- `MarketplaceProduct` supports physical goods, digital products and services, with integer minor-unit prices (pence), currency, optional stock and draft/review/published lifecycle.
- Customer owners can create drafts and submit them for review. CEO Headquarters has a moderation queue and can approve/publish or archive submitted products.
- Public marketplace and storefront APIs return only published product metadata. Private product drafts remain tenant/owner scoped.
- `MarketplaceOrder`, `MarketplaceOrderItem` and `MarketplaceSettlement` store buyer/seller references, order state, item snapshots, gross amount, platform fee, seller net proceeds, provider transfer reference, payout reference and settlement state.
- `SellerPaymentAccount` stores only a PSP connected-account reference and capability/onboarding status; it does not store bank credentials or identity documents.
- The shared `MarketplacePaymentProvider` contract defines seller onboarding, checkout, seller transfers and signed webhook verification. It is an interface only: no real PSP adapter is connected in this phase.

## Financial safeguards and current boundary

**Buying and selling are not live yet.** The checkout endpoint deliberately returns HTTP 503 until an appropriate regulated marketplace payment product is configured and verified. Do not collect customer money, mark orders paid, claim seller funds are held in escrow, or mark a payout as paid from an application-side action.

Before enabling payments, implement and test:
1. Provider-hosted seller onboarding and identity/business verification, with jurisdiction and prohibited-business checks.
2. Secure buyer checkout, idempotency, exact seller/platform fee allocation and verified signed webhooks.
3. Seller capability checks before accepting payments, payout schedule disclosure and accurate payout tracking.
4. Refunds, cancellations, disputes, chargebacks, negative balances and seller/customer support workflows.
5. Double-entry ledger posting and reconciliation of gross sales, platform fees, refunds, provider fees, transfers and payouts.
6. Tax reports for gross sales, fees, refunds and payouts; customers remain responsible for their own tax obligations.
7. PostgreSQL RLS integration tests using different buyers, sellers, owners and CEO identities; penetration testing and privacy/legal review.

Use a reputable regulated PSP and an appropriate marketplace product (for example, Stripe Connect only if the provider approves the business model and relevant jurisdictions). Provider contracts determine how funds are routed and safeguarded. Do not call funds escrow unless the provider contract explicitly provides escrow.

## Database and RLS

Migration: `packages/db/prisma/migrations/20261117180000_phase15_customer_business_marketplace/migration.sql`.

It adds customer profile and consent, connection, business profile, product, order, seller account and settlement tables; extends Company with `kind`, `status` and `ownerUserId`; adds the customer-business creation function; and enables/forces RLS on every new profile/marketplace table. Membership insertion is explicitly restricted to `customer` on active group businesses or `business_owner` on a customer business whose `ownerUserId` matches the authenticated user; customers cannot self-assign staff, admin or CEO roles. Company directory reads are limited to the current tenant, the authenticated user's memberships, active group-company directory entries, public storefronts/products, or the CEO identity. Marketplace moderation access is limited to HQ CEO membership.

Apply the migration only after reviewing it against the target PostgreSQL environment. Runtime roles must not own RLS tables and must not have `SUPERUSER` or `BYPASSRLS`. Run real PostgreSQL tests before enabling traffic.

## Verification status

The Phase 15 structural check (`npm run identity:phase15-check`) confirms that the expected schema, migrations, API routes, dashboards, moderation and fail-closed checkout contract exist. It is not proof that the migration has been applied, Prisma has validated the schema, customer registration is live, RLS is secure at runtime, payment settlement works or the platform is production-ready. Full dependency install, type-check, tests, builds, PostgreSQL integration, provider onboarding, webhook and payout reconciliation, browser testing and independent security review remain required.
