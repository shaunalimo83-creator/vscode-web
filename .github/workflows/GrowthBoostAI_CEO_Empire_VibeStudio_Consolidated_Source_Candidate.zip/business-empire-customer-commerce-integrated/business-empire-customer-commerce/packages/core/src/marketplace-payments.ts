/**
 * Marketplace settlement contract. Implementations must use an appropriately
 * regulated PSP marketplace product (for example, a verified Connect product
 * where suitable). No implementation may mark an order paid or a seller payout
 * complete without a verified provider event and reconciliation.
 */
export type MarketplaceCheckoutRequest = {
  orderId: string;
  buyerUserId: string;
  sellerCompanyId: string;
  sellerConnectedAccountRef: string;
  amountMinor: number;
  platformFeeMinor: number;
  sellerNetMinor: number;
  currency: string;
  successUrl: string;
  cancelUrl: string;
};

export type MarketplaceCheckoutSession = {
  provider: string;
  providerRef: string;
  checkoutUrl: string;
  status: "requires_payment" | "processing";
};

export type MarketplaceSellerOnboarding = {
  provider: string;
  connectedAccountRef: string;
  onboardingUrl: string;
  expiresAt: Date;
};

export type MarketplaceTransferResult = {
  providerTransferRef: string;
  providerPayoutRef?: string;
  status: "transferred" | "paid" | "pending";
};

export interface MarketplacePaymentProvider {
  readonly name: string;
  createSellerOnboarding(input: { companyId: string; businessName: string; returnUrl: string; refreshUrl: string }): Promise<MarketplaceSellerOnboarding>;
  createCheckout(input: MarketplaceCheckoutRequest): Promise<MarketplaceCheckoutSession>;
  transferSellerProceeds(input: { orderId: string; connectedAccountRef: string; amountMinor: number; currency: string; idempotencyKey: string }): Promise<MarketplaceTransferResult>;
  verifyWebhook(payload: Buffer, signature: string): boolean;
}

export class MarketplaceProviderNotConnectedError extends Error {
  constructor(provider = "marketplace payment provider") {
    super(`${provider} is not configured and verified for marketplace transactions`);
  }
}
