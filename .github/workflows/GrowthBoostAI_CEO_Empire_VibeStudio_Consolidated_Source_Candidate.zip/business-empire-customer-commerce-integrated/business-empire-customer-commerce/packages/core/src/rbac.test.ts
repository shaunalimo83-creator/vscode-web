import { describe, it, expect } from "vitest";
import { can, requirePermission, PermissionDeniedError, canReadBankingData, type AuthContext } from "./rbac.js";

const ceoCtx: AuthContext = { userId: "u1", memberships: [{ userId: "u1", companyId: "hq", role: "ceo" }] };
const growthAdmin: AuthContext = {
  userId: "u2",
  memberships: [{ userId: "u2", companyId: "growthboost", role: "admin" }],
};
const trustStaff: AuthContext = {
  userId: "u3",
  memberships: [{ userId: "u3", companyId: "trust-vault", role: "staff" }],
};
const customerBusinessOwner: AuthContext = {
  userId: "u4",
  memberships: [{ userId: "u4", companyId: "customer-my-shop", role: "business_owner" }],
};

describe("rbac", () => {
  it("CEO may read consolidated reports at HQ", () => {
    expect(can(ceoCtx, "hq", "cross_company:read_reports")).toBe(true);
    expect(can(ceoCtx, "hq", "reports:export")).toBe(true);
  });

  it("CEO membership cannot be attached to an operating company", () => {
    const sneaky: AuthContext = {
      userId: "u9",
      memberships: [{ userId: "u9", companyId: "growthboost", role: "ceo" }],
    };
    expect(can(sneaky, "growthboost", "reports:read")).toBe(false);
  });

  it("company admin acts inside their company only", () => {
    expect(can(growthAdmin, "growthboost", "billing:write")).toBe(true);
    expect(can(growthAdmin, "real-estate", "billing:write")).toBe(false);
  });

  it("customer business owners administer only their own tenant and never gain cross-company or banking permissions", () => {
    expect(can(customerBusinessOwner, "customer-my-shop", "admin:write")).toBe(true);
    expect(can(customerBusinessOwner, "customer-my-shop", "ledger:read")).toBe(true);
    expect(can(customerBusinessOwner, "customer-my-shop", "customer:banking:read")).toBe(false);
    expect(can(customerBusinessOwner, "growthboost", "admin:write")).toBe(false);
    expect(can(customerBusinessOwner, "customer-my-shop", "cross_company:read_reports")).toBe(false);
  });

  it("staff cannot manage staff or write ledger", () => {
    expect(can(trustStaff, "trust-vault", "customer:read")).toBe(true);
    expect(can(trustStaff, "trust-vault", "staff:manage")).toBe(false);
    expect(can(trustStaff, "trust-vault", "ledger:write")).toBe(false);
  });

  it("unauthenticated / unknown company throws PermissionDeniedError", () => {
    expect(() => requirePermission({ userId: "x", memberships: [] }, "growthboost", "site:read"))
      .toThrow(PermissionDeniedError);
  });

  it("banking data is readable only inside trust-vault by permitted staff — never by HQ", () => {
    expect(canReadBankingData(ceoCtx, "hq")).toBe(false);
    expect(canReadBankingData(growthAdmin, "growthboost")).toBe(false);
    // staff role lacks the banking permission; it would be granted explicitly per user
    expect(canReadBankingData(trustStaff, "trust-vault")).toBe(false);
  });
});
