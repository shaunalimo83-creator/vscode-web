-- Phase 15: platform-wide customer accounts, customer-owned businesses,
-- shareable profiles, storefront products, marketplace orders and settlement records.
-- Payment initiation/transfers remain disabled until a regulated PSP adapter and
-- verified webhook processing are configured.

ALTER TABLE "Company"
  ADD COLUMN "kind" TEXT NOT NULL DEFAULT 'group',
  ADD COLUMN "status" TEXT NOT NULL DEFAULT 'active',
  ADD COLUMN "ownerUserId" TEXT;
ALTER TABLE "Company"
  ADD CONSTRAINT "Company_ownerUserId_fkey"
  FOREIGN KEY ("ownerUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "Company"
  ADD CONSTRAINT "Company_kind_check" CHECK ("kind" IN ('group','customer')),
  ADD CONSTRAINT "Company_status_check" CHECK ("status" IN ('active','pending_review','suspended'));
CREATE INDEX "Company_ownerUserId_idx" ON "Company"("ownerUserId");
CREATE INDEX "Company_kind_status_idx" ON "Company"("kind","status");

CREATE TABLE "CustomerProfile" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "handle" TEXT NOT NULL,
  "displayName" TEXT NOT NULL,
  "bio" TEXT NOT NULL DEFAULT '',
  "avatarUrl" TEXT,
  "visibility" TEXT NOT NULL DEFAULT 'private',
  "allowConnections" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "CustomerProfile_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "CustomerProfile_userId_key" UNIQUE ("userId"),
  CONSTRAINT "CustomerProfile_handle_key" UNIQUE ("handle"),
  CONSTRAINT "CustomerProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "CustomerProfile_visibility_check" CHECK ("visibility" IN ('public','private'))
);
CREATE INDEX "CustomerProfile_visibility_handle_idx" ON "CustomerProfile"("visibility","handle");

CREATE TABLE "CustomerConsent" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "documentType" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "acceptedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "source" TEXT NOT NULL,
  CONSTRAINT "CustomerConsent_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "CustomerConsent_userId_documentType_version_key" UNIQUE ("userId","documentType","version"),
  CONSTRAINT "CustomerConsent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "CustomerConsent_documentType_check" CHECK ("documentType" IN ('terms','privacy'))
);
CREATE INDEX "CustomerConsent_userId_acceptedAt_idx" ON "CustomerConsent"("userId","acceptedAt");
ALTER TABLE "CustomerConsent" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "CustomerConsent" FORCE ROW LEVEL SECURITY;
CREATE POLICY customer_consent_owner_read ON "CustomerConsent" FOR SELECT USING (
  "userId" = NULLIF(current_setting('app.user_id', true), '')
);
CREATE POLICY customer_consent_owner_insert ON "CustomerConsent" FOR INSERT WITH CHECK (
  "userId" = NULLIF(current_setting('app.user_id', true), '')
);

CREATE TABLE "ProfileConnection" (
  "id" TEXT NOT NULL,
  "requesterUserId" TEXT NOT NULL,
  "recipientUserId" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'pending',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ProfileConnection_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ProfileConnection_requesterUserId_recipientUserId_key" UNIQUE ("requesterUserId","recipientUserId"),
  CONSTRAINT "ProfileConnection_requesterUserId_fkey" FOREIGN KEY ("requesterUserId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "ProfileConnection_recipientUserId_fkey" FOREIGN KEY ("recipientUserId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "ProfileConnection_status_check" CHECK ("status" IN ('pending','accepted','declined','blocked')),
  CONSTRAINT "ProfileConnection_not_self_check" CHECK ("requesterUserId" <> "recipientUserId")
);
CREATE INDEX "ProfileConnection_recipientUserId_status_idx" ON "ProfileConnection"("recipientUserId","status");

CREATE TABLE "BusinessProfile" (
  "id" TEXT NOT NULL,
  "companyId" TEXT NOT NULL,
  "displayName" TEXT NOT NULL,
  "description" TEXT NOT NULL DEFAULT '',
  "handle" TEXT NOT NULL,
  "websiteUrl" TEXT,
  "logoUrl" TEXT,
  "visibility" TEXT NOT NULL DEFAULT 'private',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "BusinessProfile_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "BusinessProfile_companyId_key" UNIQUE ("companyId"),
  CONSTRAINT "BusinessProfile_handle_key" UNIQUE ("handle"),
  CONSTRAINT "BusinessProfile_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "BusinessProfile_visibility_check" CHECK ("visibility" IN ('public','private'))
);

CREATE TABLE "MarketplaceProduct" (
  "id" TEXT NOT NULL,
  "companyId" TEXT NOT NULL,
  "sellerUserId" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "productType" TEXT NOT NULL,
  "priceMinor" INTEGER NOT NULL,
  "currency" TEXT NOT NULL DEFAULT 'GBP',
  "stockQuantity" INTEGER,
  "status" TEXT NOT NULL DEFAULT 'draft',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "MarketplaceProduct_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "MarketplaceProduct_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "MarketplaceProduct_sellerUserId_fkey" FOREIGN KEY ("sellerUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "MarketplaceProduct_companyId_slug_key" UNIQUE ("companyId","slug"),
  CONSTRAINT "MarketplaceProduct_productType_check" CHECK ("productType" IN ('physical','digital','service')),
  CONSTRAINT "MarketplaceProduct_priceMinor_check" CHECK ("priceMinor" > 0),
  CONSTRAINT "MarketplaceProduct_stockQuantity_check" CHECK ("stockQuantity" IS NULL OR "stockQuantity" >= 0),
  CONSTRAINT "MarketplaceProduct_status_check" CHECK ("status" IN ('draft','pending_review','published','archived','sold_out'))
);
CREATE INDEX "MarketplaceProduct_status_createdAt_idx" ON "MarketplaceProduct"("status","createdAt");
CREATE INDEX "MarketplaceProduct_companyId_sellerUserId_idx" ON "MarketplaceProduct"("companyId","sellerUserId");

CREATE TABLE "SellerPaymentAccount" (
  "id" TEXT NOT NULL,
  "companyId" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "providerAccountRef" TEXT,
  "onboardingStatus" TEXT NOT NULL DEFAULT 'not_started',
  "detailsSubmitted" BOOLEAN NOT NULL DEFAULT false,
  "chargesEnabled" BOOLEAN NOT NULL DEFAULT false,
  "payoutsEnabled" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "SellerPaymentAccount_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "SellerPaymentAccount_companyId_key" UNIQUE ("companyId"),
  CONSTRAINT "SellerPaymentAccount_providerAccountRef_key" UNIQUE ("providerAccountRef"),
  CONSTRAINT "SellerPaymentAccount_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "SellerPaymentAccount_onboardingStatus_check" CHECK ("onboardingStatus" IN ('not_started','pending','restricted','verified'))
);

CREATE TABLE "MarketplaceOrder" (
  "id" TEXT NOT NULL,
  "buyerUserId" TEXT NOT NULL,
  "sellerCompanyId" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'pending_payment',
  "subtotalMinor" INTEGER NOT NULL,
  "platformFeeMinor" INTEGER NOT NULL,
  "sellerNetMinor" INTEGER NOT NULL,
  "currency" TEXT NOT NULL DEFAULT 'GBP',
  "provider" TEXT,
  "providerRef" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "paidAt" TIMESTAMP(3),
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "MarketplaceOrder_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "MarketplaceOrder_buyerUserId_fkey" FOREIGN KEY ("buyerUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "MarketplaceOrder_sellerCompanyId_fkey" FOREIGN KEY ("sellerCompanyId") REFERENCES "Company"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "MarketplaceOrder_providerRef_key" UNIQUE ("providerRef"),
  CONSTRAINT "MarketplaceOrder_status_check" CHECK ("status" IN ('pending_payment','paid','processing','fulfilled','canceled','refunded','disputed')),
  CONSTRAINT "MarketplaceOrder_amounts_check" CHECK ("subtotalMinor" > 0 AND "platformFeeMinor" >= 0 AND "sellerNetMinor" >= 0 AND "subtotalMinor" = "platformFeeMinor" + "sellerNetMinor")
);
CREATE INDEX "MarketplaceOrder_buyerUserId_createdAt_idx" ON "MarketplaceOrder"("buyerUserId","createdAt");
CREATE INDEX "MarketplaceOrder_sellerCompanyId_status_createdAt_idx" ON "MarketplaceOrder"("sellerCompanyId","status","createdAt");

CREATE TABLE "MarketplaceOrderItem" (
  "id" TEXT NOT NULL,
  "orderId" TEXT NOT NULL,
  "productId" TEXT NOT NULL,
  "titleSnapshot" TEXT NOT NULL,
  "quantity" INTEGER NOT NULL,
  "unitPriceMinor" INTEGER NOT NULL,
  "lineTotalMinor" INTEGER NOT NULL,
  CONSTRAINT "MarketplaceOrderItem_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "MarketplaceOrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "MarketplaceOrder"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "MarketplaceOrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES "MarketplaceProduct"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "MarketplaceOrderItem_quantity_check" CHECK ("quantity" > 0),
  CONSTRAINT "MarketplaceOrderItem_amount_check" CHECK ("unitPriceMinor" > 0 AND "lineTotalMinor" = "unitPriceMinor" * "quantity")
);
CREATE INDEX "MarketplaceOrderItem_orderId_idx" ON "MarketplaceOrderItem"("orderId");
CREATE INDEX "MarketplaceOrderItem_productId_idx" ON "MarketplaceOrderItem"("productId");

CREATE TABLE "MarketplaceSettlement" (
  "id" TEXT NOT NULL,
  "orderId" TEXT NOT NULL,
  "sellerCompanyId" TEXT NOT NULL,
  "grossMinor" INTEGER NOT NULL,
  "platformFeeMinor" INTEGER NOT NULL,
  "sellerNetMinor" INTEGER NOT NULL,
  "currency" TEXT NOT NULL DEFAULT 'GBP',
  "status" TEXT NOT NULL DEFAULT 'pending',
  "providerTransferRef" TEXT,
  "providerPayoutRef" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "paidAt" TIMESTAMP(3),
  CONSTRAINT "MarketplaceSettlement_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "MarketplaceSettlement_orderId_key" UNIQUE ("orderId"),
  CONSTRAINT "MarketplaceSettlement_providerTransferRef_key" UNIQUE ("providerTransferRef"),
  CONSTRAINT "MarketplaceSettlement_providerPayoutRef_key" UNIQUE ("providerPayoutRef"),
  CONSTRAINT "MarketplaceSettlement_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "MarketplaceOrder"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "MarketplaceSettlement_sellerCompanyId_fkey" FOREIGN KEY ("sellerCompanyId") REFERENCES "Company"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "MarketplaceSettlement_amounts_check" CHECK ("grossMinor" > 0 AND "platformFeeMinor" >= 0 AND "sellerNetMinor" >= 0 AND "grossMinor" = "platformFeeMinor" + "sellerNetMinor"),
  CONSTRAINT "MarketplaceSettlement_status_check" CHECK ("status" IN ('pending','transferred','paid','failed','reversed'))
);
CREATE INDEX "MarketplaceSettlement_sellerCompanyId_status_createdAt_idx" ON "MarketplaceSettlement"("sellerCompanyId","status","createdAt");

-- Extend Company directory visibility: own memberships can discover their
-- business workspaces; the public can discover only public business profiles.
DROP POLICY IF EXISTS company_tenant_isolation ON "Company";
CREATE POLICY company_tenant_isolation ON "Company"
  USING (
    "id" = NULLIF(current_setting('app.company_id', true), '')
    OR EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "Company"."id"
      AND m."userId" = NULLIF(current_setting('app.user_id', true), ''))
    OR ("kind" = 'group' AND "status" = 'active')
    OR EXISTS (SELECT 1 FROM "UserCompany" ceo WHERE ceo."userId" = NULLIF(current_setting('app.user_id', true), '') AND ceo."role" = 'ceo')
    OR EXISTS (SELECT 1 FROM "BusinessProfile" bp WHERE bp."companyId" = "Company"."id" AND bp."visibility" = 'public')
    OR EXISTS (SELECT 1 FROM "MarketplaceProduct" mp WHERE mp."companyId" = "Company"."id" AND mp."status" = 'published')
    OR EXISTS (SELECT 1 FROM "MarketplaceOrder" o WHERE o."sellerCompanyId" = "Company"."id"
      AND o."buyerUserId" = NULLIF(current_setting('app.user_id', true), ''))
  )
  WITH CHECK ("id" = NULLIF(current_setting('app.company_id', true), ''));

-- Customer self-enrolment is restricted to the customer role in active group
-- companies. It cannot create staff/admin/CEO memberships or join another
-- customer's tenant.
DROP POLICY IF EXISTS user_membership_insert_customer_self ON "UserCompany";
CREATE POLICY user_membership_insert_customer_self ON "UserCompany" FOR INSERT WITH CHECK (
  "userId" = NULLIF(current_setting('app.user_id', true), '')
  AND "role" = 'customer'
  AND EXISTS (SELECT 1 FROM "Company" c WHERE c."id" = "UserCompany"."companyId"
    AND c."kind" = 'group' AND c."status" = 'active')
);

-- A business_owner membership may be inserted only for a customer company
-- whose ownerUserId already matches the authenticated account.
DROP POLICY IF EXISTS user_membership_insert_owner_self ON "UserCompany";
CREATE POLICY user_membership_insert_owner_self ON "UserCompany" FOR INSERT WITH CHECK (
  "userId" = NULLIF(current_setting('app.user_id', true), '')
  AND "role" = 'business_owner'
  AND EXISTS (SELECT 1 FROM "Company" c WHERE c."id" = "UserCompany"."companyId"
    AND c."kind" = 'customer' AND c."status" = 'active'
    AND c."ownerUserId" = NULLIF(current_setting('app.user_id', true), ''))
);

-- Platform users can create their own business from an authenticated context.
-- The function sets the transaction-local company scope before inserting rows,
-- so ordinary RLS policies remain active and no privileged bypass is required.
CREATE OR REPLACE FUNCTION create_customer_business(p_name TEXT, p_description TEXT DEFAULT '')
RETURNS TABLE(company_id TEXT, company_slug TEXT)
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
DECLARE
  v_user_id TEXT := NULLIF(current_setting('app.user_id', true), '');
  v_company_id TEXT := gen_random_uuid()::text;
  v_slug TEXT;
  v_handle TEXT;
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'authenticated_user_required'; END IF;
  IF length(trim(coalesce(p_name,''))) < 2 OR length(trim(p_name)) > 100 THEN RAISE EXCEPTION 'invalid_business_name'; END IF;
  IF length(coalesce(p_description,'')) > 2000 THEN RAISE EXCEPTION 'business_description_too_long'; END IF;
  IF NOT EXISTS (SELECT 1 FROM "User" u WHERE u."id" = v_user_id AND u."isActive" = true AND u."emailVerifiedAt" IS NOT NULL) THEN
    RAISE EXCEPTION 'verified_account_required';
  END IF;

  v_handle := trim(both '-' from regexp_replace(lower(trim(p_name)), '[^a-z0-9]+', '-', 'g'));
  IF v_handle = '' THEN v_handle := 'business'; END IF;
  v_slug := 'customer-' || left(v_handle, 32) || '-' || substr(replace(gen_random_uuid()::text, '-', ''), 1, 8);

  PERFORM set_config('app.company_id', v_company_id, true);
  INSERT INTO "Company" ("id","slug","name","currency","kind","status","ownerUserId","createdAt")
  VALUES (v_company_id, v_slug, trim(p_name), 'GBP', 'customer', 'active', v_user_id, CURRENT_TIMESTAMP);

  INSERT INTO "UserCompany" ("id","userId","companyId","role")
  VALUES (gen_random_uuid()::text, v_user_id, v_company_id, 'business_owner');

  INSERT INTO "BusinessProfile" ("id","companyId","displayName","description","handle","visibility","createdAt","updatedAt")
  VALUES (gen_random_uuid()::text, v_company_id, trim(p_name), coalesce(p_description,''), v_slug, 'private', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

  RETURN QUERY SELECT v_company_id, v_slug;
END;
$$;

-- Customer personal profiles: public cards disclose only the fields selected
-- for the profile; private profiles remain visible to their owner only.
ALTER TABLE "CustomerProfile" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "CustomerProfile" FORCE ROW LEVEL SECURITY;
CREATE POLICY customer_profile_read ON "CustomerProfile" FOR SELECT USING (
  "visibility" = 'public'
  OR "userId" = NULLIF(current_setting('app.user_id', true), '')
  OR EXISTS (SELECT 1 FROM "ProfileConnection" pc WHERE pc."status" = 'accepted'
    AND ((pc."requesterUserId" = NULLIF(current_setting('app.user_id', true), '') AND pc."recipientUserId" = "CustomerProfile"."userId")
      OR (pc."recipientUserId" = NULLIF(current_setting('app.user_id', true), '') AND pc."requesterUserId" = "CustomerProfile"."userId")))
);
CREATE POLICY customer_profile_insert ON "CustomerProfile" FOR INSERT WITH CHECK (
  "userId" = NULLIF(current_setting('app.user_id', true), '')
);
CREATE POLICY customer_profile_update ON "CustomerProfile" FOR UPDATE USING (
  "userId" = NULLIF(current_setting('app.user_id', true), '')
) WITH CHECK ("userId" = NULLIF(current_setting('app.user_id', true), ''));

ALTER TABLE "ProfileConnection" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ProfileConnection" FORCE ROW LEVEL SECURITY;
CREATE POLICY profile_connection_read ON "ProfileConnection" FOR SELECT USING (
  "requesterUserId" = NULLIF(current_setting('app.user_id', true), '')
  OR "recipientUserId" = NULLIF(current_setting('app.user_id', true), '')
);
CREATE POLICY profile_connection_insert ON "ProfileConnection" FOR INSERT WITH CHECK (
  "requesterUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND "requesterUserId" <> "recipientUserId"
  AND "status" = 'pending'
);
CREATE POLICY profile_connection_recipient_update ON "ProfileConnection" FOR UPDATE USING (
  "recipientUserId" = NULLIF(current_setting('app.user_id', true), '')
) WITH CHECK (
  "recipientUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND "status" IN ('accepted','declined','blocked')
);

ALTER TABLE "BusinessProfile" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "BusinessProfile" FORCE ROW LEVEL SECURITY;
CREATE POLICY business_profile_read ON "BusinessProfile" FOR SELECT USING (
  "visibility" = 'public'
  OR "companyId" = NULLIF(current_setting('app.company_id', true), '')
  OR EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "BusinessProfile"."companyId"
    AND m."userId" = NULLIF(current_setting('app.user_id', true), ''))
);
CREATE POLICY business_profile_owner_insert ON "BusinessProfile" FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "BusinessProfile"."companyId"
    AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" = 'business_owner')
);
CREATE POLICY business_profile_owner_update ON "BusinessProfile" FOR UPDATE USING (
  EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "BusinessProfile"."companyId"
    AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" = 'business_owner')
) WITH CHECK (
  EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "BusinessProfile"."companyId"
    AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" = 'business_owner')
);

ALTER TABLE "MarketplaceProduct" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "MarketplaceProduct" FORCE ROW LEVEL SECURITY;
CREATE POLICY marketplace_product_public_or_owner_read ON "MarketplaceProduct" FOR SELECT USING (
  "status" = 'published'
  OR ("companyId" = NULLIF(current_setting('app.company_id', true), '')
      AND "sellerUserId" = NULLIF(current_setting('app.user_id', true), ''))
  OR EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "MarketplaceProduct"."companyId"
      AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" IN ('business_owner','staff','admin'))
);
CREATE POLICY marketplace_product_owner_insert ON "MarketplaceProduct" FOR INSERT WITH CHECK (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "sellerUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "MarketplaceProduct"."companyId"
    AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" = 'business_owner')
  AND "status" = 'draft'
);
CREATE POLICY marketplace_product_owner_update ON "MarketplaceProduct" FOR UPDATE USING (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "sellerUserId" = NULLIF(current_setting('app.user_id', true), '')
) WITH CHECK (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "sellerUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND "status" IN ('draft','pending_review','archived','sold_out')
);

ALTER TABLE "SellerPaymentAccount" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "SellerPaymentAccount" FORCE ROW LEVEL SECURITY;
CREATE POLICY seller_payment_account_owner_read ON "SellerPaymentAccount" FOR SELECT USING (
  EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "SellerPaymentAccount"."companyId"
    AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" = 'business_owner')
);
CREATE POLICY seller_payment_account_owner_insert ON "SellerPaymentAccount" FOR INSERT WITH CHECK (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "SellerPaymentAccount"."companyId"
    AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" = 'business_owner')
);

ALTER TABLE "MarketplaceOrder" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "MarketplaceOrder" FORCE ROW LEVEL SECURITY;
CREATE POLICY marketplace_order_buyer_or_seller_read ON "MarketplaceOrder" FOR SELECT USING (
  "buyerUserId" = NULLIF(current_setting('app.user_id', true), '')
  OR "sellerCompanyId" = NULLIF(current_setting('app.company_id', true), '')
);
CREATE POLICY marketplace_order_buyer_insert ON "MarketplaceOrder" FOR INSERT WITH CHECK (
  "buyerUserId" = NULLIF(current_setting('app.user_id', true), '')
);

ALTER TABLE "MarketplaceOrderItem" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "MarketplaceOrderItem" FORCE ROW LEVEL SECURITY;
CREATE POLICY marketplace_order_item_read ON "MarketplaceOrderItem" FOR SELECT USING (
  EXISTS (SELECT 1 FROM "MarketplaceOrder" o WHERE o."id" = "MarketplaceOrderItem"."orderId"
    AND (o."buyerUserId" = NULLIF(current_setting('app.user_id', true), '')
      OR o."sellerCompanyId" = NULLIF(current_setting('app.company_id', true), ''))
  )
);
CREATE POLICY marketplace_order_item_buyer_insert ON "MarketplaceOrderItem" FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM "MarketplaceOrder" o WHERE o."id" = "MarketplaceOrderItem"."orderId"
    AND o."buyerUserId" = NULLIF(current_setting('app.user_id', true), ''))
);

ALTER TABLE "MarketplaceSettlement" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "MarketplaceSettlement" FORCE ROW LEVEL SECURITY;
CREATE POLICY marketplace_settlement_seller_read ON "MarketplaceSettlement" FOR SELECT USING (
  "sellerCompanyId" = NULLIF(current_setting('app.company_id', true), '')
  AND EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "MarketplaceSettlement"."sellerCompanyId"
    AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" = 'business_owner')
);

-- Customer-owned Vibe projects are permitted only when the owner has the
-- business_owner membership for the matching customer-created company.
ALTER TABLE "VibeProject" DROP CONSTRAINT IF EXISTS "VibeProject_targetBusinessSlug_check";
DROP POLICY IF EXISTS vibe_project_tenant_select ON "VibeProject";
CREATE POLICY vibe_project_tenant_select ON "VibeProject" FOR SELECT USING (
  "companyId" = NULLIF(current_setting('app.company_id', true), '') AND (
    "ownerUserId" = NULLIF(current_setting('app.user_id', true), '') OR EXISTS (
      SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "VibeProject"."companyId"
      AND m."userId" = NULLIF(current_setting('app.user_id', true), '')
      AND m."role" IN ('staff','admin','ceo','business_owner')
    )
  )
);
DROP POLICY IF EXISTS vibe_project_owner_insert ON "VibeProject";
CREATE POLICY vibe_project_owner_insert ON "VibeProject" FOR INSERT WITH CHECK (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND EXISTS (
    SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "VibeProject"."companyId"
      AND m."userId" = NULLIF(current_setting('app.user_id', true), '')
      AND m."role" IN ('customer','staff','admin','business_owner','ceo')
  )
  AND EXISTS (SELECT 1 FROM "Company" c WHERE c."id" = "VibeProject"."companyId"
    AND (c."slug" = "VibeProject"."targetBusinessSlug" OR c."slug" = 'hq'))
);
DROP POLICY IF EXISTS vibe_project_owner_update ON "VibeProject";
CREATE POLICY vibe_project_owner_update ON "VibeProject" FOR UPDATE USING (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
) WITH CHECK (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND EXISTS (SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "VibeProject"."companyId"
    AND m."userId" = NULLIF(current_setting('app.user_id', true), '')
    AND m."role" IN ('customer','staff','admin','business_owner','ceo'))
);

-- CEO Headquarters can review marketplace submissions across customer tenants.
-- This is limited to the CEO membership and does not grant general ledger access.
CREATE POLICY marketplace_product_ceo_review_read ON "MarketplaceProduct" FOR SELECT USING (
  EXISTS (SELECT 1 FROM "UserCompany" m
    WHERE m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" = 'ceo')
);
CREATE POLICY marketplace_product_ceo_review_update ON "MarketplaceProduct" FOR UPDATE USING (
  EXISTS (SELECT 1 FROM "UserCompany" m
    WHERE m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" = 'ceo')
) WITH CHECK ("status" IN ('pending_review','published','archived'));
