import { createHash } from "node:crypto";
import type { Prisma } from "@prisma/client";
import { prisma } from "./client.js";

export type TenantRole = "customer" | "staff" | "admin" | "business_owner";
export type TenantContext = {
  tx: Prisma.TransactionClient;
  userId: string;
  companyId: string;
  companySlug: string;
  role: TenantRole;
};

export type TenantSessionResult<T> =
  | { ok: true; value: T; userId: string; companyId: string; role: TenantRole }
  | { ok: false; status: 401 | 403; error: "authentication_required" | "tenant_access_denied" };

/**
 * Authenticate a server-side session and execute tenant work in one database
 * transaction. The company and user RLS settings are transaction-local, so
 * they cannot leak through a pooled connection into another request.
 * Never accept userId/companyId from request parameters as authority.
 */
export async function withTenantSession<T>(input: {
  token?: string | null;
  companySlug: string;
  allowedRoles: readonly TenantRole[];
}, run: (context: TenantContext) => Promise<T>): Promise<TenantSessionResult<T>> {
  if (!input.token || input.token.length < 32 || !input.companySlug || input.companySlug.length > 80) {
    return { ok: false, status: 401, error: "authentication_required" };
  }

  const tokenHash = createHash("sha256").update(input.token).digest("hex");
  const session = await prisma.session.findUnique({
    where: { tokenHash },
    select: {
      id: true,
      userId: true,
      expiresAt: true,
      revokedAt: true,
      user: { select: { isActive: true } },
    },
  });
  if (!session || session.revokedAt || session.expiresAt <= new Date() || !session.user.isActive) {
    return { ok: false, status: 401, error: "authentication_required" };
  }

  return prisma.$transaction(async (tx) => {
    // UserCompany RLS permits only the authenticated user's memberships.
    await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
    const membership = await tx.userCompany.findFirst({
      where: { userId: session.userId, company: { slug: input.companySlug } },
      select: { companyId: true, role: true, company: { select: { slug: true } } },
    });

    if (!membership || !input.allowedRoles.includes(membership.role as TenantRole)) {
      return { ok: false, status: 403, error: "tenant_access_denied" } as const;
    }

    // All company-owned queries in `run` inherit this transaction-local scope.
    await tx.$queryRaw`SELECT set_config('app.company_id', ${membership.companyId}, true)`;
    const value = await run({
      tx,
      userId: session.userId,
      companyId: membership.companyId,
      companySlug: membership.company.slug,
      role: membership.role as TenantRole,
    });
    return {
      ok: true,
      value,
      userId: session.userId,
      companyId: membership.companyId,
      role: membership.role as TenantRole,
    } as const;
  });
}
