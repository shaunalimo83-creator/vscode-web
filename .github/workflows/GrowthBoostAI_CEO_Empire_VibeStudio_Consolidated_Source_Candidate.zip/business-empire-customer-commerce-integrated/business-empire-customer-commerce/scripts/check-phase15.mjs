import fs from "node:fs";
const errors = [];
const read = (p) => fs.existsSync(p) ? fs.readFileSync(p, "utf8") : "";
const required = [
  "packages/db/prisma/migrations/20261117180000_phase15_customer_business_marketplace/migration.sql",
  "packages/core/src/marketplace-payments.ts",
  "apps/hq/lib/customer-session.ts",
  "apps/hq/app/customer/page.tsx",
  "apps/hq/app/customer/businesses/[id]/page.tsx",
  "apps/hq/app/api/customer/auth/register/route.ts",
  "apps/hq/app/api/customer/auth/login/route.ts",
  "apps/hq/app/api/customer/auth/verify/route.ts",
  "apps/hq/app/api/customer/businesses/route.ts",
  "apps/hq/app/api/customer/businesses/[id]/products/route.ts",
  "apps/hq/app/api/customer/businesses/[id]/profile/route.ts",
  "apps/hq/app/api/customer/connections/route.ts",
  "apps/hq/app/api/marketplace/products/route.ts",
  "apps/hq/app/api/marketplace/checkout/route.ts",
  "apps/hq/app/api/admin/marketplace/products/route.ts",
  "apps/hq/app/marketplace-review/page.tsx",
  "apps/hq/app/api/admin/customer-businesses/route.ts",
  "apps/hq/app/customer-businesses/page.tsx",
];
for (const file of required) if (!fs.existsSync(file)) errors.push(`Missing ${file}`);
const schema = read("packages/db/prisma/schema.prisma");
for (const model of ["CustomerProfile","CustomerConsent","ProfileConnection","BusinessProfile","MarketplaceProduct","SellerPaymentAccount","MarketplaceOrder","MarketplaceOrderItem","MarketplaceSettlement"]) {
  if (!schema.includes(`model ${model} {`)) errors.push(`Prisma model missing: ${model}`);
}
const migration = read(required[0]);
for (const marker of ["CREATE OR REPLACE FUNCTION create_customer_business","ENABLE ROW LEVEL SECURITY","FORCE ROW LEVEL SECURITY","business_owner","marketplace_product_ceo_review_update","user_membership_insert_customer_self","user_membership_insert_owner_self","MarketplaceSettlement"]) {
  if (!migration.includes(marker)) errors.push(`Phase 15 migration missing ${marker}`);
}
for (const app of ["growthboost","ai-magazine","trust-vault","stock-express","real-estate","supergpu","dailyaccess"]) {
  const identity = read(`apps/${app}/lib/identity.ts`);
  if (!identity.includes("platformCompanies") || !identity.includes("createMany")) errors.push(`${app}: account-wide customer memberships missing`);
}
const vibeAuth = read("apps/vibe-coding-platform/lib/auth.ts");
if (!vibeAuth.includes("canAccessVibeBusiness") || !vibeAuth.includes('"business_owner"')) errors.push("Vibe dynamic customer-owned business access missing");
const checkout = read("apps/hq/app/api/marketplace/checkout/route.ts");
if (!checkout.includes("marketplace_payments_not_connected") || !checkout.includes("status: 503")) errors.push("Marketplace checkout must fail closed without a payment provider");
const rbac = read("packages/core/src/rbac.ts");
if (!rbac.includes('"business_owner"') || !rbac.includes('business_owner: BUSINESS_OWNER')) errors.push("Business-owner RBAC role is missing");
const paymentContract = read("packages/core/src/marketplace-payments.ts");
for (const marker of ["createSellerOnboarding","createCheckout","transferSellerProceeds","verifyWebhook"]) if (!paymentContract.includes(marker)) errors.push(`Marketplace payment contract missing ${marker}`);
if (errors.length) { console.error(errors.join("\\n")); process.exit(1); }
console.log("Phase 15 structural check PASSED: platform customer accounts, public/private profiles, customer-owned businesses, per-business dashboards, product listings, CEO moderation and fail-closed marketplace payment contracts are present.");
console.log("This is a structural source check only; it does not prove runtime isolation, provider settlement, legal compliance or production readiness.");
