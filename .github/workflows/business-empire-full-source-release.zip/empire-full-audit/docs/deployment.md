# Deployment Instructions

## Prerequisites

- Node 20+, npm 10+
- Managed PostgreSQL 15+ (with PITR backups)
- S3-compatible object storage with SSE-KMS and versioning
- Managed auth provider (Cognito / Auth0 / Keycloak) with TOTP MFA
- Payment provider merchant accounts (e.g. Stripe) — optional at first

## Stages

### Stage 1 — Platform
```bash
npm install
cp .env.example .env            # fill in DATABASE_URL, auth, storage
npm run generate:apps           # (re)generate app scaffolding
npx prisma validate --schema packages/db/prisma/schema.prisma
npx prisma migrate deploy --schema packages/db/prisma/schema.prisma
npm run typecheck && npm test
```

### Stage 2 — Per-business rollout (test each independently)
Deploy one app at a time behind its subdomain and run its smoke tests:

```bash
cd apps/growthboost && npm run build && npm start   # then curl /api/health
```

Rollout order: growthboost → ai-magazine → real-estate → dailyaccess →
supergpu → stock-express (paper only) → trust-vault (vault only, no banking).
Run the full test suite between each rollout.

### Stage 3 — HQ
Deploy `apps/hq` behind `hq.example.com`. CEO sign-in requires MFA before any
panel renders data. Verify consolidated reporting returns `no-live-data`
until real transactions exist.

### Stage 4 — Ecosystem test
`tests/` contains cross-cutting suites: run `npm test` and the Playwright e2e
against a staging deployment with all eight apps wired to one database.

## Environments

| Env | Payments | Trading | Seed data |
|---|---|---|---|
| production | live PSP only | disabled | forbidden |
| staging | PSP test mode | paper | `SIMULATED`-labelled only |
| development | simulated (throws) | paper | `SIMULATED`-labelled only |

## Domains

Each company gets its own subdomain + TLS (managed cert). `hq.example.com`
hosts the CEO dashboard. DNS records documented in `infra/dns.md`.
