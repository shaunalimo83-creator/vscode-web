FROM node:20-alpine
WORKDIR /srv
ARG APP=hq
COPY . .
RUN npm install --workspace @empire/app-${APP} --ignore-scripts || npm install --ignore-scripts
WORKDIR /srv/apps/${APP}
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
