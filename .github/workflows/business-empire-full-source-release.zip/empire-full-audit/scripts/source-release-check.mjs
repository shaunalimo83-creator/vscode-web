import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const apps = ['hq', 'growthboost', 'ai-magazine', 'trust-vault', 'stock-express', 'real-estate', 'supergpu', 'dailyaccess'];
const errors = [];
for (const app of apps) {
  const base = path.join(root, 'apps', app);
  for (const rel of ['package.json', 'app/page.tsx', 'app/layout.tsx']) {
    if (!fs.existsSync(path.join(base, rel))) errors.push(`${app}: missing ${rel}`);
  }
}
for (const rel of [
  'packages/core/package.json', 'packages/db/package.json',
  'packages/db/prisma/schema.prisma', '.env.example', 'README.md',
  'RELEASE-STATUS.md', 'docs/deployment.md', 'docs/integration-register.md',
]) if (!fs.existsSync(path.join(root, rel))) errors.push(`Missing ${rel}`);
const env = fs.readFileSync(path.join(root, '.env.example'), 'utf8');
if (!env.includes('CUSTOMER_REGISTRATION_ENABLED=false')) errors.push('Customer registration must remain disabled by default');
if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}
console.log(`Source release check passed: ${apps.length} app workspaces, shared packages, database schema, environment template and release gates present.`);
console.log('This is a source-structure check only, not a build, runtime, security or deployment certification.');
