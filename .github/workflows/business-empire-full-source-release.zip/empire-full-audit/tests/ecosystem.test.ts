import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { BUSINESSES } from "../packages/core/src/entities.js";

const ROOT = join(import.meta.dirname, "..");

describe("ecosystem integrity (each business independently)", () => {
  const allApps = BUSINESSES.map((b) => b.id).concat("hq");

  it("generates all seven business apps plus HQ", () => {
    for (const a of allApps) {
      for (const f of ["package.json", "app/page.tsx", "app/layout.tsx", "app/login/page.tsx"]) {
        expect(
          (() => { readFileSync(join(ROOT, "apps", a, f)); return true; })(),
          `apps/${a}/${f} missing`,
        ).toBe(true);
      }
    }
  });

  it("every business app has a customer dashboard, admin area and legal pages", () => {
    for (const b of BUSINESSES) {
      for (const f of ["app/dashboard/page.tsx", "app/admin/page.tsx", "app/legal/privacy/page.tsx", "app/legal/terms/page.tsx", "app/support/page.tsx", "app/account-recovery/page.tsx"]) {
        expect(
          (() => { readFileSync(join(ROOT, "apps", b.id, f)); return true; })(),
          `apps/${b.id}/${f} missing`,
        ).toBe(true);
      }
    }
  });

  it("every business page links customer dashboard, admin, login and legal pages", () => {
    for (const b of BUSINESSES) {
      const page = readFileSync(join(ROOT, "apps", b.id, "app", "page.tsx"), "utf8");
      for (const link of ['"/dashboard"', '"/admin"', '"/login"', '"/legal/privacy"', '"/legal/terms"']) {
        expect(page.includes(link), `${b.id} missing ${link}`).toBe(true);
      }
    }
  });

  it("HQ dashboard exposes all seven business panels and core HQ features", () => {
    const page = readFileSync(join(ROOT, "apps", "hq", "app", "page.tsx"), "utf8");
    for (const b of BUSINESSES) expect(page.includes(b.name), `HQ panel missing ${b.name}`).toBe(true);
    const files = [
      "app/reports/page.tsx", "app/staff/page.tsx", "app/security/page.tsx",
      "app/api/consolidated/route.ts", "app/api/health/route.ts",
    ];
    for (const f of files) readFileSync(join(ROOT, "apps", "hq", f)); // throws if missing
  });

  it("regulatory notices are honest and prominent where required", () => {
    const trust = readFileSync(join(ROOT, "apps", "trust-vault", "app", "page.tsx"), "utf8");
    expect(trust).toMatch(/not an authorised bank/);
    expect(trust).toMatch(/authorised partner/i);
    const stock = readFileSync(join(ROOT, "apps", "stock-express", "app", "page.tsx"), "utf8");
    expect(stock).toMatch(/Paper trading only/);
  });

  it("every business app has a health endpoint", () => {
    for (const a of allApps) {
      readFileSync(join(ROOT, "apps", a, "app", "api", "health", "route.ts"));
    }
  });
});

describe("financial controls are present in the schema", () => {
  const schema = readFileSync(join(ROOT, "packages", "db", "prisma", "schema.prisma"), "utf8");
  it("records entity, amount, currency, status, date, reference and provider on every payment", () => {
    for (const field of ["companyId", "amountMinor", "currency", "status", "createdAt", "reference", "provider", "providerRef"]) {
      expect(schema.includes(field), `Payment missing ${field}`).toBe(true);
    }
  });
  it("has an intercompany authorisation model (no silent money movement)", () => {
    expect(schema).toMatch(/model IntercompanyAuthorisation/);
  });
  it("enforces RLS in SQL policies", () => {
    const rls = readFileSync(join(ROOT, "packages", "db", "policies", "rls.sql"), "utf8");
    expect(rls).toMatch(/ENABLE ROW LEVEL SECURITY/);
    expect(rls).toMatch(/tenant_isolation/);
  });
});
