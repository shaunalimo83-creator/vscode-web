import { logoutCustomer } from "../../../../lib/identity";
export async function POST(req: Request) { return logoutCustomer(req); }
