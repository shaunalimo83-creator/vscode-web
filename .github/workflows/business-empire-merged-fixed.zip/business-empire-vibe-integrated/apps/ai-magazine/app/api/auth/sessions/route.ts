import { listCustomerSessions, revokeCustomerSessions } from "../../../../lib/identity";
export async function GET() { return listCustomerSessions(); }
export async function DELETE(req: Request) { return revokeCustomerSessions(req); }
