import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "DailyAccess",
  description: "Personalised AI briefings, topic monitoring and verified source links.",
  openGraph: { title: "DailyAccess", description: "Personalised AI briefings, topic monitoring and verified source links." },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
