import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "growthboost", status: "ok", ts: new Date().toISOString() });
}
