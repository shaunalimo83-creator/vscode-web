# CEO Master Dashboard (HQ)

Panels: seven business overviews, website navigation, revenue/expense/P&L/cash-flow reporting, customer & subscription analytics, AI CEO assistant & daily briefing, legal & compliance reminders, staff & permissions, security alerts & audit logs, website status & domains, downloadable reports.

Reporting currency: GBP. MFA mandatory. Cross-company banking data access is impossible by design.
