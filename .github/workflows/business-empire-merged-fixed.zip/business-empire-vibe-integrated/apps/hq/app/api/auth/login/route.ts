import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { newSessionToken, sha256, verifyPassword, decryptMfaSecret, verifyTotp, isSameOriginRequest } from "@empire/core";
import { SESSION_COOKIE } from "../session";
import { loginIsThrottled, clearLoginThrottle } from "../throttle";
export const runtime = "nodejs";
export async function POST(request: NextRequest) {
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "Invalid request origin" }, { status: 403, headers: { "Cache-Control": "no-store" } });
  try {
    const body = await request.json();
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body.password === "string" ? body.password : "";
    const code = typeof body.code === "string" ? body.code.trim() : "";
    const ip = request.headers.get("x-real-ip")?.trim() || request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    if (await loginIsThrottled(email, ip)) return NextResponse.json({ error: "Too many sign-in attempts. Try again later." }, { status: 429, headers: { "Cache-Control": "no-store", "Retry-After": "900" } });
    if (!email || !password) return NextResponse.json({ error: "Email and password are required" }, { status: 400 });
    const user = await prisma.user.findUnique({
      where: { email },
      select: { id: true, isActive: true, passwordHash: true, mfaEnrolled: true, mfaSecretEnc: true },
    });
    const valid = !!user && user.isActive && !!user.passwordHash && verifyPassword(password, user.passwordHash);
    if (!valid) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });

    // Membership lookup is user-scoped; Company RLS permits discovery only
    // through this verified user's UserCompany row.
    const membership = await prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${user!.id}, true)`;
      return tx.userCompany.findFirst({
        where: { userId: user!.id, company: { slug: "hq" }, role: "ceo" },
        select: { companyId: true },
      });
    });
    if (!membership) return NextResponse.json({ error: "This account is not authorised for CEO Headquarters" }, { status: 403 });
    if (!user!.mfaEnrolled || !user!.mfaSecretEnc || !code) return NextResponse.json({ error: "CEO MFA must be enrolled before access is granted" }, { status: 403 });
    let mfaValid = false;
    try { mfaValid = verifyTotp(decryptMfaSecret(user!.mfaSecretEnc), code, Math.floor(Date.now() / 1000)); } catch { mfaValid = false; }
    if (!mfaValid && /^[A-F0-9]{4}(?:-[A-F0-9]{4}){3}$/i.test(code)) {
      mfaValid = await prisma.$transaction(async (tx) => {
        await tx.$queryRaw`SELECT set_config('app.user_id', ${user!.id}, true)`;
        await tx.$queryRaw`SELECT set_config('app.company_id', ${membership.companyId}, true)`;
        const consumed = await tx.recoveryCode.updateMany({ where: { userId: user!.id, codeHash: sha256(code.toUpperCase()), usedAt: null }, data: { usedAt: new Date() } });
        if (consumed.count === 1) {
          await tx.auditLog.create({ data: { actorId: user!.id, companyId: membership.companyId, action: "hq.auth.recovery_code_used", subject: user!.id, ip } });
          return true;
        }
        return false;
      });
    }
    if (!mfaValid) return NextResponse.json({ error: "Invalid authenticator or recovery code" }, { status: 401, headers: { "Cache-Control": "no-store" } });
    await clearLoginThrottle(email, ip);
    const token = newSessionToken();
    const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000);
    const session = await prisma.session.create({ data: { userId: user!.id, tokenHash: sha256(token), expiresAt } });
    await prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${user!.id}, true)`;
      await tx.$queryRaw`SELECT set_config('app.company_id', ${membership.companyId}, true)`;
      await tx.auditLog.create({ data: { actorId: user!.id, companyId: membership.companyId, action: "hq.login.success", subject: session.id, ip: request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null } });
    });
    const response = NextResponse.json({ ok: true, expiresAt });
    response.cookies.set(SESSION_COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", expires: expiresAt });
    response.headers.set("Cache-Control", "no-store");
    return response;
  } catch { return NextResponse.json({ error: "Authentication service unavailable" }, { status: 503, headers: { "Cache-Control": "no-store" } }); }
}
