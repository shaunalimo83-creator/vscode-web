import { NextResponse } from "next/server";
import { currentHqUser } from "../session";
export async function GET() {
  const user = await currentHqUser();
  if (!user) return NextResponse.json({ error: "Unauthorised" }, { status: 401, headers: { "Cache-Control": "no-store" } });
  return NextResponse.json({ user: { id: user.id, email: user.email } }, { headers: { "Cache-Control": "no-store" } });
}
