import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { isSameOriginRequest } from "@empire/core";
import { currentHqUser } from "../../session";
export async function POST(request: NextRequest) {
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "Invalid request origin" }, { status: 403, headers: { "Cache-Control": "no-store" } });
  const user = await currentHqUser();
  if (!user) return NextResponse.json({ error: "Unauthorised" }, { status: 401, headers: { "Cache-Control": "no-store" } });
  const result = await prisma.$transaction(async tx => {
    await tx.$queryRaw`SELECT set_config('app.user_id', ${user.id}, true)`;
    await tx.$queryRaw`SELECT set_config('app.company_id', ${user.companyId}, true)`;
    const revoked = await tx.session.updateMany({ where: { userId: user.id, id: { not: user.sessionId }, revokedAt: null }, data: { revokedAt: new Date() } });
    await tx.auditLog.create({ data: { actorId: user.id, companyId: user.companyId, action: "hq.sessions.revoke_others", subject: `count:${revoked.count}` } });
    return revoked;
  });
  return NextResponse.json({ ok: true, revokedCount: result.count }, { headers: { "Cache-Control": "no-store" } });
}
