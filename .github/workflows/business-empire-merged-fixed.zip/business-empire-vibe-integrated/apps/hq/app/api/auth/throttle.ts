import { prisma } from "@empire/db";
import { sha256 } from "@empire/core";

const WINDOW_MS = 15 * 60 * 1000;
const LOCK_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 8;

/** Shared PostgreSQL throttle; requires the Phase 6 AuthThrottle migration. */
export async function loginIsThrottled(email: string, clientIp: string): Promise<boolean> {
  const key = sha256(`${email.toLowerCase()}|${clientIp}`).slice(0, 64);
  const now = new Date();
  const rows = await prisma.$queryRaw<Array<{ locked: boolean }>>`
    INSERT INTO "AuthThrottle" ("key", "windowStartedAt", "attempts", "lockedUntil", "updatedAt")
    VALUES (${key}, ${now}, 1, NULL, ${now})
    ON CONFLICT ("key") DO UPDATE SET
      "windowStartedAt" = CASE WHEN "AuthThrottle"."windowStartedAt" <= ${new Date(now.getTime()-WINDOW_MS)} THEN ${now} ELSE "AuthThrottle"."windowStartedAt" END,
      "attempts" = CASE WHEN "AuthThrottle"."windowStartedAt" <= ${new Date(now.getTime()-WINDOW_MS)} THEN 1 ELSE "AuthThrottle"."attempts" + 1 END,
      "lockedUntil" = CASE WHEN "AuthThrottle"."lockedUntil" > ${now} THEN "AuthThrottle"."lockedUntil"
        WHEN (CASE WHEN "AuthThrottle"."windowStartedAt" <= ${new Date(now.getTime()-WINDOW_MS)} THEN 1 ELSE "AuthThrottle"."attempts" + 1 END) >= ${MAX_ATTEMPTS} THEN ${new Date(now.getTime()+LOCK_MS)} ELSE NULL END,
      "updatedAt" = ${now}
    RETURNING ("lockedUntil" IS NOT NULL AND "lockedUntil" > ${now}) AS locked
  `;
  return rows[0]?.locked ?? true;
}

export async function clearLoginThrottle(email: string, clientIp: string) {
  const key = sha256(`${email.toLowerCase()}|${clientIp}`).slice(0, 64);
  await prisma.authThrottle.deleteMany({ where: { key } });
}
