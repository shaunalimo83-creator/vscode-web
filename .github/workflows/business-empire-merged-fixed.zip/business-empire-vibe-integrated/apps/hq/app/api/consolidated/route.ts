import { NextResponse } from "next/server";
import { currentHqUser } from "../auth/session";
export async function GET() {
  const user = await currentHqUser();
  if (!user) return NextResponse.json({ error: "Unauthorised" }, { status: 401, headers: { "Cache-Control": "no-store" } });
  return NextResponse.json({ status: "not_configured", code: "LEDGER_NOT_CONFIGURED", message: "CEO identity verified. Consolidated figures remain unavailable until verified ledger entries are connected." }, { status: 503, headers: { "Cache-Control": "no-store" } });
}
