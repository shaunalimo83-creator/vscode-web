# Real Estate Master Developments app

Company id: `real-estate` · Currency: GBP · Subdomain: `real-estate.example.com`

Pages: / (marketing + enquiry), /login (MFA-aware), /dashboard, /admin, /legal/privacy, /legal/terms, /support, /account-recovery.
APIs: /api/health, /api/auth/login, /api/enquiry, /api/me/summary, /api/me/export, /api/admin/summary.
