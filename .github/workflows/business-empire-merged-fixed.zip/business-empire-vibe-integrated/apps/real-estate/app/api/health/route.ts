import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "real-estate", status: "ok", ts: new Date().toISOString() });
}
