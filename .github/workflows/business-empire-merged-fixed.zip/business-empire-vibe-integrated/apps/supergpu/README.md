# SUPERGPU UNIVERSAL app

Company id: `supergpu` · Currency: GBP · Subdomain: `supergpu.example.com`

Pages: / (marketing + enquiry), /login (MFA-aware), /dashboard, /admin, /legal/privacy, /legal/terms, /support, /account-recovery.
APIs: /api/health, /api/auth/login, /api/enquiry, /api/me/summary, /api/me/export, /api/admin/summary.
