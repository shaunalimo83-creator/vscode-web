import { NextResponse } from "next/server";
import { VIBE_BUSINESS_TARGETS } from "@empire/core";
import { getVibeSession, VIBE_BUSINESS_NAMES } from "../../../../lib/auth";
import { NO_STORE } from "../../../../lib/security";

export async function GET() {
  const session = await getVibeSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const businesses = session.isCeo
    ? VIBE_BUSINESS_TARGETS.map((slug) => ({ slug, name: VIBE_BUSINESS_NAMES[slug], role: "ceo" }))
    : session.memberships
      .filter((membership) => (VIBE_BUSINESS_TARGETS as readonly string[]).includes(membership.slug))
      .map((membership) => ({ slug: membership.slug, name: membership.name, role: membership.role }));
  return NextResponse.json({ user: { email: session.email, isCeo: session.isCeo }, businesses }, { headers: NO_STORE });
}
