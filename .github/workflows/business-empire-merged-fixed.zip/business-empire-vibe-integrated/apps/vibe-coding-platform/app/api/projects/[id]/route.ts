import { NextResponse } from "next/server";
import { getVibeSession, withVibeTenant } from "../../../../lib/auth";
import { NO_STORE } from "../../../../lib/security";
import { isVibeBusinessSlug } from "@empire/core";

export async function GET(request: Request, context: { params: { id: string } }) {
  const session = await getVibeSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const target = new URL(request.url).searchParams.get("business") || "growthboost";
  if (!isVibeBusinessSlug(target)) return NextResponse.json({ error: "invalid_business_target" }, { status: 400, headers: NO_STORE });
  const result = await withVibeTenant(session, target, async ({ tx, companyId, role }) => {
    const project = await tx.vibeProject.findFirst({
      where: { id: context.params.id, companyId, ...(role === "customer" ? { ownerUserId: session.userId } : {}) },
      select: { id: true, name: true, prompt: true, targetBusinessSlug: true, status: true, createdAt: true, updatedAt: true, files: { select: { id: true, path: true, language: true, version: true, updatedAt: true }, orderBy: { path: "asc" } } },
    });
    return project;
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers: NO_STORE });
  if (!result.value) return NextResponse.json({ error: "project_not_found" }, { status: 404, headers: NO_STORE });
  return NextResponse.json({ project: result.value }, { headers: NO_STORE });
}
