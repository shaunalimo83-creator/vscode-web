import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { VIBE_PLAN_LIMITS, escapeVibeHtml, isVibeBusinessSlug, isVibePlanCode } from "@empire/core";
import { getVibeSession, withVibeTenant } from "../../../lib/auth";
import { NO_STORE, rejectVibeOrigin, vibeRateLimited } from "../../../lib/security";

export const runtime = "nodejs";

export async function GET(request: Request) {
  const session = await getVibeSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const target = new URL(request.url).searchParams.get("business") || "growthboost";
  if (!isVibeBusinessSlug(target)) return NextResponse.json({ error: "invalid_business_target" }, { status: 400, headers: NO_STORE });
  const result = await withVibeTenant(session, target, async ({ tx, companyId, role }) => {
    const where = role === "customer" ? { companyId, ownerUserId: session.userId } : { companyId };
    return tx.vibeProject.findMany({
      where,
      orderBy: { updatedAt: "desc" },
      take: 50,
      select: { id: true, name: true, targetBusinessSlug: true, status: true, createdAt: true, updatedAt: true, _count: { select: { files: true } } },
    });
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers: NO_STORE });
  return NextResponse.json({ projects: result.value }, { headers: NO_STORE });
}

export async function POST(request: Request) {
  const blocked = rejectVibeOrigin(request);
  if (blocked) return blocked;
  const session = await getVibeSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  if (await vibeRateLimited(request, "project-create", session.userId)) return NextResponse.json({ error: "too_many_project_requests" }, { status: 429, headers: NO_STORE });

  const body = await request.json().catch(() => null);
  const target = body?.businessSlug;
  const name = typeof body?.name === "string" ? body.name.trim() : "";
  const prompt = typeof body?.prompt === "string" ? body.prompt.trim() : "";
  if (!isVibeBusinessSlug(target) || name.length < 2 || name.length > 80 || prompt.length < 12 || prompt.length > 6000) {
    return NextResponse.json({ error: "valid_business_name_and_project_prompt_required" }, { status: 400, headers: NO_STORE });
  }

  const result = await withVibeTenant(session, target, async ({ tx, companyId }) => {
    const plan = await tx.vibePlanSubscription.upsert({
      where: { userId: session.userId },
      create: { userId: session.userId, planCode: "free", websiteCount: 0, status: "active" },
      update: {},
      select: { planCode: true, status: true, websiteCount: true },
    });
    const planCode = isVibePlanCode(plan.planCode) ? plan.planCode : "free";
    const limit = VIBE_PLAN_LIMITS[planCode];
    if (plan.status !== "active" || (limit !== null && plan.websiteCount >= limit)) {
      return { limitReached: true as const, project: null };
    }
    // Atomic account-wide quota claim prevents parallel requests from exceeding
    // the free allowance, even when a user belongs to more than one business.
    const claimed = await tx.vibePlanSubscription.updateMany({
      where: { userId: session.userId, status: "active", ...(limit === null ? {} : { websiteCount: { lt: limit } }) },
      data: { websiteCount: { increment: 1 } },
    });
    if (claimed.count !== 1) return { limitReached: true as const, project: null };

    const safeName = escapeVibeHtml(name);
    const safePrompt = escapeVibeHtml(prompt.slice(0, 1800));
    const html = `<!doctype html>\n<html lang="en-GB">\n<head>\n  <meta charset="utf-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1" />\n  <title>${safeName}</title>\n  <style>body{font-family:system-ui,sans-serif;margin:0;background:#f5f6fb;color:#182033}main{max-width:860px;margin:10vh auto;padding:40px;background:white;border-radius:20px;box-shadow:0 16px 60px #18203312}h1{font-size:clamp(2rem,6vw,4rem);margin:0 0 1rem}p{line-height:1.7;color:#536078}</style>\n</head>\n<body>\n  <main>\n    <p>New project workspace</p>\n    <h1>${safeName}</h1>\n    <p>${safePrompt}</p>\n    <p>Edit this starter file in Vibe Coding Platform. AI-generated code requires a configured model gateway; remote hosted preview is not available yet.</p>\n  </main>\n</body>\n</html>\n`;
    const project = await tx.vibeProject.create({
      data: {
        companyId,
        ownerUserId: session.userId,
        targetBusinessSlug: target,
        name,
        prompt,
        status: "draft",
        files: {
          create: [
            { path: "index.html", language: "html", content: html },
            { path: "README.md", language: "markdown", content: `# ${name}\n\n## Original build brief\n\n${prompt}\n\n## Status\n\nStarter workspace created. AI generation, sandbox execution, hosted preview, custom domains and deployment are not yet connected.\n` },
          ],
        },
      },
      select: { id: true, name: true, targetBusinessSlug: true, status: true, createdAt: true },
    });
    await tx.auditLog.create({
      data: { actorId: session.userId, companyId, action: "vibe.project.created", subject: project.id },
    });
    return { limitReached: false as const, project };
  });

  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers: NO_STORE });
  if (result.value.limitReached) return NextResponse.json({ error: "free_or_current_plan_project_limit_reached", upgradeAvailable: false }, { status: 402, headers: NO_STORE });
  return NextResponse.json({ project: result.value.project, notice: "Starter workspace saved. AI generation, hosted preview and deployment still need provider connections." }, { status: 201, headers: NO_STORE });
}
