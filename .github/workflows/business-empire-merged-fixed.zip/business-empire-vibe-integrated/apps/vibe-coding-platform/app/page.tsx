import Link from "next/link";

const features = [
  ["Prompt-led projects", "Turn a project brief into a saved website or application workspace."],
  ["One shared ecosystem", "Choose from the seven Business Empire companies, with access checked against your existing account membership."],
  ["Code workspace", "Browse and edit starter project files with tenant isolation and version counters."],
  ["Website marketplace", "Prepare draft listings for websites you want to sell. Publishing and checkout remain gated until payment and transfer systems are verified."],
];

export default function Home() {
  return (
    <main style={{ maxWidth: 1120, margin: "0 auto", padding: "32px 22px 80px" }}>
      <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
        <Link href="/" style={{ color: "#fff", textDecoration: "none", fontWeight: 800, letterSpacing: ".08em" }}>VIBE / EMPIRE</Link>
        <nav style={{ display: "flex", gap: 18, flexWrap: "wrap", color: "#b8c2dc" }}>
          <Link href="/projects" style={{ color: "inherit" }}>My projects</Link>
          <Link href="/marketplace" style={{ color: "inherit" }}>Marketplace</Link>
          <Link href="/plans" style={{ color: "inherit" }}>Plans</Link>
          <Link href="/login" style={{ color: "inherit" }}>Sign in</Link>
        </nav>
      </header>

      <section style={{ padding: "84px 0 58px", maxWidth: 820 }}>
        <p style={{ color: "#a78bfa", textTransform: "uppercase", letterSpacing: ".18em", fontSize: 12, fontWeight: 700 }}>One platform. Seven businesses. One headquarters.</p>
        <h1 style={{ fontSize: "clamp(42px, 7vw, 76px)", lineHeight: 1.02, margin: "18px 0", letterSpacing: "-.055em" }}>Describe it.<br /><span style={{ color: "#a78bfa" }}>Build the workspace.</span></h1>
        <p style={{ maxWidth: 680, color: "#b8c2dc", fontSize: 19, lineHeight: 1.65 }}>A shared website and application creation studio for GrowthBoost AI, AI Magazine & Comic Book Studio, Trust Vault, Stock Market Express, Real Estate Master Developments, SUPERGPU UNIVERSAL and DailyAccess — connected to CEO Headquarters.</p>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 28 }}>
          <Link href="/projects" style={{ background: "#8b5cf6", color: "white", padding: "14px 20px", borderRadius: 12, textDecoration: "none", fontWeight: 700 }}>Open project studio →</Link>
          <Link href="/marketplace" style={{ border: "1px solid #35405d", color: "#eef2ff", padding: "14px 20px", borderRadius: 12, textDecoration: "none" }}>Explore marketplace</Link>
        </div>
      </section>

      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 14 }}>
        {features.map(([title, description]) => <article key={title} style={{ background: "#121a30", border: "1px solid #26314d", borderRadius: 18, padding: 22 }}><h2 style={{ fontSize: 18, marginTop: 0 }}>{title}</h2><p style={{ color: "#aeb9d3", lineHeight: 1.6, marginBottom: 0 }}>{description}</p></article>)}
      </section>

      <section style={{ marginTop: 22, border: "1px solid #5b4a91", background: "#1a1730", borderRadius: 18, padding: 22 }}>
        <strong style={{ color: "#d8ccff" }}>Build status</strong>
        <p style={{ color: "#c3bddb", lineHeight: 1.6, marginBottom: 0 }}>Project storage, account access, starter files and draft marketplace records are included in this source integration. AI code generation is enabled only after server-side AI Gateway credentials and a supported model are configured. Remote sandbox execution, hosted preview, custom-domain provisioning, payment checkout and deployment remain pending.</p>
      </section>
    </main>
  );
}
