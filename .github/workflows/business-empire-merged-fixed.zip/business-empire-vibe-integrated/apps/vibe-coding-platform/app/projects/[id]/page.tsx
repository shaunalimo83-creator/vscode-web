'use client';
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

type Project = { id: string; name: string; prompt: string; targetBusinessSlug: string; status: string; files: { id: string; path: string; language: string; version: number }[] };
type ProjectFile = { id: string; path: string; language: string; content: string; version: number };

export default function ProjectWorkspace({ params }: { params: { id: string } }) {
  const search = useSearchParams();
  const businessSlug = search.get("business") || "growthboost";
  const [project, setProject] = useState<Project | null>(null);
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [selectedPath, setSelectedPath] = useState("index.html");
  const [content, setContent] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [listingTitle, setListingTitle] = useState("");
  const [listingDescription, setListingDescription] = useState("");
  const [listingPrice, setListingPrice] = useState("49.00");
  const selectedFile = useMemo(() => files.find(file => file.path === selectedPath), [files, selectedPath]);

  async function load() {
    const [projectResponse, filesResponse] = await Promise.all([
      fetch(`/api/projects/${params.id}?business=${encodeURIComponent(businessSlug)}`, { cache: "no-store" }),
      fetch(`/api/projects/${params.id}/files?business=${encodeURIComponent(businessSlug)}`, { cache: "no-store" }),
    ]);
    const projectData = await projectResponse.json(); const filesData = await filesResponse.json();
    if (!projectResponse.ok || !filesResponse.ok) throw new Error(projectData.error || filesData.error || "Could not load project.");
    setProject(projectData.project); setFiles(filesData.files || []);
    const first = (filesData.files || []).find((file: ProjectFile) => file.path === selectedPath) || (filesData.files || [])[0];
    if (first) { setSelectedPath(first.path); setContent(first.content); }
  }
  useEffect(() => { load().catch(e => setError(e.message)); }, [params.id, businessSlug]);
  useEffect(() => { if (selectedFile) setContent(selectedFile.content); }, [selectedPath]);

  async function saveFile() {
    setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch(`/api/projects/${params.id}/files`, { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ businessSlug, path: selectedPath, language: selectedFile?.language || "text", content }) });
      const data = await response.json(); if (!response.ok) throw new Error(data.error || "File save failed.");
      setMessage(`Saved ${selectedPath} · version ${data.file.version}`); await load();
    } catch (e) { setError(e instanceof Error ? e.message : "File save failed."); }
    finally { setBusy(false); }
  }
  async function requestGeneration() {
    setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch(`/api/projects/${params.id}/generate`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ businessSlug }) });
      const data = await response.json(); setMessage(data.message || data.error || "Generation service response received."); if (response.ok) await load();
    } catch { setError("Could not contact the generation service."); }
    finally { setBusy(false); }
  }
  async function createListing(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    try {
      const priceMinor = Math.round(Number(listingPrice) * 100);
      const response = await fetch(`/api/projects/${params.id}/listing`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ businessSlug, title: listingTitle, description: listingDescription, priceMinor }) });
      const data = await response.json(); if (!response.ok) throw new Error(data.error || "Could not save listing.");
      setMessage(data.notice || "Draft listing saved.");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not save listing."); }
    finally { setBusy(false); }
  }

  if (error && !project) return <main style={wrap}><Link href="/projects">← Projects</Link><p role="alert">{error}</p></main>;
  if (!project) return <main style={wrap}><p>Loading project workspace…</p></main>;
  const preview = selectedPath.endsWith(".html") ? content : "";
  return <main style={wrap}>
    <header style={header}><div><Link href={`/projects`} style={{ color: "#b9a5ff" }}>← All projects</Link><h1 style={{ marginBottom: 4 }}>{project.name}</h1><p style={muted}>{project.targetBusinessSlug} · {project.status} · starter workspace</p></div><button onClick={requestGeneration} disabled={busy} style={button}>Generate code with AI</button></header>
    {message && <p role="status" style={notice}>{message}</p>}{error && <p role="alert" style={errorStyle}>{error}</p>}
    <section style={workspace}>
      <aside style={filePanel}><h2 style={smallTitle}>Project files</h2>{files.map(file => <button key={file.id} onClick={() => setSelectedPath(file.path)} style={{ ...fileButton, background: selectedPath === file.path ? "#30245b" : "transparent" }}>{file.path}</button>)}<p style={{ ...muted, fontSize: 12, marginTop: 18 }}>Changes are saved to this project's tenant-scoped file store.</p></aside>
      <section style={editorPanel}><div style={editorHead}><strong>{selectedPath}</strong><button onClick={saveFile} disabled={busy} style={smallButton}>{busy ? "Saving…" : "Save file"}</button></div><textarea aria-label="Project file editor" spellCheck={false} value={content} onChange={e => setContent(e.target.value)} style={editor} /></section>
    </section>
    {preview && <section style={{ ...panel, marginTop: 18 }}><h2 style={smallTitle}>Local HTML preview</h2><p style={muted}>This preview renders the current editor contents in a sandboxed frame. It is not a hosted public deployment.</p><iframe title="Local website preview" sandbox="" srcDoc={preview} style={{ width: "100%", minHeight: 420, border: "1px solid #35405d", borderRadius: 12, background: "white" }} /></section>}
    <section style={{ ...panel, marginTop: 18 }}><h2 style={smallTitle}>Prepare a marketplace listing</h2><p style={muted}>Save a private draft listing for this website. Publishing, buyer checkout, ownership transfer and seller payouts are not enabled yet.</p><form onSubmit={createListing} style={{ display: "grid", gap: 12 }}><label>Listing title<input required minLength={3} maxLength={100} value={listingTitle} onChange={e => setListingTitle(e.target.value)} style={field} placeholder="Website title" /></label><label>Description<textarea required minLength={20} maxLength={2000} rows={3} value={listingDescription} onChange={e => setListingDescription(e.target.value)} style={field} placeholder="Describe the site, features and what a buyer receives." /></label><label>Asking price (GBP)<input required type="number" min="0.01" max="1000000" step="0.01" value={listingPrice} onChange={e => setListingPrice(e.target.value)} style={field} /></label><button disabled={busy} style={button}>Save draft listing</button></form></section>
  </main>;
}
const wrap: React.CSSProperties = { maxWidth: 1200, margin: "0 auto", padding: "28px 22px 80px" };
const header: React.CSSProperties = { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 18, flexWrap: "wrap", marginBottom: 24 };
const muted: React.CSSProperties = { color: "#aeb9d3", lineHeight: 1.55 };
const button: React.CSSProperties = { border: 0, borderRadius: 10, background: "#8b5cf6", color: "white", padding: "12px 16px", fontWeight: 700, cursor: "pointer" };
const panel: React.CSSProperties = { background: "#121a30", border: "1px solid #26314d", borderRadius: 18, padding: 22 };
const smallTitle: React.CSSProperties = { marginTop: 0, fontSize: 18 };
const workspace: React.CSSProperties = { display: "grid", gridTemplateColumns: "220px minmax(0,1fr)", gap: 14 };
const filePanel: React.CSSProperties = { background: "#121a30", border: "1px solid #26314d", borderRadius: 16, padding: 16 };
const editorPanel: React.CSSProperties = { background: "#121a30", border: "1px solid #26314d", borderRadius: 16, padding: 16, minWidth: 0 };
const editorHead: React.CSSProperties = { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, marginBottom: 12 };
const fileButton: React.CSSProperties = { display: "block", width: "100%", border: 0, borderRadius: 8, color: "#e5e7eb", textAlign: "left", padding: 10, cursor: "pointer" };
const smallButton: React.CSSProperties = { border: "1px solid #4c3c7a", borderRadius: 8, background: "#241c40", color: "#ddd6fe", padding: "8px 12px" };
const editor: React.CSSProperties = { width: "100%", minHeight: 450, resize: "vertical", boxSizing: "border-box", border: "1px solid #35405d", borderRadius: 10, background: "#080d19", color: "#e5e7eb", padding: 14, fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: 13, lineHeight: 1.6 };
const field: React.CSSProperties = { display: "block", width: "100%", boxSizing: "border-box", marginTop: 7, padding: 12, borderRadius: 9, border: "1px solid #35405d", background: "#0b1020", color: "#fff" };
const notice: React.CSSProperties = { background: "#123528", border: "1px solid #236449", borderRadius: 10, padding: 12, color: "#bbf7d0" };
const errorStyle: React.CSSProperties = { background: "#451d2a", border: "1px solid #7f1d3d", borderRadius: 10, padding: 12, color: "#fecdd3" };
