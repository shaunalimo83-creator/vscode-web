# Phase 8 — API tenant context and isolation

## Implemented

- Added `withTenantSession` in `packages/db/src/tenant.ts`.
- The helper hashes the supplied session token and verifies the session is active, unrevoked and unexpired before starting tenant work.
- Inside one Prisma interactive transaction it sets `app.user_id` transaction-locally, resolves the fixed application company through a matching `UserCompany` membership, checks the allowed role, then sets `app.company_id` transaction-locally before invoking tenant work.
- The company slug and allowed roles are server constants in each app's `lib/tenant-api.ts`; request parameters cannot select another tenant or elevate a role.
- Protected customer summary/export and staff/admin summary routes across all seven business apps now fail closed through the shared tenant gate. They return 401 without a valid session, 403 without the required company membership/role, and 503 after successful authorisation until their data contracts and queries are implemented.
- Added Phase 8 Company RLS policy migration so a user can resolve only company rows where they have a membership before `app.company_id` is known. The policy relies on the user-scoped `UserCompany` RLS policy. Memberships are now read-only to runtime tenant roles (preventing self-enrolment and self-promotion); audit logs and intercompany authorisations are append-only; recovery codes are scoped to the authenticated user.
- Added unit tests for missing/revoked sessions, absent membership, role mismatch and transaction-local user/company context.
- Added an opt-in PostgreSQL RLS integration script that checks membership-based company discovery, tenant-scoped reads, membership visibility, cross-tenant insert rejection and runtime DB role bypass settings.

## Business app session cookie contract

Each business app gate currently expects a host-only, HttpOnly, Secure-in-production, SameSite=Strict cookie:

- `empire_growthboost_session`
- `empire_ai_magazine_session`
- `empire_trust_vault_session`
- `empire_stock_express_session`
- `empire_real_estate_session`
- `empire_supergpu_session`
- `empire_dailyaccess_session`

The business-app login endpoints are still unconfigured (501). No cookie is issued by this phase. Do not manually mint these cookies. A later identity phase must issue them only after verifying credentials/MFA and create/revoke corresponding database sessions.

## HQ authentication compatibility

The HQ session resolver and login/recovery/session audit writes now set `app.user_id` and `app.company_id` transaction-locally before querying membership or writing company-scoped audit records. The first CEO bootstrap uses `DIRECT_URL` and verifies the connection role can perform the controlled provisioning operation after forced RLS is active.

## Apply and verify

1. Back up the database and apply Prisma migrations in order through `20261116170000_phase8_tenant_api_context` using the migration/admin connection.
2. Run the applications using a separate PostgreSQL runtime role that is not table owner, superuser or `BYPASSRLS`.
3. Run `npm run preflight` and `npm run security:rls-check`.
4. Install dependencies and run `npm test` and `npm run typecheck`.
5. For the opt-in database test, create two disposable companies and a test user who belongs to Company A only, then set `RLS_TEST_COMPANY_A_ID`, `RLS_TEST_COMPANY_B_ID`, and `RLS_TEST_USER_ID` in a protected test environment. Run `npm run security:rls-integration` using the non-bypass runtime role. The script can create a one-unit sentinel product in Company B only if RLS is broken; clean the fixture database after testing.

## Not yet complete

- The business apps' login/session issuance and MFA integration are not implemented.
- Customer summary, export and admin summary data contracts are intentionally not implemented; authorised calls return 503 rather than invented data.
- Public enquiry endpoints do not yet persist records.
- No PostgreSQL migration, live integration test, full unit test suite, TypeScript build, production build, penetration test or deployment was run in this phase.
- The custom PostgreSQL settings are trusted application context, not protection against arbitrary SQL execution under the same runtime role. Prevent SQL injection, keep DB credentials private, use least privilege, and obtain an independent security review. RLS is defence in depth, not a substitute for explicit application predicates, permission checks and audit trails.
