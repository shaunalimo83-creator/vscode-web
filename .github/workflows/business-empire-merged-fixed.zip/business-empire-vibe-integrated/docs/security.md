# Security & Permissions Documentation

## Identity & access

| Control | Implementation |
|---|---|
| Passwords | scrypt (N=16384 default), unique salt, constant-time verify |
| MFA | TOTP RFC 6238, ±1 step skew, constant-time compare (`packages/core/src/mfa.ts`) |
| Sessions | 256-bit random tokens, stored hashed (SHA-256), httpOnly cookies |
| RBAC | 4 roles × 16 permissions, scoped per company (`packages/core/src/rbac.ts`) |
| Tenancy | `company_id` on every row + PostgreSQL RLS policies |
| Audit | Every privileged action → `AuditLog` (actor, company, action, subject, IP, timestamp) |

## Role model

| Role | Scope | Key permissions |
|---|---|---|
| `customer` | own account | site:read |
| `staff` | their company | admin:read, customer:read, site:write |
| `admin` | their company | + billing, ledger, reports, staff:manage, security:read |
| `ceo` | HQ only | + cross-company consolidated reporting (read-only) |

Hard rules, enforced in code and tested:

1. A `ceo` membership cannot be attached to an operating company — HQ only.
2. `customer:banking:read` exists for Trust Vault staff and is **never**
   reachable cross-company; the HQ role does not hold it. Customer banking
   data is stored in a trust-vault-only table the HQ role is not granted.
3. Every API route calls `authorize(companyId, permission)` before any data
   access; failures return 401/403 and are audit-logged.

## Financial controls

- Intercompany transfers require an `IntercompanyAuthorisation` row
  (approver, reference, amount) and post as a balanced intercompany journal
  pair. The ledger rejects any other cross-company journal.
- Refunds require an `authorisationRef` and are executed only through the
  provider interface against the original `providerRef`.
- No payment confirmation is ever displayed unless the provider's verified
  webhook reports `succeeded`. Simulated data is forbidden in production
  (`SimulatedProvider` self-destructs when `NODE_ENV === production`).

## Regulatory posture (honesty register)

- **Trust Vault Bank** — name is a trading style only. It is **not** an
  authorised bank. Financial-services features ship only through appropriately
  authorised partners; until then the UI says so and no banking data is stored.
- **Stock Market Express** — paper trading only. Live brokerage/order routing
  is disabled until an appropriately authorised partner is integrated.
- No statement of FCA authorisation is made anywhere in the product or docs.

## Secrets

- All secrets via environment variables (`/.env.example` template); never in
  code or the repo. MFA secrets encrypted at rest with a KMS data key.
- Webhook endpoints verify provider signatures before processing.

## Reporting a vulnerability

security@example.com — PGP key published at /.well-known before launch.
