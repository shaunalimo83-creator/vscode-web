# DNS records (example.com → replace with the registered group domain)

| Subdomain | Type | Target | Company |
|---|---|---|---|
| growthboost | CNAME | edge.example.com | GrowthBoost AI |
| aimagazine | CNAME | edge.example.com | AI Magazine & Comic Book Studio |
| trustvault | CNAME | edge.example.com | Trust Vault Bank |
| stockexpress | CNAME | edge.example.com | Stock Market Express |
| realestate | CNAME | edge.example.com | Real Estate Master Developments |
| supergpu | CNAME | edge.example.com | SUPERGPU UNIVERSAL |
| dailyaccess | CNAME | edge.example.com | DailyAccess |
| hq | CNAME | edge.example.com | CEO Master Dashboard |

TLS: managed certificates, auto-renewal, HSTS on. Each record maps to its own
app deployment; the database is shared but RLS-isolated per company_id.
