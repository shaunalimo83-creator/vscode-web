import { describe, expect, it } from "vitest";
import { isSameOriginRequest } from "./http-security.js";

function headers(values: Record<string, string>) {
  return { get: (name: string) => values[name.toLowerCase()] ?? null };
}

describe("cookie-authenticated request origin guard", () => {
  it("accepts exact same-origin HTTP and HTTPS requests", () => {
    expect(isSameOriginRequest(headers({ origin: "https://hq.example.com", host: "hq.example.com" }))).toBe(true);
    expect(isSameOriginRequest(headers({ origin: "http://localhost:3000", host: "localhost:3000" }))).toBe(true);
  });
  it("rejects missing, malformed, or cross-origin headers", () => {
    expect(isSameOriginRequest(headers({ host: "hq.example.com" }))).toBe(false);
    expect(isSameOriginRequest(headers({ origin: "https://evil.example", host: "hq.example.com" }))).toBe(false);
    expect(isSameOriginRequest(headers({ origin: "not a URL", host: "hq.example.com" }))).toBe(false);
    expect(isSameOriginRequest(headers({ origin: "https://hq.example.com/path", host: "hq.example.com" }))).toBe(false);
  });
  it("rejects unsafe host syntax and credential-bearing origins", () => {
    expect(isSameOriginRequest(headers({ origin: "https://hq.example.com", host: "hq.example.com/evil" }))).toBe(false);
    expect(isSameOriginRequest(headers({ origin: "https://user:pass@hq.example.com", host: "hq.example.com" }))).toBe(false);
  });
});
