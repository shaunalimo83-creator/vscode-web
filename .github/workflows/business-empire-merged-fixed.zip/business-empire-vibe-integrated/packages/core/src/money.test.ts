import { describe, it, expect } from "vitest";
import { gbp, money, add, sum, format, convertToReportingCurrency } from "./money.js";

describe("money", () => {
  it("stores amounts as integer minor units", () => {
    expect(gbp(10, 50).minor).toBe(1050);
    expect(() => gbp(10.5 as unknown as number)).toThrow();
  });

  it("adds and sums without floating point error", () => {
    expect(add(gbp(0, 10), gbp(0, 5)).minor).toBe(15);
    expect(sum([gbp(0, 1), gbp(0, 2), gbp(0, 3)]).minor).toBe(6);
    expect(sum([gbp(1), gbp(2)])).toEqual({ currency: "GBP", minor: 300 });
  });

  it("refuses to mix currencies", () => {
    expect(() => add(gbp(1), money("USD" as never, 100))).toThrow(/currency mismatch/);
  });

  it("formats GBP correctly", () => {
    expect(format(gbp(1234, 56))).toBe("£1,234.56");
    expect(format({ currency: "GBP", minor: -7 })).toBe("-£0.07");
  });

  it("requires an FX rate for non-GBP consolidation", () => {
    const eur = money("EUR" as never, 200);
    const { value, rateUsed } = convertToReportingCurrency(eur, 0.85);
    expect(value.currency).toBe("GBP");
    expect(value.minor).toBe(170);
    expect(rateUsed).toBe(0.85);
    expect(() => convertToReportingCurrency(eur, NaN)).toThrow(/FX rate/);
  });
});
