/**
 * Payment provider interface — the ONLY way money-touching code interacts
 * with a PSP (Stripe, GoCardless, etc.).
 *
 * PRODUCTION RULE (see docs/security.md):
 *  - No implementation may fabricate a payment confirmation.
 *  - Until a provider is connected AND webhook signature verification is
 *    configured, every method throws ProviderNotConnectedError and the UI
 *    must render the checkout as "unavailable", never as "successful".
 *  - The SimulatedProvider below exists solely for tests and clearly
 *    labelled prototypes; it refuses to run when NODE_ENV === "production".
 */

export interface PaymentIntentRequest {
  companyId: string;
  customerId: string;
  amountMinor: number;
  currency: string;
  reference: string;
  description: string;
}

export interface PaymentIntent {
  providerRef: string;
  clientSecret: string;
  status: "requires_payment" | "processing" | "succeeded";
}

export interface RefundRequest {
  providerRef: string;
  amountMinor: number;
  reason: string;
  authorisationRef: string; // required by financial controls
}

export class ProviderNotConnectedError extends Error {
  constructor(provider: string) {
    super(`payment provider "${provider}" is not connected in this environment`);
  }
}

export interface PaymentProvider {
  readonly name: string;
  createIntent(req: PaymentIntentRequest): Promise<PaymentIntent>;
  refund(req: RefundRequest): Promise<{ refundRef: string; status: string }>;
  verifyWebhook(payload: Buffer, signature: string): boolean;
}

export class SimulatedProvider implements PaymentProvider {
  readonly name = "simulated";
  constructor(private readonly env: string) {
    if (env === "production") {
      throw new Error("SimulatedProvider is forbidden in production");
    }
  }
  async createIntent(_req: PaymentIntentRequest): Promise<PaymentIntent> {
    throw new ProviderNotConnectedError(this.name);
  }
  async refund(_req: RefundRequest): Promise<{ refundRef: string; status: string }> {
    throw new ProviderNotConnectedError(this.name);
  }
  verifyWebhook(_payload: Buffer, _signature: string): boolean {
    throw new ProviderNotConnectedError(this.name);
  }
}

export function getPaymentProvider(env: string, stripeKey?: string): PaymentProvider {
  if (env === "production") {
    // Real adapter is added when the merchant account is live. The interface
    // above is the contract it must implement; until then this throws.
    throw new ProviderNotConnectedError(stripeKey ? "stripe" : "no provider configured");
  }
  return new SimulatedProvider(env);
}
