/**
 * Role-based access control. Permissions are scoped to a company (tenant).
 * A user's membership in a company carries a role; cross-company access
 * requires a separate membership. The holding "ceo" role grants read-only
 * consolidated reporting across companies and write access to HQ records —
 * it never grants access to customer banking data of any company.
 */

export const PERMISSIONS = [
  "site:read",
  "site:write",
  "admin:read",
  "admin:write",
  "billing:read",
  "billing:write",
  "customer:read",
  "customer:write",
  "customer:banking:read", // restricted: Trust Vault only, never cross-company
  "ledger:read",
  "ledger:write",
  "reports:read",
  "reports:export",
  "staff:manage",
  "security:read",
  "cross_company:read_reports", // CEO/HQ only, reporting aggregates
] as const;

export type Permission = (typeof PERMISSIONS)[number];

export const ROLES = ["customer", "staff", "admin", "ceo"] as const;
export type Role = (typeof ROLES)[number];

const CUSTOMER: Permission[] = ["site:read"];
const STAFF: Permission[] = [...CUSTOMER, "admin:read", "customer:read", "site:write"];
const ADMIN: Permission[] = [
  ...STAFF,
  "admin:write",
  "billing:read",
  "billing:write",
  "customer:write",
  "ledger:read",
  "ledger:write",
  "reports:read",
  "reports:export",
  "staff:manage",
  "security:read",
];
const CEO: Permission[] = [...ADMIN, "cross_company:read_reports"];

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  customer: CUSTOMER,
  staff: STAFF,
  admin: ADMIN,
  ceo: CEO,
};

/** Company where each role may exist. ceo memberships live in the HQ tenant. */
export function rolePermittedInCompany(role: Role, companyId: string): boolean {
  if (role === "ceo") return companyId === "hq";
  return true;
}

export interface Membership {
  userId: string;
  companyId: string;
  role: Role;
}

export interface AuthContext {
  userId: string;
  memberships: Membership[];
}

/** Resolve a membership for (user, company). Returns null when absent. */
export function getMembership(ctx: AuthContext, companyId: string): Membership | null {
  const m = ctx.memberships.find(
    (x) => x.companyId === companyId && rolePermittedInCompany(x.role, x.companyId),
  );
  return m ?? null;
}

export function can(ctx: AuthContext, companyId: string, permission: Permission): boolean {
  const m = getMembership(ctx, companyId);
  if (!m) return false;
  return ROLE_PERMISSIONS[m.role].includes(permission);
}

/** Guard helper: throws when the permission is not held (use in API routes). */
export class PermissionDeniedError extends Error {
  constructor(public companyId: string, public permission: Permission) {
    super(`permission denied: ${permission} on ${companyId}`);
  }
}

export function requirePermission(
  ctx: AuthContext,
  companyId: string,
  permission: Permission,
): void {
  if (!can(ctx, companyId, permission)) throw new PermissionDeniedError(companyId, permission);
}

/**
 * Hard isolation rule: customer banking data may only be read inside the
 * company that owns the customer, by staff explicitly granted the banking
 * permission in that company. The CEO cross-company reporting permission
 * deliberately excludes it.
 */
export function canReadBankingData(ctx: AuthContext, companyId: string): boolean {
  if (companyId === "hq") return false;
  const m = getMembership(ctx, companyId);
  if (!m) return false;
  return ROLE_PERMISSIONS[m.role].includes("customer:banking:read");
}
