import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { newSessionToken, sha256 } from "./auth.js";

export { newSessionToken, sha256 };

function encryptionKey(): Buffer {
  const raw = process.env.AUTH_MFA_ENCRYPTION_KEY;
  if (!raw) throw new Error("AUTH_MFA_ENCRYPTION_KEY is not configured");
  const key = Buffer.from(raw, "base64");
  if (key.length !== 32) throw new Error("AUTH_MFA_ENCRYPTION_KEY must decode to 32 bytes");
  return key;
}

export function decryptMfaSecret(payload: string): string {
  const [ivHex, tagHex, dataHex] = payload.split(":");
  if (!ivHex || !tagHex || !dataHex) throw new Error("Invalid encrypted MFA secret");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(ivHex, "hex"));
  decipher.setAuthTag(Buffer.from(tagHex, "hex"));
  return Buffer.concat([decipher.update(Buffer.from(dataHex, "hex")), decipher.final()]).toString("utf8");
}

export function encryptMfaSecret(secret: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const data = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  return `${iv.toString("hex")}:${cipher.getAuthTag().toString("hex")}:${data.toString("hex")}`;
}
