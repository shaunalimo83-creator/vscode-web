import { describe, expect, it } from "vitest";
import {
  VIBE_BUSINESS_TARGETS,
  canCreateVibeProject,
  escapeVibeHtml,
  isSafeVibeProjectPath,
  isVibeBusinessSlug,
} from "./vibe-coding.js";

describe("Vibe Coding Platform shared rules", () => {
  it("limits target business selection to the seven existing businesses", () => {
    expect(VIBE_BUSINESS_TARGETS).toHaveLength(7);
    expect(isVibeBusinessSlug("growthboost")).toBe(true);
    expect(isVibeBusinessSlug("hq")).toBe(false);
    expect(isVibeBusinessSlug("unknown-company")).toBe(false);
  });

  it("enforces the free website allowance and unlimited plan semantics", () => {
    expect(canCreateVibeProject("free", 2)).toBe(true);
    expect(canCreateVibeProject("free", 3)).toBe(false);
    expect(canCreateVibeProject("unlimited", 1000)).toBe(true);
    expect(canCreateVibeProject("unknown", 0)).toBe(true); // unknown plans fail back to free
  });

  it("rejects unsafe file paths", () => {
    expect(isSafeVibeProjectPath("src/app.tsx")).toBe(true);
    expect(isSafeVibeProjectPath("../secrets.env")).toBe(false);
    expect(isSafeVibeProjectPath("/etc/passwd")).toBe(false);
    expect(isSafeVibeProjectPath("src\\app.tsx")).toBe(false);
  });

  it("escapes user-provided project names before inserting them into starter HTML", () => {
    expect(escapeVibeHtml('<script>alert("x")</script>')).toBe("&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;");
  });
});
