-- Phase 7: enforce PostgreSQL row-level security using the actual Prisma
-- PostgreSQL identifiers (Prisma's default columns are quoted camelCase).
-- Apply with a migration/admin role. Runtime app roles must NOT own these
-- tables and must not have SUPERUSER or BYPASSRLS.
-- Set app.company_id inside the same transaction as each tenant query:
--   SELECT set_config('app.company_id', '<company UUID>', true);
-- The final `true` makes the setting transaction-local.

-- Company directory: a tenant can see only its own company record.
ALTER TABLE "Company" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Company" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS company_tenant_isolation ON "Company";
CREATE POLICY company_tenant_isolation ON "Company"
  USING ("id" = NULLIF(current_setting('app.company_id', true), ''))
  WITH CHECK ("id" = NULLIF(current_setting('app.company_id', true), ''));

-- Ordinary company-owned tables. These names and columns match schema.prisma.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'Product','Customer','Subscription','Payment','Expense',
    'LedgerAccount','JournalEntry','Integration'
  ] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation ON %I', t);
    EXECUTE format(
      'CREATE POLICY tenant_isolation ON %I USING ("companyId" = NULLIF(current_setting(''app.company_id'', true), '''')) WITH CHECK ("companyId" = NULLIF(current_setting(''app.company_id'', true), ''''))',
      t
    );
  END LOOP;
END $$;

-- Membership records are scoped to the authenticated user, not company_id.
-- The identity layer must set app.user_id transaction-locally after verifying
-- the user. Do not grant the ordinary tenant role unrestricted membership reads.
ALTER TABLE "UserCompany" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "UserCompany" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS user_membership_isolation ON "UserCompany";
CREATE POLICY user_membership_isolation ON "UserCompany"
  USING ("userId" = NULLIF(current_setting('app.user_id', true), ''))
  WITH CHECK ("userId" = NULLIF(current_setting('app.user_id', true), ''));

-- Audit logs are visible only inside their company context. Global/system audit
-- rows with NULL companyId are deliberately invisible to tenant roles.
ALTER TABLE "AuditLog" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "AuditLog" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation ON "AuditLog";
CREATE POLICY tenant_isolation ON "AuditLog"
  USING ("companyId" IS NOT NULL AND "companyId" = NULLIF(current_setting('app.company_id', true), ''))
  WITH CHECK ("companyId" IS NOT NULL AND "companyId" = NULLIF(current_setting('app.company_id', true), ''));

-- Intercompany authorisations are readable by either participating company,
-- but only the originating company context may create/change an authorisation.
ALTER TABLE "IntercompanyAuthorisation" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "IntercompanyAuthorisation" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS intercompany_participant_isolation ON "IntercompanyAuthorisation";
CREATE POLICY intercompany_participant_isolation ON "IntercompanyAuthorisation"
  USING (
    "fromCompanyId" = NULLIF(current_setting('app.company_id', true), '') OR
    "toCompanyId" = NULLIF(current_setting('app.company_id', true), '')
  )
  WITH CHECK ("fromCompanyId" = NULLIF(current_setting('app.company_id', true), ''));

-- Session, RecoveryCode and AuthThrottle are identity/security tables, not
-- company-owned tables. Keep them out of company policies and access them only
-- through narrowly scoped identity-service queries (userId/key predicates).
-- A dedicated audited HQ reporting role may read approved aggregate views only;
-- it must not be granted direct access to Trust Vault customer financial data.
