import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const expected = [
  ['hq', 3000], ['growthboost', 3001], ['ai-magazine', 3002],
  ['trust-vault', 3003], ['stock-express', 3004], ['real-estate', 3005],
  ['supergpu', 3006], ['dailyaccess', 3007], ['vibe-coding-platform', 3008],
];
const errors = [];
const check = (condition, message) => { if (!condition) errors.push(message); };
for (const [app, port] of expected) {
  const dir = path.join(root, 'apps', app);
  check(fs.existsSync(path.join(dir, 'package.json')), `Missing app package: ${app}`);
  if (app === 'vibe-coding-platform') {
    for (const file of ['lib/auth.ts', 'lib/security.ts', 'app/api/projects/route.ts', 'app/api/projects/[id]/generate/route.ts', 'app/api/auth/login/route.ts', 'app/api/marketplace/route.ts']) {
      check(fs.existsSync(path.join(dir, file)), `Missing Vibe Coding Platform file: ${file}`);
    }
    const appPkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
    check(appPkg.dependencies?.['@empire/db'] === '1.0.0' && appPkg.dependencies?.['@empire/core'] === '1.0.0', 'Vibe Coding Platform must use shared database and core packages');
  }
  if (app !== 'hq' && app !== 'vibe-coding-platform') {
    check(fs.existsSync(path.join(dir, 'lib/tenant-api.ts')), `Missing tenant API guard: ${app}`);
    const appPkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
    check(appPkg.dependencies?.['@empire/db'] === '1.0.0', `${app} must depend on the shared database package`);
    for (const route of ['app/api/admin/summary/route.ts', 'app/api/me/summary/route.ts', 'app/api/me/export/route.ts']) {
      const routePath = path.join(dir, route);
      check(fs.existsSync(routePath) && fs.readFileSync(routePath, 'utf8').includes('tenantApiGate'), `${app}/${route} must use tenant API gate`);
    }
  }
  check(fs.existsSync(path.join(dir, 'app', 'page.tsx')), `Missing app entry page: ${app}`);
  if (app !== 'hq' && app !== 'vibe-coding-platform') {
    const dashboard = fs.readFileSync(path.join(dir, 'app/dashboard/page.tsx'), 'utf8');
    const admin = fs.readFileSync(path.join(dir, 'app/admin/page.tsx'), 'utf8');
    const login = fs.readFileSync(path.join(dir, 'app/login/page.tsx'), 'utf8');
    check(dashboard.includes('remain unavailable') || dashboard.includes('SETUP PENDING'), `${app} customer workspace must disclose pending services`);
    check(admin.includes('SETUP PENDING') && admin.includes('does not grant admin access'), `${app} control room must disclose pending admin services`);
    check(login.includes('Sign in') && login.includes('Create account'), `${app} login must expose sign-in and registration modes`);
    check(fs.existsSync(path.join(dir, 'lib/identity.ts')), `${app} shared customer identity helper missing`);
    for (const endpoint of ['register','login','logout','me']) check(fs.existsSync(path.join(dir, `app/api/auth/${endpoint}/route.ts`)), `${app} auth endpoint missing: ${endpoint}`);
  }
  const nextConfig = path.join(dir, 'next.config.mjs');
  check(fs.existsSync(nextConfig) && fs.readFileSync(nextConfig, 'utf8').includes('transpilePackages'), `${app} must transpile shared workspace packages`);
  if (fs.existsSync(path.join(dir, 'package.json'))) {
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
    check((pkg.scripts?.dev ?? '').includes(`-p ${port}`), `${app} dev script must use port ${port}`);
    check((pkg.scripts?.start ?? '').includes(`-p ${port}`), `${app} start script must use port ${port}`);
  }
}
const required = [
  'packages/core/src/vibe-coding.ts', 'packages/core/src/vibe-coding.test.ts',
  'packages/db/prisma/migrations/20261117170000_phase14_vibe_coding_platform/migration.sql',
  'packages/core/src/auth.ts', 'packages/core/src/mfa.ts', 'packages/core/src/rbac.ts',
  'packages/db/prisma/schema.prisma', 'packages/db/policies/rls.sql',
  'apps/hq/app/api/auth/login/route.ts', 'apps/hq/app/api/auth/logout/route.ts',
  'apps/hq/app/api/auth/me/route.ts', 'apps/hq/app/api/consolidated/route.ts',
  'apps/hq/app/api/auth/session.ts',
  'docs/auth-database-foundation.md', 'docs/hq-hardening-notes.md',
  'scripts/bootstrap-ceo.mjs', 'docs/phase5-owner-bootstrap.md',
  'apps/hq/app/api/auth/throttle.ts', 'apps/hq/app/api/auth/sessions/route.ts',
  'apps/hq/app/api/auth/sessions/revoke-others/route.ts', 'apps/hq/app/api/auth/recovery-codes/route.ts',
  'scripts/cleanup-auth.mjs', 'packages/db/prisma/migrations/20261116140000_phase6_auth_throttle/migration.sql',
  'docs/phase7-tenant-isolation.md', 'scripts/check-rls.mjs',
  'packages/db/prisma/migrations/20261116160000_phase7_rls_hardening/migration.sql',
  'packages/db/src/tenant.ts', 'packages/db/src/tenant.test.ts', 'packages/db/src/index.ts',
  'packages/db/prisma/migrations/20261116170000_phase8_tenant_api_context/migration.sql',
  'packages/db/prisma/migrations/20261116180000_phase10_identity_company_lookup/migration.sql',
  'docs/phase10-customer-identity.md',
];
for (const file of required) check(fs.existsSync(path.join(root, file)), `Missing required foundation file: ${file}`);
const envPath = path.join(root, '.env.example');
if (fs.existsSync(envPath)) {
  const lines = fs.readFileSync(envPath, 'utf8').split(/\r?\n/);
  const keys = lines.filter(x => /^[A-Z][A-Z0-9_]*=/.test(x)).map(x => x.split('=')[0]);
  const duplicates = keys.filter((k, i) => keys.indexOf(k) !== i);
  check(duplicates.length === 0, `Duplicate environment variable(s): ${[...new Set(duplicates)].join(', ')}`);
}
if (errors.length) {
  console.error('Empire preflight FAILED');
  for (const e of errors) console.error(`- ${e}`);
  process.exit(1);
}
const rootPackage = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
check(rootPackage.scripts?.['bootstrap:ceo'] === 'node scripts/bootstrap-ceo.mjs', 'Missing CEO bootstrap npm script');
check(Boolean(rootPackage.dependencies?.dotenv), 'CEO bootstrap requires dotenv to load local environment settings');
check(rootPackage.scripts?.['security:rls-check'] === 'node scripts/check-rls.mjs', 'Missing RLS structural check script');
if (errors.length) { console.error('Empire preflight FAILED'); for (const e of errors) console.error(`- ${e}`); process.exit(1); }
console.log(`Empire preflight PASSED: ${expected.length} app workspaces (seven businesses, HQ and shared Vibe platform), customer identity endpoints, unique dev/start ports, auth/MFA/RBAC/session/recovery/throttle/RLS/database foundation files present, environment keys unique.`);
console.log('This is a structural preflight only; it does not replace dependency installation, type-checking, tests, builds, penetration testing or deployment verification.');
