import 'dotenv/config';
import { PrismaClient } from '@prisma/client';

const required = ['RLS_TEST_COMPANY_A_ID', 'RLS_TEST_COMPANY_B_ID', 'RLS_TEST_USER_ID'];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing required isolated-test variables: ${missing.join(', ')}`);
  process.exit(2);
}

const prisma = new PrismaClient();
const a = process.env.RLS_TEST_COMPANY_A_ID;
const b = process.env.RLS_TEST_COMPANY_B_ID;
const userId = process.env.RLS_TEST_USER_ID;
let failures = [];
try {
  const role = await prisma.$queryRaw`SELECT current_user AS role, rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user`;
  if (!role[0] || role[0].rolsuper || role[0].rolbypassrls) {
    throw new Error('Integration test must use a non-superuser, non-BYPASSRLS runtime database role');
  }

  const visibleCompanies = await prisma.$transaction(async (tx) => {
    // Resolve the fixed app's company using membership before company_id exists.
    await tx.$queryRaw`SELECT set_config('app.user_id', ${userId}, true)`;
    return tx.company.findMany({ where: { id: { in: [a, b] } }, select: { id: true } });
  });
  if (!visibleCompanies.some((row) => row.id === a) || visibleCompanies.some((row) => row.id === b)) {
    failures.push('Membership-based company discovery exposed a non-member company or hid the member company');
  }

  const scopedReads = await prisma.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT set_config('app.user_id', ${userId}, true)`;
    await tx.$queryRaw`SELECT set_config('app.company_id', ${a}, true)`;
    const own = await tx.company.findUnique({ where: { id: a }, select: { id: true } });
    const other = await tx.company.findUnique({ where: { id: b }, select: { id: true } });
    const products = await tx.product.findMany({ select: { companyId: true } });
    const memberships = await tx.userCompany.findMany({ select: { userId: true, companyId: true } });
    if (!own || other) failures.push('Company visibility crossed tenant boundary or own company was hidden');
    if (products.some((row) => row.companyId !== a)) failures.push('Product query returned another tenant row');
    if (memberships.some((row) => row.userId !== userId)) failures.push('Membership query returned another user row');
    return own;
  });
  if (!scopedReads) failures.push('Tenant A fixture is not visible to the runtime role');

  let crossWriteRejected = false;
  try {
    await prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${userId}, true)`;
      await tx.$queryRaw`SELECT set_config('app.company_id', ${a}, true)`;
      await tx.product.create({ data: {
        companyId: b, slug: `rls-cross-tenant-${Date.now()}`, name: 'RLS test sentinel',
        kind: 'digital', priceMinor: 1, currency: 'GBP',
      } });
    });
  } catch {
    crossWriteRejected = true;
  }
  if (!crossWriteRejected) failures.push('Cross-tenant Product insert was not rejected by RLS');

  if (failures.length) {
    console.error('PostgreSQL RLS integration test FAILED');
    for (const failure of failures) console.error(`- ${failure}`);
    process.exitCode = 1;
  } else {
    console.log('PostgreSQL RLS integration test PASSED: tenant reads, membership scope and cross-tenant write rejection verified.');
  }
} finally {
  await prisma.$disconnect();
}
