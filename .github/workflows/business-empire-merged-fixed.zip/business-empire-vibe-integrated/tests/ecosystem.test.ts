import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { BUSINESSES } from "../packages/core/src/entities.js";

const ROOT = join(import.meta.dirname, "..");

describe("ecosystem integrity (each business independently)", () => {
  const allApps = BUSINESSES.map((b) => b.id).concat("hq");

  it("generates all seven business apps plus HQ", () => {
    for (const a of allApps) {
      for (const f of ["package.json", "app/page.tsx", "app/layout.tsx", "app/login/page.tsx"]) {
        expect(
          (() => { readFileSync(join(ROOT, "apps", a, f)); return true; })(),
          `apps/${a}/${f} missing`,
        ).toBe(true);
      }
    }
  });

  it("every business app has a customer dashboard, admin area and legal pages", () => {
    for (const b of BUSINESSES) {
      for (const f of ["app/dashboard/page.tsx", "app/admin/page.tsx", "app/legal/privacy/page.tsx", "app/legal/terms/page.tsx", "app/support/page.tsx", "app/account-recovery/page.tsx"]) {
        expect(
          (() => { readFileSync(join(ROOT, "apps", b.id, f)); return true; })(),
          `apps/${b.id}/${f} missing`,
        ).toBe(true);
      }
    }
  });

  it("every business page links customer dashboard, admin, login and legal pages", () => {
    for (const b of BUSINESSES) {
      const page = readFileSync(join(ROOT, "apps", b.id, "app", "page.tsx"), "utf8");
      for (const link of ['"/dashboard"', '"/admin"', '"/login"', '"/legal/privacy"', '"/legal/terms"']) {
        expect(page.includes(link), `${b.id} missing ${link}`).toBe(true);
      }
    }
  });

  it("HQ dashboard exposes all seven business panels and core HQ features", () => {
    const page = readFileSync(join(ROOT, "apps", "hq", "app", "page.tsx"), "utf8");
    for (const b of BUSINESSES) expect(page.includes(b.name), `HQ panel missing ${b.name}`).toBe(true);
    const files = [
      "app/reports/page.tsx", "app/staff/page.tsx", "app/security/page.tsx",
      "app/api/consolidated/route.ts", "app/api/health/route.ts",
    ];
    for (const f of files) readFileSync(join(ROOT, "apps", "hq", f)); // throws if missing
  });


  it("integrates the shared Vibe Coding Platform with all seven businesses and HQ", () => {
    const vibeRoot = join(ROOT, "apps", "vibe-coding-platform");
    for (const file of ["package.json", "app/page.tsx", "app/login/page.tsx", "app/projects/page.tsx", "app/marketplace/page.tsx", "app/plans/page.tsx", "app/api/projects/route.ts", "app/api/projects/[id]/generate/route.ts", "app/api/projects/[id]/files/route.ts", "app/api/projects/[id]/listing/route.ts", "app/api/auth/login/route.ts", "app/api/marketplace/route.ts", "lib/auth.ts"]) {
      readFileSync(join(vibeRoot, file));
    }
    for (const business of BUSINESSES) {
      const page = readFileSync(join(ROOT, "apps", business.id, "app", "page.tsx"), "utf8");
      expect(page).toMatch(/Vibe Coding Studio/);
      const dashboard = readFileSync(join(ROOT, "apps", business.id, "app", "dashboard", "page.tsx"), "utf8");
      expect(dashboard).toMatch(/Build a website or app/);
    }
    const hq = readFileSync(join(ROOT, "apps", "hq", "app", "page.tsx"), "utf8");
    expect(hq).toMatch(/Vibe Coding Platform/);
  });

  it("regulatory notices are honest and prominent where required", () => {
    const trust = readFileSync(join(ROOT, "apps", "trust-vault", "app", "page.tsx"), "utf8");
    expect(trust).toMatch(/not an authorised bank/);
    expect(trust).toMatch(/authorised partner/i);
    const stock = readFileSync(join(ROOT, "apps", "stock-express", "app", "page.tsx"), "utf8");
    expect(stock).toMatch(/Paper trading only/);
  });

  it("every business app has a health endpoint", () => {
    for (const a of allApps) {
      readFileSync(join(ROOT, "apps", a, "app", "api", "health", "route.ts"));
    }
  });
});

describe("financial controls are present in the schema", () => {
  const schema = readFileSync(join(ROOT, "packages", "db", "prisma", "schema.prisma"), "utf8");
  it("records entity, amount, currency, status, date, reference and provider on every payment", () => {
    for (const field of ["companyId", "amountMinor", "currency", "status", "createdAt", "reference", "provider", "providerRef"]) {
      expect(schema.includes(field), `Payment missing ${field}`).toBe(true);
    }
  });
  it("has an intercompany authorisation model (no silent money movement)", () => {
    expect(schema).toMatch(/model IntercompanyAuthorisation/);
  });
  it("enforces RLS in SQL policies", () => {
    const rls = readFileSync(join(ROOT, "packages", "db", "policies", "rls.sql"), "utf8");
    expect(rls).toMatch(/ENABLE ROW LEVEL SECURITY/);
    expect(rls).toMatch(/tenant_isolation/);
    const phase14 = readFileSync(join(ROOT, "packages", "db", "prisma", "migrations", "20261117170000_phase14_vibe_coding_platform", "migration.sql"), "utf8");
    expect(phase14).toMatch(/VibeProject/);
    expect(phase14).toMatch(/ENABLE ROW LEVEL SECURITY/);
    expect(phase14).toMatch(/vibe_marketplace_public_or_owner_read/);
  });
});
