import { defineConfig } from "vitest/config";
export default defineConfig({
  test: {
    include: ["tests/**/*.test.ts", "packages/core/src/**/*.test.ts", "packages/db/src/**/*.test.ts"],
    environment: "node",
  },
});
