# GrowthBoost AI — Secure Google OAuth & CEO Permissions

This is an integration patch for the existing React + Supabase application. It does not replace the dashboard.

## What it implements

- Real Google OAuth through Supabase Auth.
- Session restoration and sign-out.
- A server-controlled `platform_owner` role stored separately from user-editable profile metadata.
- A database function used by the client to check the current user's role.
- A protected React route for CEO-only screens.
- A Supabase Edge Function (`ceo-gate`) that verifies the bearer token and checks the role server-side before allowing sensitive CEO operations.
- RLS-protected example CEO settings table.

## Important limitations

This bundle is source code, not a deployed integration. It cannot authenticate users until the Supabase and Google settings below are completed and the files are integrated into the existing Manus project's source. No credentials are included.

## 1. Configure Google OAuth

1. In Google Cloud Console, create/select a project.
2. Configure the OAuth consent screen and create an OAuth Client ID of type **Web application**.
3. Add the Supabase callback URL shown in **Supabase Dashboard → Authentication → Providers → Google** to Google's **Authorised redirect URIs**. It normally looks like:
   `https://YOUR_PROJECT_REF.supabase.co/auth/v1/callback`
4. Enable Google in Supabase → Authentication → Sign In / Providers → Google.
5. Paste the Google Client ID and Client Secret into Supabase. Do not put the Google Client Secret in React code.
6. In Supabase → Authentication → URL Configuration, set the production Site URL and add the exact application callback/redirect URLs to the allow list. Include local development URLs only if needed.

## 2. Configure frontend environment

Add these values to the existing app's environment configuration:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

The anon/publishable key is intended for browser use with RLS enabled. Never add the Supabase service-role key, Google Client Secret, or OpenAI secret to `VITE_*` variables.

Install the client if not already present:

```bash
npm install @supabase/supabase-js
```

## 3. Apply the SQL migration

Run `supabase/migrations/001_secure_ceo_roles.sql` in the Supabase SQL Editor (or apply it using your normal migration workflow).

The migration creates:
- `public.app_role`
- `public.user_roles`
- `public.has_app_role(...)`
- `public.platform_ceo_settings` as a sample protected table.

The role table has RLS enabled and deliberately has no client write policies. Users cannot promote themselves from the browser.

## 4. Sign in once, then grant the owner role

First sign in to the application using the intended Google account. Then open Supabase → Authentication → Users, find the account and copy its UUID.

Run the following SQL in the Supabase SQL Editor, replacing `PASTE_AUTH_USER_UUID_HERE` with that UUID:

```sql
insert into public.user_roles (user_id, role, granted_by)
select id, 'platform_owner', id
from auth.users
where id = 'PASTE_AUTH_USER_UUID_HERE'::uuid
  and lower(email) = 'shaun.alimo@growthboost.ai'
  and email_confirmed_at is not null
  and coalesce(raw_app_meta_data->'providers', '[]'::jsonb) ? 'google'
on conflict (user_id, role) do nothing;
```

Then verify:

```sql
select u.id, u.email, r.role, r.created_at
from public.user_roles r
join auth.users u on u.id = r.user_id
where lower(u.email) = 'shaun.alimo@growthboost.ai';
```

Only grant this role after you personally confirm that the Supabase Auth user is the correct account. The email check is an additional safeguard, not a substitute for checking the account UUID. Do not grant the role based only on a value supplied by the browser.

## 5. Deploy the server-side CEO gate

Set the Edge Function secrets in Supabase:

```bash
supabase secrets set SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
supabase secrets set SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=YOUR_SUPABASE_SERVICE_ROLE_KEY
```

Deploy:

```bash
supabase functions deploy ceo-gate
```

Keep `verify_jwt` enabled for this function. The function also validates the user token with Supabase Auth and looks up the role using a server-only service-role client.

## 6. Integrate the React files

- Copy `src/lib/supabase.ts` into your app's `src/lib/` folder.
- Copy `src/auth/AuthProvider.tsx` and `src/auth/ProtectedRoute.tsx`.
- Wrap the app with `AuthProvider` in `src/main.tsx` (example below).
- Add the sign-in page and callback route to your existing router.
- Wrap the CEO Control page/route in `ProtectedRoute requiredRole="platform_owner"`.
- Remove the hardcoded `authSession`, fake `handleGoogleLogin`, fake Google subject ID, and any UI code that assigns `SUPER_ADMIN` locally.
- Do not rely on hiding a tab or button as security. Every server/database operation must independently enforce authorization.

Example `src/main.tsx`:

```tsx
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "./auth/AuthProvider";
import App from "./App";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <App />
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);
```

Example route wiring (adapt to the app's existing router):

```tsx
<Route path="/login" element={<LoginPage />} />
<Route path="/auth/callback" element={<AuthCallbackPage />} />
<Route
  path="/ceo"
  element={
    <ProtectedRoute requiredRole="platform_owner">
      <CeoControlPage />
    </ProtectedRoute>
  }
/>
```

## 7. Protect real CEO actions

Before performing any sensitive action (for example changing platform-wide settings, granting roles, viewing all tenants, or initiating financial administration), call the `ceo-gate` Edge Function from the browser and perform the action in a trusted server-side function. Do not return the service-role key to the browser.

Example:

```tsx
const { data, error } = await supabase.functions.invoke("ceo-gate");
if (error || !data?.authorized) {
  throw new Error("CEO authorization required");
}
// This confirms authorization only. Perform the sensitive operation
// in a separately protected server-side function, not in the browser.
```

The gate is not a replacement for authorization inside each sensitive Edge Function. Each function must verify the caller and role itself before carrying out its operation.

## 8. Test checklist

- A visitor can see only public/login content.
- Google sign-in redirects to Google and returns to the allow-listed app URL.
- A normal signed-in customer cannot open `/ceo`.
- A normal customer cannot call protected CEO Edge Functions.
- Editing React state, local storage, URL parameters, or user profile metadata does not grant CEO access.
- The owner account can open `/ceo` only after the role row has been granted.
- Signing out clears access.
- Expired/revoked sessions are rejected.
- RLS blocks cross-tenant reads and writes on business tables (separate tenant policies still need to be applied to your actual schema).
