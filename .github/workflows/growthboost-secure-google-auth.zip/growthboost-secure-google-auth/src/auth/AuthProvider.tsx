import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "../lib/supabase";

export type AppRole =
  | "platform_owner"
  | "business_admin"
  | "staff"
  | "customer";

type AuthContextValue = {
  session: Session | null;
  user: User | null;
  role: AppRole | null;
  loading: boolean;
  roleLoading: boolean;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  refreshRole: () => Promise<AppRole | null>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function readCurrentRole(): Promise<AppRole | null> {
  const { data, error } = await supabase.rpc("current_app_role");
  if (error) {
    console.error("Unable to verify account role:", error.message);
    return null;
  }
  return (data as AppRole | null) ?? null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [role, setRole] = useState<AppRole | null>(null);
  const [roleLoading, setRoleLoading] = useState(false);

  const refreshRole = useCallback(async () => {
    setRoleLoading(true);
    try {
      const nextRole = await readCurrentRole();
      setRole(nextRole);
      return nextRole;
    } finally {
      setRoleLoading(false);
    }
  }, []);

  useEffect(() => {
    let alive = true;

    supabase.auth.getSession().then(({ data, error }) => {
      if (!alive) return;
      if (error) console.error("Session restore failed:", error.message);
      setSession(data.session);
      setLoading(false);
      if (data.session) {
        void refreshRole();
      } else {
        setRole(null);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!alive) return;
      setSession(nextSession);
      if (nextSession) {
        // Defer the RPC until after the auth event callback completes.
        queueMicrotask(() => {
          if (alive) void refreshRole();
        });
      } else {
        setRole(null);
        setRoleLoading(false);
      }
    });

    return () => {
      alive = false;
      subscription.unsubscribe();
    };
  }, [refreshRole]);

  const signInWithGoogle = useCallback(async () => {
    const redirectTo = `${window.location.origin}/auth/callback`;
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo,
        queryParams: { prompt: "select_account" },
      },
    });
    if (error) throw error;
  }, []);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    setRole(null);
    setSession(null);
  }, []);

  const value = useMemo(
    () => ({
      session,
      user: session?.user ?? null,
      role,
      loading,
      roleLoading,
      signInWithGoogle,
      signOut,
      refreshRole,
    }),
    [session, role, loading, roleLoading, signInWithGoogle, signOut, refreshRole]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
