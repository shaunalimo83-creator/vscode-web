import type { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth, type AppRole } from "./AuthProvider";

export function ProtectedRoute({
  children,
  requiredRole,
}: {
  children: ReactNode;
  requiredRole: AppRole;
}) {
  const { user, role, loading, roleLoading } = useAuth();

  if (loading || roleLoading) {
    return <div role="status" aria-live="polite">Verifying secure account permissions…</div>;
  }

  if (!user) return <Navigate to="/login" replace />;

  if (role !== requiredRole) {
    return <Navigate to="/unauthorised" replace />;
  }

  return <>{children}</>;
}
