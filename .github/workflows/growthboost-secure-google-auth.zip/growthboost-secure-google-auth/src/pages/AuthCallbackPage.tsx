import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { supabase } from "../lib/supabase";

export default function AuthCallbackPage() {
  const [status, setStatus] = useState("Completing secure sign-in…");
  const [done, setDone] = useState(false);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data, error }) => {
      if (!active) return;
      if (error || !data.session) {
        setStatus("Sign-in could not be completed. Please return to login and try again.");
        return;
      }
      setDone(true);
    });
    return () => { active = false; };
  }, []);

  if (done) return <Navigate to="/" replace />;
  return <main className="min-h-screen bg-[#070B14] text-white grid place-items-center p-6">{status}</main>;
}
