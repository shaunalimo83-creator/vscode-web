import { useState } from "react";
import { useAuth } from "../auth/AuthProvider";

export default function LoginPage() {
  const { signInWithGoogle } = useAuth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleGoogleSignIn() {
    setBusy(true);
    setError("");
    try {
      await signInWithGoogle();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Google sign-in could not be started.");
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#070B14] text-white grid place-items-center p-6">
      <section className="w-full max-w-md rounded-2xl border border-slate-800 bg-[#0E1526] p-8">
        <h1 className="text-2xl font-bold">GrowthBoost AI</h1>
        <p className="mt-2 text-slate-400">Sign in securely to your business account.</p>
        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={busy}
          className="mt-6 w-full rounded-xl bg-indigo-600 px-4 py-3 font-semibold disabled:opacity-60"
        >
          {busy ? "Redirecting to Google…" : "Continue with Google"}
        </button>
        {error && <p role="alert" className="mt-4 text-sm text-rose-300">{error}</p>}
      </section>
    </main>
  );
}
