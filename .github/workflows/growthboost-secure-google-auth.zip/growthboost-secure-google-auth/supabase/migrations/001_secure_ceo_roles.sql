-- GrowthBoost AI secure role foundation.
-- Apply using the Supabase SQL Editor or your migration workflow.

do $$ begin
  create type public.app_role as enum (
    'platform_owner',
    'business_admin',
    'staff',
    'customer'
  );
exception
  when duplicate_object then null;
end $$;

create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  granted_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

alter table public.user_roles enable row level security;

-- Users may read their own assigned role, but cannot insert, update, or delete roles.
drop policy if exists "Users can read their own roles" on public.user_roles;
create policy "Users can read their own roles"
on public.user_roles
for select
to authenticated
using (user_id = (select auth.uid()));

-- No client write policies are intentionally created. Role grants/revocations
-- must be performed by a trusted administrator through a controlled server path
-- or the Supabase SQL Editor.

create or replace function public.current_app_role()
returns public.app_role
language sql
stable
security definer
set search_path = ''
as $$
  select r.role
  from public.user_roles r
  where r.user_id = (select auth.uid())
  order by
    case r.role
      when 'platform_owner' then 1
      when 'business_admin' then 2
      when 'staff' then 3
      else 4
    end
  limit 1;
$$;

revoke all on function public.current_app_role() from public;
grant execute on function public.current_app_role() to authenticated;

create or replace function public.has_app_role(required_role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.user_roles r
    where r.user_id = (select auth.uid())
      and r.role = required_role
  );
$$;

revoke all on function public.has_app_role(public.app_role) from public;
grant execute on function public.has_app_role(public.app_role) to authenticated;

-- Example of a platform-owner-only table. Adapt policies to actual CEO data tables.
create table if not exists public.platform_ceo_settings (
  id uuid primary key default gen_random_uuid(),
  setting_key text not null unique,
  setting_value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null
);

alter table public.platform_ceo_settings enable row level security;

drop policy if exists "Only platform owner can read CEO settings" on public.platform_ceo_settings;
create policy "Only platform owner can read CEO settings"
on public.platform_ceo_settings
for select
to authenticated
using (public.has_app_role('platform_owner'));

drop policy if exists "Only platform owner can update CEO settings" on public.platform_ceo_settings;
create policy "Only platform owner can update CEO settings"
on public.platform_ceo_settings
for update
to authenticated
using (public.has_app_role('platform_owner'))
with check (public.has_app_role('platform_owner'));

drop policy if exists "Only platform owner can insert CEO settings" on public.platform_ceo_settings;
create policy "Only platform owner can insert CEO settings"
on public.platform_ceo_settings
for insert
to authenticated
with check (public.has_app_role('platform_owner'));

-- Deliberately no browser-side delete policy for CEO settings.
