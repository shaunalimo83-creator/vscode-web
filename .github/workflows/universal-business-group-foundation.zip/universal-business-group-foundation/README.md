# Universal Business Group — CEO Business Empire HQ

The master application foundation for one connected platform containing seven business workspaces.

## Included business workspaces

1. GrowthBoost AI
2. DailyAccess
3. Trust Vault Bank
4. AI Magazine & Comic Book Studio
5. Website Builder Marketplace
6. Business Empire: CEO Simulator
7. SuperGPU Universal

## Current status

This repository package is a **frontend foundation preview**, not a production platform. It includes a responsive CEO dashboard, business directory, workspace blueprint views, a platform architecture overview and an integration readiness page.

It does not yet include production authentication, a database, customer accounts, payment processing, seller payouts, live AI services or connected third-party systems. The interface intentionally labels integrations as unconnected rather than implying they are live.

## Run locally

- Install the dependencies with your package manager.
- Start the development server with `npm run dev`.
- Create a production build with `npm run build`.

## Architecture principles

- One master command centre and seven connected but separately permissioned business workspaces.
- Tenant-aware data access and least-privilege roles.
- Separate seller ledgers and provider-reconciled payout records.
- Server-side secrets only; verified webhooks and idempotent payment operations.
- Audit trails, backups, recovery and explicit customer consent.
- Integrations remain disabled until credentials, permissions and end-to-end tests are complete.

See `docs/ARCHITECTURE.md` and `docs/SECURITY-AND-FINANCE.md`.

## Deployment

The project is Vite-based and can be deployed to a static hosting platform such as Vercel after the repository is connected and the production build succeeds. Configure environment variables only when server-side services are added. Do not add secrets to source control.
