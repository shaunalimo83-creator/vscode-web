# Security, Payments and Financial Controls

## Authentication and authorization

- Use a reputable identity provider and secure session management.
- Require server-side authorization on every protected operation.
- Enforce business membership, role and tenant scope.
- Use least-privilege access, MFA for privileged roles where supported, and secure account recovery.
- Keep secrets out of client bundles, source control, logs and error messages.

## Payments and seller payouts

Use a reputable, appropriately regulated payment service provider and a marketplace product that supports the intended countries and business model (for example, Stripe Connect only if its terms and capabilities fit). Complete provider-led seller onboarding and verification.

The application must maintain clear records of:
- gross order amount and currency;
- platform fees and provider fees where available;
- refunds, disputes and chargebacks;
- seller allocation and net proceeds;
- provider payout IDs, status and timestamps;
- reconciliation results and administrative adjustments.

Use verified provider webhooks, idempotency keys, duplicate-event handling, audit logs and reconciliation jobs. Do not represent the platform as holding escrow unless the provider contract explicitly supports that arrangement. Do not promise instant or unrestricted withdrawals; payout timing and availability depend on the provider, account status, reserves and applicable rules.

## Customer funds and Trust Vault Bank

The Trust Vault Bank workspace name does not establish that the platform is a bank or holds a banking licence. Do not accept deposits, issue stored value, provide regulated banking services or custody customer funds without the required authorisations and provider arrangements. Use regulated providers for payment and payout flows.

## Tax and reporting

Record the underlying transaction facts and provide exportable reports. Support country-specific tax configuration only after specialist review. Do not claim that the platform automatically determines or files every seller's tax obligations.

## Privacy and operations

- Collect only necessary personal data and document retention periods.
- Provide clear privacy notices and consent controls.
- Encrypt data in transit and at rest through supported infrastructure.
- Restrict support access and log privileged data access.
- Maintain backups, tested restoration procedures and incident response processes.
- Review dependencies, vulnerabilities and access credentials regularly.

## Launch gates

Do not enable real customer accounts, live payments or financial services until legal, provider, security, privacy and operational reviews are complete and end-to-end tests pass.
