import { useState } from 'react'
import {
  Activity, ArrowUpRight, BookOpen, BrainCircuit, Building2, ChevronRight,
  CircleHelp, Cpu, Gamepad2, Globe2, Landmark, LayoutDashboard, LockKeyhole,
  Menu, Newspaper, Plug, ShieldCheck, Wallet, X, Crown
} from 'lucide-react'

const businesses = [
  { id:'growthboost', name:'GrowthBoost AI', category:'AI business growth platform', icon:BrainCircuit, description:'AI tools for marketing, sales, operations, customer retention and business performance.' },
  { id:'dailyaccess', name:'DailyAccess', category:'News and advance briefings', icon:Newspaper, description:'Topic-based news, updates and advance briefings with clear sourcing and freshness.' },
  { id:'trustvault', name:'Trust Vault Bank', category:'Financial services workspace', icon:Landmark, description:'A financial-services workspace with careful separation of customer records and regulated-provider integrations.' },
  { id:'magazine', name:'AI Magazine & Comic Book Studio', category:'Publishing and creator tools', icon:BookOpen, description:'Create, edit, publish and sell magazines, comics and digital publications.' },
  { id:'marketplace', name:'Website Builder Marketplace', category:'Websites and marketplace', icon:Globe2, description:'Build websites and discover, buy and sell approved digital products and services.' },
  { id:'simulator', name:'Business Empire: CEO Simulator', category:'Business simulation', icon:Gamepad2, description:'A business-building simulation connected to the wider brand ecosystem.' },
  { id:'supergpu', name:'SuperGPU Universal', category:'Computing and GPU services', icon:Cpu, description:'A workspace for GPU computing products, services and infrastructure.' },
] as const

type BusinessId = typeof businesses[number]['id']
type Page = 'overview' | 'businesses' | 'architecture' | 'integrations'

function App() {
  const [page, setPage] = useState<Page>('overview')
  const [selected, setSelected] = useState<BusinessId | null>(null)
  const [mobileOpen, setMobileOpen] = useState(false)
  const activeBusiness = businesses.find(b => b.id === selected)

  const nav = [
    { id:'overview' as Page, label:'CEO overview', icon:LayoutDashboard },
    { id:'businesses' as Page, label:'Business workspaces', icon:Building2 },
    { id:'architecture' as Page, label:'Platform architecture', icon:ShieldCheck },
    { id:'integrations' as Page, label:'Integrations', icon:Plug },
  ]

  function go(next: Page) { setPage(next); setSelected(null); setMobileOpen(false) }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
      <div className="brand">
        <div className="brand-mark"><Crown size={21}/></div>
        <div><strong>UNIVERSAL</strong><span>BUSINESS GROUP</span></div>
        <button className="icon-button mobile-close" onClick={() => setMobileOpen(false)} aria-label="Close navigation"><X size={19}/></button>
      </div>
      <div className="workspace-label">MASTER WORKSPACE</div>
      <div className="workspace-chip"><div className="workspace-avatar">U</div><div><b>CEO Command Centre</b><small>Master administration</small></div></div>
      <nav aria-label="Main navigation">
        <div className="nav-label">WORKSPACE</div>
        {nav.map(item => <button key={item.id} className={`nav-item ${page===item.id?'active':''}`} onClick={() => go(item.id)}><item.icon size={18}/><span>{item.label}</span>{page===item.id && <ChevronRight size={15} className="nav-arrow"/>}</button>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="secure-note"><LockKeyhole size={16}/><span><b>Security-first design</b><small>Access controls required</small></span></div>
        <div className="version">FOUNDATION PREVIEW · v0.1.0</div>
      </div>
    </aside>

    <main className="main">
      <header className="topbar">
        <button className="icon-button menu-button" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu size={20}/></button>
        <div className="breadcrumb">Universal Business Group <span>/</span> <b>{activeBusiness?.name ?? nav.find(n=>n.id===page)?.label}</b></div>
        <div className="top-actions"><span className="status-dot"></span><span className="top-status">Foundation preview</span><div className="avatar">CEO</div></div>
      </header>

      <div className="content">
        {page==='overview' && !activeBusiness && <>
          <section className="welcome">
            <div><div className="eyebrow"><span className="eyebrow-line"></span> MASTER CONTROL</div><h1>CEO Business<br/><em>Command Centre</em></h1><p>One connected headquarters for seven businesses, shared platform services and clearly separated customer workspaces.</p></div>
            <div className="welcome-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="core"><Crown size={34}/><span>UBG</span></div><div className="orbit-node node-a"><BrainCircuit/></div><div className="orbit-node node-b"><Wallet/></div><div className="orbit-node node-c"><Cpu/></div></div>
          </section>
          <div className="notice"><Activity size={18}/><div><b>Development foundation — not a live financial or customer system</b><span>This preview contains navigation and business workspace descriptions. Authentication, databases, payment processing and live integrations still need to be implemented and tested.</span></div></div>
          <section className="section-heading"><div><div className="eyebrow">YOUR PORTFOLIO</div><h2>Seven connected businesses</h2><p>Each business has its own workspace within one shared platform.</p></div><button className="text-link" onClick={()=>go('businesses')}>View all businesses <ArrowUpRight size={16}/></button></section>
          <div className="business-grid">{businesses.map((b,i)=><button className="business-card" key={b.id} onClick={()=>setSelected(b.id)}><div className="card-top"><div className="business-icon"><b.icon size={21}/></div><span className="card-index">0{i+1}</span></div><h3>{b.name}</h3><div className="category">{b.category}</div><p>{b.description}</p><div className="card-footer"><span>Workspace blueprint</span><ArrowUpRight size={16}/></div></button>)}</div>
          <section className="section-heading lower-heading"><div><div className="eyebrow">SHARED FOUNDATION</div><h2>One platform. Clear boundaries.</h2></div></section>
          <div className="foundation-grid">
            <div className="foundation-card"><LockKeyhole/><b>Identity & permissions</b><span>Business-scoped roles, customer ownership and tenant isolation.</span></div>
            <div className="foundation-card"><Wallet/><b>Financial records</b><span>Seller-specific transaction ledgers, payout status and audit history.</span></div>
            <div className="foundation-card"><BrainCircuit/><b>AI command layer</b><span>Shared AI services with business-specific permissions and context.</span></div>
            <div className="foundation-card"><Plug/><b>Integration centre</b><span>Approved payment, accounting, email, calendar and service connections.</span></div>
          </div>
        </>}

        {page==='businesses' && !activeBusiness && <>
          <div className="page-intro"><div className="eyebrow">PORTFOLIO DIRECTORY</div><h1>Business workspaces</h1><p>Seven distinct business experiences, connected through the CEO headquarters.</p></div>
          <div className="business-grid directory">{businesses.map((b,i)=><button className="business-card" key={b.id} onClick={()=>setSelected(b.id)}><div className="card-top"><div className="business-icon"><b.icon size={21}/></div><span className="card-index">0{i+1}</span></div><h3>{b.name}</h3><div className="category">{b.category}</div><p>{b.description}</p><div className="card-footer"><span>Open workspace blueprint</span><ArrowUpRight size={16}/></div></button>)}</div>
        </>}

        {activeBusiness && <section className="detail-panel"><button className="back-link" onClick={()=>setSelected(null)}>← Back to {page==='businesses'?'businesses':'overview'}</button><div className="detail-icon"><activeBusiness.icon size={30}/></div><div className="eyebrow">BUSINESS WORKSPACE BLUEPRINT</div><h1>{activeBusiness.name}</h1><div className="category">{activeBusiness.category}</div><p className="detail-description">{activeBusiness.description}</p><div className="notice"><CircleHelp size={18}/><div><b>Workspace specification stage</b><span>This business is listed in the master portfolio. Its production features, data connections and customer flows have not yet been connected.</span></div></div><h2>Shared platform rules</h2><ul className="rule-list"><li>Customers enter through an authenticated account and receive only the access they are authorised to use.</li><li>Business data is scoped to the correct business and customer; cross-business access is permission-controlled.</li><li>Sales, fees, refunds, payouts and balances must be traceable to the correct seller and payment provider records.</li><li>External integrations remain inactive until credentials, permissions and end-to-end tests are configured.</li></ul></section>}

        {page==='architecture' && <>
          <div className="page-intro"><div className="eyebrow">TECHNICAL BLUEPRINT</div><h1>Platform architecture</h1><p>Build a reliable shared core before activating individual business capabilities.</p></div>
          <div className="architecture-stack">
            <div className="arch-layer master"><span>01 · CONTROL PLANE</span><b>CEO Business Command Centre</b><small>Portfolio administration · business settings · oversight · audit views</small></div>
            <div className="arch-connector">↓</div>
            <div className="arch-layer"><span>02 · BUSINESS EXPERIENCE</span><b>Seven isolated business workspaces</b><small>GrowthBoost AI · DailyAccess · Trust Vault Bank · Magazine & Comic Studio · Website Builder Marketplace · CEO Simulator · SuperGPU Universal</small></div>
            <div className="arch-connector">↓</div>
            <div className="arch-layer"><span>03 · SHARED PLATFORM SERVICES</span><b>Identity · Profiles · Permissions · Notifications · AI gateway</b><small>Business-scoped access policies and customer consent</small></div>
            <div className="arch-connector">↓</div>
            <div className="arch-layer"><span>04 · DATA & FINANCIAL CONTROLS</span><b>Tenant-aware database · transaction ledger · audit logs</b><small>Seller attribution · payout reconciliation · retention and backup policies</small></div>
            <div className="arch-connector">↓</div>
            <div className="arch-layer"><span>05 · EXTERNAL PROVIDERS</span><b>Payment provider · email · accounting · hosting · approved APIs</b><small>Provider credentials stored server-side; least-privilege access and webhook verification</small></div>
          </div>
          <div className="notice"><ShieldCheck size={18}/><div><b>Important financial boundary</b><span>Trust Vault Bank is a product/workspace name, not evidence of a licensed bank. Customer funds must be handled by appropriately authorised providers under their actual product terms. No escrow, instant withdrawal or guaranteed protection is implied.</span></div></div>
        </>}

        {page==='integrations' && <>
          <div className="page-intro"><div className="eyebrow">CONNECTION MANAGEMENT</div><h1>Integration centre</h1><p>External services are deliberately shown as unconnected until configured and verified.</p></div>
          <div className="integration-list">
            {[['Payment processing','Stripe Connect or another suitable regulated provider','Seller onboarding, checkout, fees, refunds, disputes and payouts'],['Database & authentication','Production database and identity provider','Tenant isolation, secure sessions, roles and account recovery'],['Email & notifications','Approved transactional email provider','Verified sender domain, consent and delivery tracking'],['Accounting & tax','Supported accounting and tax services','Exports, gross sales, fees, refunds and jurisdiction-specific settings'],['Hosting & monitoring','Production hosting, logs and error monitoring','Environment separation, health checks, backups and alerts']].map((x,i)=><div className="integration-row" key={x[0]}><div className="integration-number">0{i+1}</div><div className="integration-copy"><b>{x[0]}</b><span>{x[1]}</span><small>{x[2]}</small></div><span className="unconnected">Not connected</span></div>)}
          </div>
          <div className="notice"><LockKeyhole size={18}/><div><b>Never place secret keys in browser code</b><span>Provider credentials belong in protected server-side environment variables or a secrets manager. Live payments require webhook signature checks, idempotency, reconciliation and test-mode verification.</span></div></div>
        </>}
      </div>
      <footer><span>UNIVERSAL BUSINESS GROUP</span><span>Master application foundation · Development preview</span></footer>
    </main>
    {mobileOpen && <button className="mobile-scrim" onClick={()=>setMobileOpen(false)} aria-label="Close navigation overlay"/>}
  </div>
}

export default App
