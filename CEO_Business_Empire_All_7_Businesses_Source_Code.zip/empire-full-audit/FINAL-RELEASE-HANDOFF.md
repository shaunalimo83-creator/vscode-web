# Business Empire — Combined Release Handoff

This is the consolidated development release for the seven business applications and CEO Headquarters. It is suitable as a source-code handoff and controlled local-development starting point. It is **not certified production-ready**.

## Applications and local addresses

| Application | Local address |
|---|---|
| CEO Headquarters | http://localhost:3000 |
| GrowthBoost AI | http://localhost:3001 |
| AI Magazine & Comic Book Studio | http://localhost:3002 |
| Trust Vault customer vault scaffold | http://localhost:3003 |
| Stock Market Express | http://localhost:3004 |
| Real Estate Master Developments | http://localhost:3005 |
| SUPERGPU UNIVERSAL | http://localhost:3006 |
| DailyAccess | http://localhost:3007 |

## Local development

1. Use Node.js 20 or newer and npm 10 or newer.
2. From this directory, install packages with `npm install`.
3. Copy `.env.example` to `.env`; use unique local-only secrets and a local PostgreSQL instance.
4. Review every Prisma migration, then apply migrations using the deployment procedure approved for your environment. Do not run migrations against production without a backup and review.
5. Generate Prisma Client and run the release checks: `npm run release:verify`.
6. Start all eight Next.js development servers with `npm run dev:all`.
7. Alternatively, use `docker compose -f infra/docker-compose.yml up --build` for the local-only container stack. It uses a development-only database password and must never be exposed to the public internet.

## What this release does and does not mean

The bundle includes eight Next.js workspaces, shared core/database packages, customer identity/security source, tenant-isolation/RLS foundations, account recovery and customer security pages, development orchestration, and documentation. Static checks confirm source structure only.

This environment could not complete npm dependency installation (the install operation timed out). Consequently, production builds, complete TypeScript checks, Vitest, Prisma validation/generation, actual migrations, PostgreSQL runtime isolation, and browser end-to-end tests are not certified by this release. Do not infer that a button or workflow is live merely because its page or API route exists.

## Mandatory launch gates

- Complete dependency installation and resolve all build/type/test failures.
- Validate Prisma schema; review and apply migrations in staging; execute PostgreSQL RLS tests with distinct tenants and roles.
- Configure a production-grade secrets manager, session encryption key, TLS, secure cookies, backups, restore drills, logging, monitoring, alerting and incident response.
- Configure and verify transactional email for verification and password reset; add abuse controls and rate limits before enabling registration. Registration stays disabled by default.
- Implement and test business-specific customer workflows, persistence, permissions, staff administration and customer support. Existing workspace pages are not proof of complete business operations.
- Implement the HQ consolidated ledger query, reconciliation and audit controls. HQ consolidated reporting currently fails closed until a real ledger data adapter and permission controls are configured.
- Connect payment providers per legal entity only after merchant onboarding; implement idempotent webhooks, refunds, disputes, reconciliation and accounting. No live payments are included.
- Configure object storage and KMS before storing identity or private customer documents.
- Register and verify domains, DNS, TLS, privacy notices, terms, support operations and data-retention/deletion workflows.
- Obtain specialist UK legal/regulatory review. Trust Vault is not a bank or deposit service; do not hold customer funds or offer e-money without appropriate authorisation/partners. Stock Market Express is not a live broker or investment adviser. Real-estate activity may trigger estate-agent, AML and redress obligations. SUPERGPU software cannot create physical GPU cores/VRAM or replace hardware; cloud GPU requires provider capacity, contracts, security and metered costs.

## Safe defaults

- `CUSTOMER_REGISTRATION_ENABLED=false`.
- Payment and broker credentials are blank/disabled.
- Trading remains paper-only/disabled unless an authorised broker integration is approved.
- No live customer financial balances, deposits, card controls, payments, refunds, brokerage orders, or regulated banking capabilities are represented as operational.
- Example domains are placeholders, not registered domains.

The release should be treated as a consolidated engineering handoff, not an executable promise of a finished commercial service.
